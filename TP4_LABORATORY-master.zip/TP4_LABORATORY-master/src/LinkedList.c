#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../inc/LinkedList.h"

static Node* getNode(LinkedList* this, int nodeIndex);
static int addNode(LinkedList* this, int nodeIndex,void* pElement);

/** \brief Crea un nuevo LinkedList en memoria de manera dinamica
 *
 *  \param void
 *  \return LinkedList* Retorna (NULL) en el caso de no conseguir espacio en memoria
 *                      o el puntero al espacio reservado
 */
LinkedList* ll_newLinkedList(void)
{
    LinkedList* this;

    this = (LinkedList*) malloc(sizeof(LinkedList));
    if(this!=NULL)
    {
        this->size = 0;
        this->pFirstNode = NULL;
    }

    return this;
}

/** \brief Retorna la cantidad de elementos de la lista
 *
 * \param this LinkedList* Puntero a la lista
 * \return int Retorna (-1) si el puntero es NULL o la cantidad de elementos de la lista
 *
 */
int ll_len(LinkedList* this)
{
    int returnAux = -1;
    if(this!=NULL)
    {
        returnAux =this->size;
    }


    return returnAux;
}


/** \brief  Obtiene un nodo de la lista
 *
 * \param this LinkedList* Puntero a la lista
 * \param index int Indice del nodo a obtener
 * \return Node* Retorna  (NULL) Error: si el puntero a la lista es NULL o (si el indice es menor a 0 o mayor al len de la lista)
                        (pElement) Si funciono correctamente
 *
 */
static Node* getNode(LinkedList* this, int nodeIndex)
{
    Node* pNode = NULL;

    int i;


  if(this != NULL && nodeIndex >-1 && nodeIndex <ll_len(this) )
    {
        pNode = this->pFirstNode; //PRIMER NODO LO GUARDO EN PNODE
        for(i=0; i <nodeIndex ; i++) // RECORRO LISTA
            {
                       pNode = pNode->pNextNode;


            }

    }

    return pNode;
}

/** \brief  Permite realizar el test de la funcion getNode la cual es privada
 *
 * \param this LinkedList* Puntero a la lista
 * \param index int Indice del nodo a obtener
 * \return Node* Retorna  (NULL) Error: si el puntero a la lista es NULL o (si el indice es menor a 0 o mayor al len de la lista)
                        (pElement) Si funciono correctamente
 *
 */
Node* test_getNode(LinkedList* this, int nodeIndex)
{
    return getNode(this, nodeIndex);
}


/** \brief Agrega y enlaza un nuevo nodo a la lista
 *
 * \param this LinkedList* Puntero a la lista
 * \param nodeIndex int Ubicacion donde se agregara el nuevo nodo
 * \param pElement void* Puntero al elemento a ser contenido por el nuevo nodo
 * \return int Retorna  (-1) Error: si el puntero a la lista es NULL o (si el indice es menor a 0 o mayor al len de la lista)
                        ( 0) Si funciono correctamente
 *
 */
static int addNode(LinkedList* this, int nodeIndex,void* pElement)
{
  int returnAux = -1;
    Node* prev;
    Node* nuevoNodo;

    if( this != NULL)
    {
        if(nodeIndex >= 0 && nodeIndex <= ll_len(this))//NODO MAYOR -1 Y MENOR AL LARGO DE LISTA THIS
        {
            nuevoNodo = (Node*)malloc(sizeof(Node)); //CREO MEMORIA PARA PUNTERO NUEVO NODO
            if(nuevoNodo != NULL) // VERIFICO SI ES NULL
            {
                nuevoNodo->pElement = pElement; // GUARDA DIRECCION DE MEMORIA DE LA "ESTRUCURA" A DONDE APUNTA EL NODO CREADO
                nuevoNodo->pNextNode = NULL; // UNA VEZ CREADO EL NODO, APUNTO AL PROXIMO NODO COMO NULL

                if(nodeIndex == 0) // SI INIDICE DADO ES IGUAL A 0
                {
                    nuevoNodo->pNextNode = this->pFirstNode; // EN EL CASO DE QUE NO ALLA NINGUN NODO CREADO, EL PRIMERO NODO LO GUARDO EN NEXTNODO
                    this->pFirstNode = nuevoNodo; // EL NUEVO NODO LO GUARDAMOS EN EL PRIMER NODO DE LA LISTA
                }
                else
                {
                    prev = this->pFirstNode;

                    while( nodeIndex > 1)
                    {

                       prev  = prev->pNextNode;//EL PRIMERO PASA AL PROXIMO
                        nodeIndex--;
                    }

                    prev->pNextNode = nuevoNodo;//ENTONCES EL PROXIMO PASA A HACER EL NODO CREADO

                }
                this->size++; //AUMENTO EL TAMA�O DE LA LISTAS
                returnAux = 0;
            }
        }
    }

    return returnAux;
}



/** \brief Permite realizar el test de la funcion addNode la cual es privada
 *
 * \param this LinkedList* Puntero a la lista
 * \param nodeIndex int Ubicacion donde se agregara el nuevo nodo
 * \param pElement void* Puntero al elemento a ser contenido por el nuevo nodo
  * \return int Retorna  (-1) Error: si el puntero a la lista es NULL o (si el indice es menor a 0 o mayor al len de la lista)
                        ( 0) Si funciono correctamente
 *
 */
int test_addNode(LinkedList* this, int nodeIndex,void* pElement)
{
    return addNode(this,nodeIndex,pElement);
}


/** \brief  Agrega un elemento a la lista
 * \param pList LinkedList* Puntero a la lista
 * \param pElement void* Puntero al elemento a ser agregado
 * \return int Retorna  (-1) Error: si el puntero a la lista es NULL
                        ( 0) Si funciono correctamente
 *
 */
int ll_add(LinkedList* this, void* pElement)
{
    int returnAux = -1;

    if(this != NULL)
        {
            addNode(this,this->size, pElement); //SI NO ES NULL LLAMO A ADDNODE Y AGREGO EL NUEVO "NODO"
            returnAux = 0;
        }

    return returnAux;
}
//  ******* OJO CORREGIR *******************
/** \brief Permite realizar el test de la funcion addNode la cual es privada
 *
 * \param this LinkedList* Puntero a la lista
 * \param nodeIndex int Ubicacion del elemento a obtener
 * \return void* Retorna    (NULL) Error: si el puntero a la lista es NULL o (si el indice es menor a 0 o mayor al len de la lista)
                            (pElement) Si funciono correctamente
 *
 */
void* ll_get(LinkedList* this, int index) //CONSIGUE ELEMENTO DEL NODO
{
    Node* returnAux = NULL;
    Node* pnode = NULL;

    if(this != NULL && index >= 0 && index< ll_len(this))
        {
            pnode = getNode(this,index); //GUARDAMS EL NODO COMPLETO EN PNODE
            if(pnode != NULL)
                {
                   returnAux = pnode->pElement; //GUARDAMOS EL ELEMENT A MOSTRAR
                }
        }


    return returnAux;
}


/** \brief Modifica un elemento de la lista
 *
 * \param this LinkedList* Puntero a la lista
 * \param nodeIndex int Ubicacion del elemento a modificar
 * \param pElement void* Puntero al nuevo elemento
 * \return int Retorna  (-1) Error: si el puntero a la lista es NULL o (si el indice es menor a 0 o mayor al len de la lista)
                        ( 0) Si funciono correctamente
 *
 */
int ll_set(LinkedList* this, int index,void* pElement) //CAMBIO ELEMNTO INTEGRADO A UN NODO , EJ. AUTO POR BICI
{
    int returnAux = -1;
    Node* actual; //GUARDO EL NODO A CAMBIAR

    if(this != NULL && index>= 0 && index< ll_len(this))
        {
            actual = getNode(this,index);

            if(actual != NULL)
                {
                    actual->pElement = pElement; // GUARDO ELEMNTO DADO EN UN NODO;
                    returnAux = 0;
                }
        }
    return returnAux;
}


/** \brief Elimina un elemento de la lista
 *
 * \param this LinkedList* Puntero a la lista
 * \param nodeIndex int Ubicacion del elemento a eliminar
 * \return int Retorna  (-1) Error: si el puntero a la lista es NULL o (si el indice es menor a 0 o mayor al len de la lista)
                        ( 0) Si funciono correctamente
 *
 */
int ll_remove(LinkedList* this,int index) //SOLICITA INDICE A ELIMINAR
{

    int returnAux = -1;
    Node*pNode;
    Node*pNodeDelete; //GUARDO EL NODO A BORRAR
    Node*PFirst; // USO PARA DECLARAR FIRST
    Node*PSiguiente;//USO PARA DECLARAR NEXT
    if (this!=NULL && index >=0 && index <ll_len(this))
    {
        PFirst = this->pFirstNode;
        PSiguiente = PFirst->pNextNode;
        pNodeDelete = getNode(this,index); //SOLOCITO NODO A BORRAR
        if (index==0) //SI INDICE EN POSICION CERO
        {
            //TENGO QUE DECIR QUE EL NODO QUE LE SIGUE EN ESTE CASO INDICE 1 ES EL PRIMERO AHORA INDICE 0
            PFirst =PSiguiente;
        }
        //PARA BORRAR EL ULTIMO , EL ANTERIO A ESTE SE DECLARA COMO NULL
        else if (index==ll_len(this)-1) //INDICE ANTE ULTIMO
        {
            pNode = getNode(this,index-1); //PIDO EL NODO ANTERIOR AL ULTIMO
            pNode->pNextNode = NULL; // EL QUE LE SIGUE AL ANTERIO AL ULTIMO LO DECLARO EN NULL
        }
        else
        {
            //SI QUIERO BORRAR UNO DEL MEDIO , EL ANTERIO A ESE HAGO QUE APUNTE AL PROXIMO
            //ES DECIR SI TENGO 1 2 3 , 1 TENDRA QUE APUNTAR A 3
            pNode = getNode(this,index-1); //NODO ANTERIOR
            pNode->pNextNode =getNode(this,index+1);//PROXIMO NODO APUNTA AL NODE PEDIDO MAS 1
        }
        returnAux = 0;
        free(pNodeDelete); //LIBERO AL NODO QUE QUIERO BORARR
        this->size--; //RESTO UNO DE LA LISTA POR BORAR
    }

    return returnAux;
}


/** \brief Elimina todos los elementos de la lista
 *
 * \param this LinkedList* Puntero a la lista
 * \return int Retorna  (-1) Error: si el puntero a la lista es NULL
                        ( 0) Si funciono correctamente
 *
 */
int ll_clear(LinkedList* this)
{
    int returnAux = -1;
    Node* nodo;
    int i;

    if(this != NULL)
        {
            for(i=0; i<ll_len(this); i++)
            {
                ll_remove(this,i); //MIENTRAS TERMINA DE ITERAR , BORRO CADA ELEMENTO DE THIS
                returnAux = 0;
            }
        }



    return returnAux;
}


/** \brief Elimina todos los elementos de la lista y la lista
 *
 * \param this LinkedList* Puntero a la lista
 * \return int Retorna  (-1) Error: si el puntero a la lista es NULL
                        ( 0) Si funciono correctamente
 *
 */
int ll_deleteLinkedList(LinkedList* this)
{
    int returnAux = -1;

    if(this != NULL)
        {
            ll_clear(this);//ELIMINO TODOS LOS ELEMENTOS
            free(this); //LIBERO LA MEMORIA OCUPADA
            returnAux = 0;
        }

    return returnAux;
}

/** \brief Busca el indice de la primer ocurrencia del elemento pasado como parametro
 *
 * \param this LinkedList* Puntero a la lista
 * \param pElement void* Puntero al elemento
 * \return int Retorna  (-1) Error: si el puntero a la lista es NULL
                        (indice del elemento) Si funciono correctamente
 *
 */
int ll_indexOf(LinkedList* this, void* pElement)
{
    int returnAux = -1;
    int i;
    Node* nodo;

    if(this != NULL)
        {
            nodo = this-> pFirstNode;
            for(i=0; i<ll_len(this);i++)
                {
                    ll_get(this,i);
                    if((nodo->pElement==pElement)) //COMPARO DIRECCIONES DE LOS ELEMENTOS
                        {
                            returnAux = i; //INDICE DEL ELEMENTO
                        }else
                        {
                            nodo = nodo->pNextNode;
                        }
                }
        }


    return returnAux;
}

/** \brief Indica si la lista esta o no vacia
 *
 * \param this LinkedList* Puntero a la lista
 * \return int Retorna  (-1) Error: si el puntero a la lista es NULL
                        ( 0) Si la lista NO esta vacia
                        ( 1) Si la lista esta vacia
 *
 */
int ll_isEmpty(LinkedList* this)
{
    int returnAux = -1;

    if(this != NULL)
    {
        if( ll_len(this)>0) //SI ES MAYOR A CERO
        {
            returnAux = 0; //NO ESTA VACIA
        }
        else
        {
            returnAux = 1; //SI NO ESTA VACIA
        }
    }
    return returnAux;
}

/** \brief Inserta un nuevo elemento en la lista en la posicion indicada
 *
 * \param this LinkedList* Puntero a la lista
 * \param nodeIndex int Ubicacion donde se agregara el nuevo elemento
 * \param pElement void* Puntero al nuevo elemento
 * \return int Retorna  (-1) Error: si el puntero a la lista es NULL o (si el indice es menor a 0 o mayor al len de la lista)
                        ( 0) Si funciono correctamente
 *
 */
int ll_push(LinkedList* this, int index, void* pElement)
{
    int returnAux = -1;
    int i;
    Node* nuevoNodo;

    nuevoNodo =(Node*) (malloc(sizeof(Node)));

    if(this != NULL && index>0 && index<ll_len(this))
        {
            for(i = 0; i< ll_len(this) ; i++)
                {
                    ll_get(this,i);
                    if(nuevoNodo != NULL)
                        {
                            if(index == i)
                                {
                                   addNode(this,index,pElement);
                                    returnAux = 0;
                                }
                        }
                }
        }
    return returnAux;
}


/** \brief Elimina el elemento de la posicion indicada y retorna su puntero
 *
 * \param this LinkedList* Puntero a la lista
 * \param nodeIndex int Ubicacion del elemento eliminar
 * \return void* Retorna    (NULL) Error: si el puntero a la lista es NULL o (si el indice es menor a 0 o mayor al len de la lista)
                            (pElement) Si funciono correctamente
 *
 */
void* ll_pop(LinkedList* this,int index)
{
    void* returnAux = NULL;
    Node* nodo;

    if(this != NULL && index>0 && index< ll_len(this))
        {
            nodo = getNode(this,index); //PIDO NODO A BORRAR
            returnAux = nodo->pElement;// REGRESO EL ELEMENTO
            ll_remove(this,index);    // BORRO EL NODO ELEGIDO

        }

    return returnAux;
}


/** \brief  Determina si la lista contiene o no el elemento pasado como parametro
 *
 * \param this LinkedList* Puntero a la lista
 * \param pElement void* Puntero del elemento a verificar
 * \return int Retorna  (-1) Error: si el puntero a la lista es NULL
                        ( 1) Si contiene el elemento
                        ( 0) si No contiene el elemento
*/
int ll_contains(LinkedList* this, void* pElement)
{
    int returnAux = -1;


    if (this!=NULL)
    {
        returnAux = ll_indexOf(this,pElement); //BUSCO EL INDICE DEL ELEMENTO
        if (returnAux ==-1)
        {
            returnAux =0; // NO LO ENCONTRO
        }
        else
        {
            returnAux =1; // SI LO ENCONTRO
        }
    }
    return returnAux;
}

/** \brief  Determina si todos los elementos de la lista (this2)
            estan contenidos en la lista (this)
 *
 * \param this LinkedList* Puntero a la lista
 * \param this2 LinkedList* Puntero a la lista
 * \return int Retorna  (-1) Error: si alguno de los punteros a las listas son NULL
                        ( 1) Si los elementos de (this2) estan contenidos en la lista (this)
                        ( 0) si los elementos de (this2) NO estan contenidos en la lista (this)
*/
int ll_containsAll(LinkedList* this,LinkedList* this2)
{
    int returnAux = -1;
    void* pElement;
    int i;

    if(this != NULL && this2 != NULL) //VERIFICO SI SON NULOS
    {
        returnAux = 1;
        for(i = 0; i < ll_len(this2); i++)
        {
            pElement = ll_get(this2,i); //RECORRO ELEMENTO DE LA LISTA 2
            if(ll_contains(this,pElement) == 0) //SI DA CERO NO ELEMENTO CONTENIDOS
            {
                returnAux = 0;
            }
        }
    }
    return returnAux;
}

/** \brief Crea y retorna una nueva lista con los elementos indicados
 *
 * \param pList LinkedList* Puntero a la lista
 * \param from int Indice desde el cual se copian los elementos en la nueva lista
 * \param to int Indice hasta el cual se copian los elementos en la nueva lista (no incluido)
 * \return LinkedList* Retorna  (NULL) Error: si el puntero a la listas es NULL
                                o (si el indice from es menor a 0 o mayor al len de la lista)
                                o (si el indice to es menor o igual a from o mayor al len de la lista)
                         (puntero a la nueva lista) Si ok
*/
LinkedList* ll_subList(LinkedList* this,int from,int to)
{
    LinkedList* cloneArray = NULL;
    int i;
    void* pElement;

    if(this != NULL && from >= 0 && from < ll_len(this) && to > from && to <= ll_len(this))
    {
        cloneArray = ll_newLinkedList(); // CREO NUEVA LINKEDLIST EN CLONE ARRAY
        for(i = from ; i < to; i++)
        {
            pElement = ll_get(this, i); // CONSIGO TODOS LOS ELEMENTO Y LOS GUARADO EN PELEMENT
            ll_add(cloneArray, pElement); // A�ADO LOS ELEMENTOS A LA PRIMERA LINKEDLIST
        }
    }


    return cloneArray;

}



/** \brief Crea y retorna una nueva lista con los elementos de la lista pasada como parametro
 *
 * \param pList LinkedList* Puntero a la lista
 * \return LinkedList* Retorna  (NULL) Error: si el puntero a la listas es NULL
                                (puntero a la nueva lista) Si ok
*/
LinkedList* ll_clone(LinkedList* this)
{
     LinkedList* cloneArray = NULL;
    if(this != NULL)
    {
        cloneArray = ll_newLinkedList(); //CREO LA NUEVA LISTA
        cloneArray = ll_subList(this, 0, ll_len(this)); //COPIO LA NUEVA LISTA DESDE EL PRINCIPIO AL FINAL
    }
    return cloneArray;
}


/** \brief Ordena los elementos de la lista utilizando la funcion criterio recibida como parametro
 * \param pList LinkedList* Puntero a la lista
 * \param pFunc (*pFunc) Puntero a la funcion criterio
 * \param order int  [1] Indica orden ascendente - [0] Indica orden descendente
 * \return int Retorna  (-1) Error: si el puntero a la listas es NULL
                                ( 0) Si ok
 */
int ll_sort(LinkedList* this, int (*pFunc)(void*,void*), int order)
{
    int returnAux =-1;
    void* pAux;



    return returnAux;
}

