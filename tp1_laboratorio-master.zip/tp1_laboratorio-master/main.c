#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{
    char seguir='s';
    int opcion=0;
    float a;
    float b;
    int flagA=0;
    int flagB=0;
    float suma;
    float resta;
    float division;
    float multiplicacion;
    long unsigned int factA;
    long unsigned int factB;



    while(seguir=='s')
    {
        if(flagA==0)
        {
            printf("1- Ingresar 1er operando (A=x)\n");
        }
        else
        {
            printf("1- Ingresar 1er operando  (A=%.3f)\n",a);
        }


        if(flagB==0)
        {
            printf("2- Ingresar 2do operando (B=y)\n");
        }
        else
        {
            printf("2- Ingresar 1do operando  (B=%.3f)\n",b);
        }
        printf("3- Calcular todas las operaciones\n");
        printf("4- informar resultados\n");
        printf("5- salir\n");

        printf("elija opcion del menu para proceder\n");
        scanf("%d", &opcion);

        system("cls");

        switch(opcion)
        {
        case 1 :
            a=pedirOperando("Ingrese primer operando\n");
            flagA=1;
            break;
        case 2 :
            b=pedirOperando("Ingrese segundo operando\n");
            flagB=1;
            break;
        case 3 :
            if(flagA==1 && flagB==0)
            {
                printf("ingrese operando B por favor\n");
            }
            else if(flagA==0 && flagB==1)
            {
                printf("ignrese operando A por vafor\n");
            }else if(flagA==1 && flagB==1)
            {
                suma=sumarValores(a, b);
                resta=restaValores(a, b);
                division=divisionValores(a,b);
                multiplicacion=multiplicarValores(a, b);
                printf("cuentas ya echas\n");

            }else
            {
                printf("ingrese operandos\n");
            }


            break;
        case 4 :
               if(flagA==1 && flagB==1){
            printf("el resutado de la suma es %.3f\n",suma);
            printf("el resutado de la resta es %.3f\n",resta);

            if(b==0 )
            {
                printf("ingrese divisor valido\n");
            }
            else
            {
                printf("el resutado de la division es %.3f\n",division);
            }

            printf("el resutado de la multiplicacion es %.3f\n",multiplicacion);

            if(a>12)
            {
                printf("ERROR A es mayor a 12 , se produce desbordamiento\n");
            }
            else if(a<1)
            {
                printf(" ERROR A es igual o menor a 0 ingrese numero nuevamente\n");
            }
            else
            {
                printf("el factorial de A es %lu\n",factorial(a));
            }


            if(b>12)
            {
                printf("ERROR B es mayor a 12 , se produce desbordamiento\n");
            }
            else if(b<1)
            {
                printf(" ERROR B es igual o menor a 0 ingrese numero nuevamente\n");
            }
            else
            {
                printf("el factorial de B es %lu\n",factorial(b));
            }
            }else
            {
                printf("haga calculos\n");
            }
            break;
        case 5 :
            seguir='n';
            break;
        default :
            printf("ingrese numero del menu\n");
            fflush(stdin);
        }//final swicht
    }//final while
    return 0;
}


