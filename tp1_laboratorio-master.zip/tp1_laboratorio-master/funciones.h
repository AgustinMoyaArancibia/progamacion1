/** \brief pide numero validandolo y una cadena de characteres
 *
 * \param un numero float y una cadena
 * \return numero
 *
 */
float pedirOperando(char mensaje[]);


/** \brief pide dos numeros float
 *
 * \param numero float
 * \param numero float
 * \return resultado suma
 *
 */
float sumarValores(float, float);


/** \brief pide dos numeros float
 *
 * \param numero float
 * \param numero float
 * \return resultado de la resta
 *
 */
float restaValores(float, float);


/** \brief pide dos numeros float
 *
 * \param numero float
 * \param numero float
 * \return regresa resultado de la division
 *
 */
 float divisionValores(float, float);


 /** \brief pide dos numeros float
  *
  * \param numeros float
   * \param numeros float
  * \return regresa resultado de la multiplicacion
  *
  */
  float multiplicarValores(float, float);



  /** \brief pide un numero long
   *
   * \param un numero float hasta 12
   * \return regresa resultado del factoreo
   *
   */
   unsigned long factorial(float a );


