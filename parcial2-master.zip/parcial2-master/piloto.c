#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "vuelos.h"
#include "parser.h"
#include "Controller.h"
#include "piloto.h"
#define TAMCARACTERES 50

int funcionListarPorNombrePiloto(void* element,char nombre[])
{
    ePilotos* listaPilotos;
    char NombrePiloto[TAMCARACTERES];
    int retorno =-1;


    if(element != NULL )
        {
            listaPilotos = (ePilotos*)element;


        ePilotos_getNombrePiloto(listaPilotos,NombrePiloto);

            if(strncmp(nombre,NombrePiloto,TAMCARACTERES)==0)
                {
                    retorno = 0;
                }
        }
return retorno;
}

int funcionVuelosSinAlex(void* element)
{
    ePilotos* listaPilotos;
    int idPiloto;
    int retorno =-100 ;// si no es alex
    if(element != NULL)
        {
            listaPilotos = (ePilotos*)element;
            ePilotos_getIdPiloto(listaPilotos,&idPiloto);
            if(idPiloto != 1)
                {
                    retorno = 100; //si no es alex
                }


        }

//Alex Lifeson

    return retorno;
}

int pilotos_imprimir(LinkedList* this)
{
    int retorno = -1;

    ePilotos* listaPilotos;
    int i;

    int idPiloto;
    char nombre[2000];
    int cantidad;


    cantidad = ll_len(this);

    if(this != NULL )
    {
        for(i=0 ; i<cantidad ; i++)
        {
            listaPilotos = ll_get(this,i);

            ePilotos_getIdPiloto(listaPilotos,&idPiloto);
            ePilotos_getNombrePiloto(listaPilotos,nombre);



//idVuelo,idAvion,idPiloto,fecha,destino,cantPasajeros,horaDespegue,horaLlegada

            printf("\nidPiloto: %d  nombre: %s  \n",idPiloto,nombre);
            printf("-----------------------------------------------");


            retorno = 0;
        }

    }

    return retorno;
}


ePilotos* pilotos_new()
{
    return (ePilotos*) malloc(sizeof(ePilotos));
}


ePilotos* pilotos_newParametros(char* idPiloto,char* nombre)
{
    ePilotos* listaPilotos = NULL;
    ePilotos* AuxListaPilotos;

    int idPilotoAux;

    listaPilotos = pilotos_new();

    if(listaPilotos != NULL )
    {
        idPilotoAux = atoi(idPiloto);//CONVIERTO LAS CADENAS A ENTEROS

        if(!ePilotos_setIdPiloto(listaPilotos,idPilotoAux)&&
           !ePilotos_setNombrePiloto(listaPilotos,nombre))
        {
            AuxListaPilotos = listaPilotos;
        }
    }
    return AuxListaPilotos;

}


int ePilotos_setIdPiloto(ePilotos* listaPilotos,int idPiloto)
{
    int retorno = -1;

    if(listaPilotos != NULL && idPiloto >= 0)
    {
        listaPilotos->idPiloto = idPiloto;
        retorno = 0;
    }

    return retorno;
}
int ePilotos_getIdPiloto(ePilotos* listaPilotos,int* idPiloto)
{
    int retorno = -1;

    if(listaPilotos != NULL && idPiloto >= 0)
    {
        *idPiloto =  listaPilotos->idPiloto;
        retorno = 0;
    }

    return retorno;
}

int ePilotos_setNombrePiloto(ePilotos* listaPilotos,char* nombre)
{
    int retorno = -1;

    if(listaPilotos != NULL && nombre != NULL)
    {
        strncpy(listaPilotos->nombrePiloto, nombre,TAMCARACTERES);
        retorno = 0;
    }

    return retorno;
}

int ePilotos_getNombrePiloto(ePilotos* listaPilotos,char* nombre)
{
    int retorno = -1;

    if(listaPilotos != NULL && nombre != NULL)
    {
        strncpy(nombre, listaPilotos->nombrePiloto,TAMCARACTERES);
        retorno = 0;
    }

    return retorno;
}
