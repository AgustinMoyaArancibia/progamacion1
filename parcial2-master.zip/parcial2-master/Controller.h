int controller_loadFromText(char* path, LinkedList* this);
int controller_loadFromTextPilotos(char* path, LinkedList* this);
int controller_ListarVuelos(LinkedList* this, LinkedList* pilotos);
int controller_ListarPilotos(LinkedList* this);
int controller_loadFromTextPilotos(char* path, LinkedList* this);
int controller_ListarPilotos(LinkedList* this);
int controller_GuardfiltroVuelosCortosTxt(char* direccion, LinkedList* this);
int controller_pasajerosAirlanda(LinkedList* this);
LinkedList* controller_vuelosCortos(LinkedList* this);
int controller_ListarVuelosPortugal(LinkedList* this, LinkedList* pilotos);
int controller_ListarVueloSinAlex(LinkedList* this, LinkedList* pilotos);






