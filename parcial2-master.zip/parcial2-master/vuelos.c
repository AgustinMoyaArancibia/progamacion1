#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "vuelos.h"
#include "piloto.h"
#include "parser.h"

#define TAMCARACTERES 50

int vuelos_imprimirPilotoPorNombre( LinkedList* Piloto)
{
    int retorno = -1;
    LinkedList* newPiltos;  //CREO UNA LL PARA USAR CON PILOTOS
    ePilotos* listaPilotos;
    int i;

    int idPilotoPiloto;
    char nombrePiloto[200];
    int cantidad;

    if(Piloto != NULL )
    {
         // USO EL FILTRO PARA SACAR A ALEX DE VUELOS
        pilotos_imprimir(Piloto);

        newPiltos = ll_filter_parametro(Piloto,funcionListarPorNombrePiloto); // USO EL FILTRO PARA SCAR A ALEX DE PILOTOS


        if(newPiltos !=NULL )
        {
             // SACO TAMANIO
            cantidad = ll_len(Piloto);
            for(i=0 ; i<cantidad ; i++) //FOR PARA LA LISTA DE VUELOS
            {


                    listaPilotos = ll_get(newPiltos,i); //CONSIGO TODOS LOS ELEMENTOS DE PILOTO SIN ALEX
                    ePilotos_getIdPiloto(listaPilotos,&idPilotoPiloto);
                    ePilotos_getNombrePiloto(listaPilotos,nombrePiloto);

                printf("\n nombrePiloto: %s   ID: %d   \n"
                       , nombrePiloto,idPilotoPiloto);
                printf("----------------------------------------------------------------------------------------------------------------------------------------------");


                retorno = 0;
            }

        }
    }

    return retorno;
}

int vuelos_imprimirVuelosSinAlex(LinkedList* this, LinkedList* Piloto)
{
    int retorno = -1;
    LinkedList* sinAlex; //CREO UN LL PARA CON VUELOS
    LinkedList* sinAlexId;  //CREO UNA LL PARA USAR CON PILOTOS
    eVuelos* listaVuelos;
    ePilotos* listaPilotos;
    int i;
    int idVuelo;
    int idAvion;
    int idPiloto;
    int cantidadPasajeros;
    int horaDespegue;
    int horaLlegada;
    int cantidad;
    char destino[2000];
    char fecha[200];
    int idPilotoPiloto;
    char nombrePiloto[200];
    int cantidadPiloto;
    int j;



    if(this != NULL && Piloto != NULL )
    {
        sinAlex = ll_filter(this,funcionVuelosSinAlex); // USO EL FILTRO PARA SACAR A ALEX DE VUELOS
        sinAlexId = ll_filter(Piloto,funcionVuelosSinAlex); // USO EL FILTRO PARA SCAR A ALEX DE PILOTOS


        if(sinAlex !=NULL && sinAlexId != NULL)
        {
            cantidad = ll_len(sinAlex); // SACO TAMANIO
            cantidadPiloto = ll_len(Piloto);
            for(i=0 ; i<cantidad ; i++) //FOR PARA LA LISTA DE VUELOS
            {
                listaVuelos = ll_get(sinAlex,i);//CONSIGO TODOS LOS ELEMENTOS DE VUELOS SIN ALEX


                eVuelos_getIdVuelos(listaVuelos,&idVuelo);
                eVuelos_getIdAvion(listaVuelos,&idAvion);
                eVuelos_getIdPiloto(listaVuelos,&idPiloto);
                eVuelos_getFecha(listaVuelos,fecha);
                eVuelos_getDestino(listaVuelos,destino);
                eVuelos_getCantidadPasajeros(listaVuelos,&cantidadPasajeros);
                eVuelos_gethoraDespegue(listaVuelos,&horaDespegue);
                eVuelos_gethoraLlegada(listaVuelos,&horaLlegada);
                for(j=0 ; j<cantidadPiloto ; j++) // FOR PARA PILOTOS
                {
                    listaPilotos = ll_get(sinAlexId,j); //CONSIGO TODOS LOS ELEMENTOS DE PILOTO SIN ALEX
                    ePilotos_getIdPiloto(listaPilotos,&idPilotoPiloto);
                    if(idPiloto == idPilotoPiloto) //CONSIGO TODOS LOS ID
                    {
                        ePilotos_getNombrePiloto(listaPilotos,nombrePiloto);
                    }

                }

                printf("\nidVuelo: %d   idAvion: %d nombrePiloto: %s  fecha: %s  destino: %s  cantidadPasajeros: %d  horaDespegue: %d horallegada: %d \n"
                       , idVuelo, idAvion, nombrePiloto,fecha,destino,cantidadPasajeros, horaDespegue, horaLlegada);
                printf("----------------------------------------------------------------------------------------------------------------------------------------------");


                retorno = 0;
            }

        }
    }

    return retorno;
}


int vuelos_imprimirVuelosPortugal(LinkedList* this, LinkedList* Piloto)
{
    int retorno = -1;

    eVuelos* listaVuelos;
    ePilotos* listaPilotos;
    int i;
    int idVuelo;
    int idAvion;
    int idPiloto;
    int cantidadPasajeros;
    int horaDespegue;
    int horaLlegada;
    int cantidad;
    char destino[2000];
    char fecha[200];
    int idPilotoPiloto;
    char nombrePiloto[200];
    int cantidadPiloto;
    int j;
    cantidad = ll_len(this);
    cantidadPiloto = ll_len(Piloto);

    if(this != NULL )
    {
        for(i=0 ; i<cantidad ; i++) //FOR PARA LA LISTA DE VUELOS
        {
            listaVuelos = ll_get(this,i);//CONSIGO TODOS LOS ELEMENTOS DE VUELOS


            eVuelos_getIdVuelos(listaVuelos,&idVuelo);
            eVuelos_getIdAvion(listaVuelos,&idAvion);
            eVuelos_getIdPiloto(listaVuelos,&idPiloto);
            eVuelos_getFecha(listaVuelos,fecha);
            eVuelos_getDestino(listaVuelos,destino);
            eVuelos_getCantidadPasajeros(listaVuelos,&cantidadPasajeros);
            eVuelos_gethoraDespegue(listaVuelos,&horaDespegue);
            eVuelos_gethoraLlegada(listaVuelos,&horaLlegada);
            for(j=0 ; j<cantidadPiloto ; j++) // FOR PARA PILOTOS
            {
                listaPilotos = ll_get(Piloto,j); //CONSIGO TODOS LOS ELEMENTOS DE PILOTO
                ePilotos_getIdPiloto(listaPilotos,&idPilotoPiloto);
                if(idPiloto == idPilotoPiloto )
                {
                    ePilotos_getNombrePiloto(listaPilotos,nombrePiloto);
                }
            }
            if(strcmp(destino,"Portugal")==0)
            {
                printf("\nidVuelo: %d   idAvion: %d nombrePiloto: %s  fecha: %s  destino: %s  cantidadPasajeros: %d  horaDespegue: %d horallegada: %d \n"
                       , idVuelo, idAvion, nombrePiloto,fecha,destino,cantidadPasajeros, horaDespegue, horaLlegada);
                printf("----------------------------------------------------------------------------------------------------------------------------------------------");
            }

            retorno = 0;
        }

    }

    return retorno;
}

int eVuelos_guardarArchivoTxtVuelosCortos(char* direccionArchivo, LinkedList* this)
{
    int i;
    int cantidad;
    int retorno = -1;
    FILE* pFile;
    eVuelos* listaVuelos;
    int idVuelo;
    int idAvion;
    int idPiloto;
    int cantidadPasajeros;
    int horaDespegue;
    int horaLlegada;
    char destino[2000];
    char fecha[200];

    cantidad = ll_len(this);
    pFile = fopen(direccionArchivo, "w");

    if(pFile != NULL && direccionArchivo !=NULL)
    {

        for(i = 0; i < cantidad; i++)
        {
            listaVuelos = ll_get(this, i);
            if(listaVuelos != NULL)
            {
                eVuelos_getIdVuelos(listaVuelos,&idVuelo);
                eVuelos_getIdAvion(listaVuelos,&idAvion);
                eVuelos_getIdPiloto(listaVuelos,&idPiloto);
                eVuelos_getFecha(listaVuelos,fecha);
                eVuelos_getDestino(listaVuelos,destino);
                eVuelos_getCantidadPasajeros(listaVuelos,&cantidadPasajeros);
                eVuelos_gethoraDespegue(listaVuelos,&horaDespegue);
                eVuelos_gethoraLlegada(listaVuelos,&horaLlegada);

                fprintf(pFile,"%d," "%d," "%d," "%s," "%s," "%d," "%d," "%d, \n",idVuelo, idAvion, idPiloto,fecha,destino,cantidadPasajeros, horaDespegue, horaLlegada);

            }
        }

        retorno = 0;
        fclose(pFile);
    }
    return retorno;

}

int vuelosMenosAtresHoras(void* element)
{
    eVuelos* listaVuelos;
    int horaDespegue;
    int horaLlegada;
    int flag = -100; // -100 SI ESTA MAL

    if(element!= NULL)
    {
        listaVuelos = (eVuelos*)element; //IGUALO PUNTERO VUELOS CON EL ELEMENTO PASADO COMO PARAMETRO
        eVuelos_gethoraLlegada(listaVuelos,&horaLlegada);
        eVuelos_gethoraDespegue(listaVuelos,&horaDespegue);

        if(horaLlegada-horaDespegue == -2 || horaLlegada-horaDespegue == -1 || horaLlegada-horaDespegue == 0 ||
                horaLlegada-horaDespegue == 1 || horaLlegada-horaDespegue == 2)
        {
            flag = 100; //100 PARA TODO OK
        }


    }
    return flag;
}



int funcionContarPasajeros(void* element)
{
    eVuelos* listaVuelos ;


    int acumulador = 0;

    if(element != NULL)
    {
        listaVuelos = (eVuelos*)element; //IGUALO PUNTERO VUELOS CON EL ELEMENTO PASADO COMO PARAMETRO
        eVuelos_getCantidadPasajeros(listaVuelos,&acumulador);//GUARDO LA CANTIDAD DE PASAJEROS EN ACUMULADOR
    }



    return acumulador;
}

int funcionContarPasajerosIrlanda(void* element)
{
    eVuelos* listaVuelos ;
    char destino[TAMCARACTERES];

    int acumulador = 0;

    if(element != NULL)
    {
        listaVuelos = (eVuelos*)element; //IGUALO PUNTERO VUELOS CON EL ELEMENTO PASADO COMO PARAMETRO
        eVuelos_getDestino(listaVuelos,destino); //GUARDO DATOS EN DESTINO
        if(strcmp(destino, "Irlanda")==0) // SI ALGUN DESTINO ES IGUAL A IRLANDA
        {
            eVuelos_getCantidadPasajeros(listaVuelos,&acumulador); //PIDO LA  CANTIDAD DE PASAJEROS DE ESE ELEMNTO Y LO GUARDO EN ACUMULADOR

        }
    }



    return acumulador;
}

eVuelos* vuelos_new()
{
    return (eVuelos*) malloc(sizeof(eVuelos));
}


eVuelos* vuelos_newParametros(char* idVueloAux,char* idAvionAux,char* idPilotoAux,char*  fechaAux,char* destinoAux,char* cantidadPasajerosAux,char* horaDespegueAux,char* horaLegadaAux)
{
    eVuelos* listaVuelos = NULL;
    eVuelos* AuxListaVuelos;

    int idVuelo;
    int idAvion;
    int idPiloto;
    int cantidadPasajeros;
    int horaDespegue;
    int horallegada;

    listaVuelos = vuelos_new();

    if(listaVuelos != NULL )
    {
        idVuelo = atoi(idVueloAux); //CONVIERTO LAS CADENAS A ENTEROS
        idAvion = atoi(idAvionAux);
        idPiloto = atoi(idPilotoAux);
        cantidadPasajeros = atoi(cantidadPasajerosAux);
        horaDespegue = atoi(horaDespegueAux);
        horallegada = atoi(horaLegadaAux);
//idVuelo,idAvion,idPiloto,fecha,destino,cantPasajeros,horaDespegue,horaLlegada
        if(!eVuelos_setIdVuelos(listaVuelos,idVuelo)&&
                !eVuelos_setIdAvion(listaVuelos,idAvion)&&
                !eVuelos_setIdPiloto(listaVuelos,idPiloto)&&
                !eVuelos_setFecha(listaVuelos,fechaAux)&&
                !eVuelos_setDestino(listaVuelos,destinoAux)&&
                !eVuelos_setCantidadPasajeros(listaVuelos,cantidadPasajeros)&&
                !eVuelos_sethoraDespegue(listaVuelos,horaDespegue)&&
                !eVuelos_sethoraLlegada(listaVuelos,horallegada))
        {
            AuxListaVuelos = listaVuelos;
        }
    }
    return AuxListaVuelos;

}

int vuelos_imprimir(LinkedList* this, LinkedList* Piloto)
{
    int retorno = -1;

    eVuelos* listaVuelos;
    ePilotos* listaPilotos;
    int i;
    int idVuelo;
    int idAvion;
    int idPiloto;
    int cantidadPasajeros;
    int horaDespegue;
    int horaLlegada;
    int cantidad;
    char destino[2000];
    char fecha[200];
    int idPilotoPiloto;
    char nombrePiloto[200];
    int cantidadPiloto;
    int j;
    cantidad = ll_len(this);
    cantidadPiloto = ll_len(Piloto);

    if(this != NULL )
    {
        for(i=0 ; i<cantidad ; i++) //FOR PARA LA LISTA DE VUELOS
        {
            listaVuelos = ll_get(this,i);//CONSIGO TODOS LOS ELEMENTOS DE VUELOS


            eVuelos_getIdVuelos(listaVuelos,&idVuelo);
            eVuelos_getIdAvion(listaVuelos,&idAvion);
            eVuelos_getIdPiloto(listaVuelos,&idPiloto);
            eVuelos_getFecha(listaVuelos,fecha);
            eVuelos_getDestino(listaVuelos,destino);
            eVuelos_getCantidadPasajeros(listaVuelos,&cantidadPasajeros);
            eVuelos_gethoraDespegue(listaVuelos,&horaDespegue);
            eVuelos_gethoraLlegada(listaVuelos,&horaLlegada);
            for(j=0 ; j<cantidadPiloto ; j++) // FOR PARA PILOTOS
            {
                listaPilotos = ll_get(Piloto,j); //CONSIGO TODOS LOS ELEMENTOS DE PILOTO
                ePilotos_getIdPiloto(listaPilotos,&idPilotoPiloto);
                if(idPiloto == idPilotoPiloto)
                {
                    ePilotos_getNombrePiloto(listaPilotos,nombrePiloto);
                }
            }

            printf("\nidVuelo: %d   idAvion: %d nombrePiloto: %s  fecha: %s  destino: %s  cantidadPasajeros: %d  horaDespegue: %d horallegada: %d \n"
                   , idVuelo, idAvion, nombrePiloto,fecha,destino,cantidadPasajeros, horaDespegue, horaLlegada);
            printf("----------------------------------------------------------------------------------------------------------------------------------------------");
            retorno = 0;
        }

    }

    return retorno;
}

/**************************************************************************************************/

int eVuelos_sethoraLlegada(eVuelos* listaVuelos,int horaLlegada)
{
    int retorno = -1;

    if(listaVuelos != NULL && horaLlegada >= 0)
    {
        listaVuelos->horaLlegada = horaLlegada;
        retorno = 0;
    }

    return retorno;
}
int eVuelos_gethoraLlegada(eVuelos* listaVuelos,int* horaLlegada)
{
    int retorno = -1;

    if(listaVuelos != NULL && horaLlegada >= 0)
    {
        *horaLlegada =  listaVuelos->horaLlegada;
        retorno = 0;
    }

    return retorno;
}

int eVuelos_sethoraDespegue(eVuelos* listaVuelos,int horaDespegue)
{
    int retorno = -1;

    if(listaVuelos != NULL && horaDespegue >= 0)
    {
        listaVuelos->horaDespegue = horaDespegue;
        retorno = 0;
    }

    return retorno;
}
int eVuelos_gethoraDespegue(eVuelos* listaVuelos,int* horaDespegue)
{
    int retorno = -1;

    if(listaVuelos != NULL && horaDespegue >= 0)
    {
        *horaDespegue =  listaVuelos->horaDespegue;
        retorno = 0;
    }

    return retorno;
}

int eVuelos_setCantidadPasajeros(eVuelos* listaVuelos,int cantidadPasajeros)
{
    int retorno = -1;

    if(listaVuelos != NULL && cantidadPasajeros >= 0)
    {
        listaVuelos->cantPasajeros = cantidadPasajeros;
        retorno = 0;
    }

    return retorno;
}
int eVuelos_getCantidadPasajeros(eVuelos* listaVuelos,int* cantidadPasajeros)
{
    int retorno = -1;

    if(listaVuelos != NULL && cantidadPasajeros >= 0)
    {
        *cantidadPasajeros =  listaVuelos->cantPasajeros;
        retorno = 0;
    }

    return retorno;
}

int eVuelos_setIdPiloto(eVuelos* listaVuelos,int idPiloto)
{
    int retorno = -1;

    if(listaVuelos != NULL && idPiloto >= 0)
    {
        listaVuelos->idPilotos = idPiloto;
        retorno = 0;
    }

    return retorno;
}
int eVuelos_getIdPiloto(eVuelos* listaVuelos,int* idPiloto)
{
    int retorno = -1;

    if(listaVuelos != NULL && idPiloto >= 0)
    {
        *idPiloto =  listaVuelos->idPilotos;
        retorno = 0;
    }

    return retorno;
}



int eVuelos_setIdAvion(eVuelos* listaVuelos,int idAvion)
{
    int retorno = -1;

    if(listaVuelos != NULL && idAvion >= 0)
    {
        listaVuelos->idAvion = idAvion;
        retorno = 0;
    }

    return retorno;
}
int eVuelos_getIdAvion(eVuelos* listaVuelos,int* idAvion)
{
    int retorno = -1;

    if(listaVuelos != NULL && idAvion >= 0)
    {
        *idAvion =  listaVuelos->idAvion;
        retorno = 0;
    }

    return retorno;
}



int eVuelos_setDestino(eVuelos* listaVuelos,char* destino)
{
    int retorno = -1;

    if(listaVuelos != NULL && destino != NULL)
    {
        strncpy(listaVuelos->destino, destino,TAMCARACTERES);
        retorno = 0;
    }

    return retorno;
}

int eVuelos_getDestino(eVuelos* listaVuelos,char* destino)
{
    int retorno = -1;

    if(listaVuelos != NULL && destino != NULL)
    {
        strncpy(destino, listaVuelos->destino,TAMCARACTERES);
        retorno = 0;
    }

    return retorno;
}

int eVuelos_setIdVuelos(eVuelos* listaVuelos,int idVuelos)
{
    int retorno = -1;

    if(listaVuelos != NULL && idVuelos >= 0)
    {
        listaVuelos->idVueldo = idVuelos;
        retorno = 0;
    }

    return retorno;
}
int eVuelos_getIdVuelos(eVuelos* listaVuelos,int* idVuelos)
{
    int retorno = -1;

    if(listaVuelos != NULL && idVuelos >= 0)
    {
        *idVuelos =  listaVuelos->idVueldo;
        retorno = 0;
    }

    return retorno;
}


int eVuelos_setFecha(eVuelos* listaVuelos,char* fecha)
{
    int retorno = -1;

    if(listaVuelos != NULL && fecha != NULL)
    {
        strncpy(listaVuelos->fecha, fecha,TAMCARACTERES);
        retorno = 0;
    }

    return retorno;
}

int eVuelos_getFecha(eVuelos* listaVuelos,char* fecha)
{
    int retorno = -1;

    if(listaVuelos != NULL && fecha != NULL)
    {
        strncpy(fecha, listaVuelos->fecha,TAMCARACTERES);
        retorno = 0;
    }

    return retorno;
}
