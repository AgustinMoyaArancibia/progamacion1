#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "vuelos.h"
#include "piloto.h"
#include "parser.h"
#include "Controller.h"

 /*int controller_Moya_ListaPorNombreApedido(LinkedList* thisPiloto)
{
   int retorno = -1;
    if(!vuelos_imprimirPilotoPorNombre(thisPiloto))
        {
            printf("lista\n");
        }else
        {
            printf("no hay nada que mostrar\n");
        }



    return retorno;
}*/

int controller_pasajerosTotal(LinkedList* this)
{
    int retorno =-1;
    int totalPasajeros=0;

    if(this != NULL)
        {
            totalPasajeros = ll_count(this,funcionContarPasajeros);

        }else
        {
            printf("no hay vuelos ");
        }

    printf("pasajeros  :%d\n", totalPasajeros);

    return retorno;
}

int controller_ListarVueloSinAlex(LinkedList* this, LinkedList* pilotos)
{
    int retorno = -1;

    if(!vuelos_imprimirVuelosSinAlex(this,pilotos))
    {
        printf("\nlista de vuelos\n");
    }
    else
    {
        printf("ERRRRRRORRRR");
    }

    return retorno;
}

int controller_ListarVuelosPortugal(LinkedList* this, LinkedList* pilotos)
{
    int retorno = -1;

    if(!vuelos_imprimirVuelosPortugal(this,pilotos))
    {
        printf("\nlista de vuelos\n");
    }
    else
    {
        printf("ERRRRRRORRRR");
    }

    return retorno;
}

LinkedList* controller_vuelosCortos(LinkedList* this)
{

    LinkedList* thisVuelosCortos;

    if(this != NULL )
        {
            thisVuelosCortos = ll_filter(this,vuelosMenosAtresHoras);
        }
    if( thisVuelosCortos != NULL)
        {
            controller_GuardfiltroVuelosCortosTxt("VuelosCortos.csv",thisVuelosCortos);
        }

    return thisVuelosCortos;
}

int controller_pasajerosAirlanda(LinkedList* this)
{
    int retorno =-1;
    int totalPasajerosIrlanda=0;

    if(this != NULL)
        {
            totalPasajerosIrlanda = ll_count(this,funcionContarPasajerosIrlanda);

        }else
        {
            printf("no hay vuelos a irlanda");
        }

    printf("pasajeros de irlanda :%d\n", totalPasajerosIrlanda);

    return retorno;
}

int controller_GuardfiltroVuelosCortosTxt(char* direccion, LinkedList* this)
{
    int retorno =-1;

    if(!eVuelos_guardarArchivoTxtVuelosCortos(direccion,this))
    {
        printf("datos guardadosOK\n");
        retorno = 0;
    }
    else
    {
        printf("ALGO ANDA MAL\n");
    }

    return retorno;
}

int controller_loadFromTextPilotos(char* path, LinkedList* this)
{
    int retorno = -1;
    FILE* pFile;
    pFile = fopen(path, "r");

    if(pFile != NULL && parser_PilotosFromText(pFile, this) == 0)
    {
        printf("\nDatos cargados ");
        system("pause");
        retorno = 0;
    }
    else
    {
        printf("\nError al cargar datos.");
        system("pause");
    }

    fclose(pFile);

    return retorno;
}

int controller_loadFromText(char* path, LinkedList* this)
{
    int retorno = -1;
    FILE* pFile;
    pFile = fopen(path, "r");

    if(pFile != NULL && parser_VuelosFromText(pFile, this) == 0)
    {
        printf("\nDatos cargados ");
        system("pause");
        retorno = 0;
    }
    else
    {
        printf("\nError al cargar datos.");
        system("pause");
    }

    fclose(pFile);

    return retorno;
}

int controller_ListarPilotos(LinkedList* this)
{
    int retorno = -1;

    if(!pilotos_imprimir(this))
    {
        printf("\nOK\n");
    }
    else
    {
        printf("ERRRRRRORRRR");
    }

    return retorno;
}

int controller_ListarVuelos(LinkedList* this, LinkedList* pilotos)
{
    int retorno = -1;

    if(!vuelos_imprimir(this,pilotos))
    {
        printf("\nlista de vuelos\n");
    }
    else
    {
        printf("ERRRRRRORRRR");
    }

    return retorno;
}

/*
int controller_loadFromBinary(char* path, LinkedList* pArrayListEmployee)
{
return 1;
}


int controller_addEmployee(LinkedList* pArrayListEmployee)
{
int retorno = -1;

    if(!employee_alta(pArrayListEmployee))
        {
            printf("ALTA CORRECTA\n");
            retorno = 1;
            system("pause");
        }else
        {
            printf("ALGO ANDA MAL\n");
            retorno = -1;
        }


return retorno;
}


int controller_editEmployee(LinkedList* pArrayListEmployee)
{
return 1;
}


int controller_removeEmployee(LinkedList* pArrayListEmployee)
{
return 1;
}





int controller_sortEmployee(LinkedList* pArrayListEmployee)
{
return 1;
}


int controller_saveAsText(char* path, LinkedList* pArrayListEmployee)
{
int retorno =-1;

if(employee_guardarArchivoTxt(path,pArrayListEmployee)==1)
    {
        printf("datos guardadosOK\n");
        retorno = 0;
    }else
    {
        printf("ALGO ANDA MAL\n");
    }

return retorno;
}


*/
