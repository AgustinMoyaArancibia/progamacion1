
ePilotos* pilotos_new();
ePilotos* pilotos_newParametros(char* idPiloto,char* nombre);
int pilotos_imprimir(LinkedList* this);
int funcionVuelosSinAlex(void* element);
/*******************************************************************************/
int ePilotos_setIdPiloto(ePilotos* listaPilotos,int idPiloto);
int ePilotos_getIdPiloto(ePilotos* listaPilotos,int* idPiloto);
int ePilotos_setNombrePiloto(ePilotos* listaPilotos,char* nombre);
int ePilotos_getNombrePiloto(ePilotos* listaPilotos,char* nombre);

