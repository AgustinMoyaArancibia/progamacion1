int parser_VuelosFromText(FILE* pFile, LinkedList* this);
int parser_PilotosFromText(FILE* pFile, LinkedList* this);

