#define TAMCARACTERES 50

typedef struct
{
    int dia;
    int mes;
    int anio;
}eFechaVuelos;

typedef struct
{
    int idVueldo;
    int idAvion;
    int idPilotos;
    char fecha[TAMCARACTERES];
    char destino[TAMCARACTERES];
    int cantPasajeros;
    int horaDespegue;
    int horaLlegada;
}eVuelos;



typedef struct
{
    int idPiloto;
    char nombrePiloto[TAMCARACTERES];

}ePilotos;


eVuelos* vuelos_new();
eVuelos* vuelos_newParametros(char* idVueloAux,char* idAvionAux,char* idPilotoAux,char*  fechaAux,char* destinoAux,char* cantidadPasajerosAux,char* horaDespegueAux,char* horaLegadaAux);
//int vuelos_imprimir(LinkedList* this);
int vuelos_imprimir(LinkedList* this, LinkedList* Piloto);
int vuelos_imprimirVuelosPortugal(LinkedList* this, LinkedList* Piloto);
int funcionContarPasajeros(void* element);
int funcionContarPasajerosIrlanda(void* element);
int vuelosMenosAtresHoras(void* element);
int eVuelos_guardarArchivoTxtVuelosCortos(char* direccionArchivo, LinkedList* this);
int vuelos_imprimirVuelosSinAlex(LinkedList* this, LinkedList* Piloto);
int funcionListarPorNombrePiloto(void* element,char nombre[]);
/**************************************************************************************************/
int eVuelos_setFecha(eVuelos* listaVuelos,char* fecha);
int eVuelos_getFecha(eVuelos* listaVuelos,char* fecha);
int eVuelos_sethoraLlegada(eVuelos* listaVuelos,int horaLlegada);
int eVuelos_gethoraLlegada(eVuelos* listaVuelos,int* horaLlegada);
int eVuelos_sethoraDespegue(eVuelos* listaVuelos,int horaDespegue);
int eVuelos_gethoraDespegue(eVuelos* listaVuelos,int* horaDespegue);
int eVuelos_setCantidadPasajeros(eVuelos* listaVuelos,int cantidadPasajeros);
int eVuelos_getCantidadPasajeros(eVuelos* listaVuelos,int* cantidadPasajeros);
int eVuelos_setIdPiloto(eVuelos* listaVuelos,int idPiloto);
int eVuelos_getIdPiloto(eVuelos* listaVuelos,int* idPiloto);
int eVuelos_setIdAvion(eVuelos* listaVuelos,int idAvion);
int eVuelos_getIdAvion(eVuelos* listaVuelos,int* idAvion);
int eVuelos_setDestino(eVuelos* listaVuelos,char* destino);
int eVuelos_getDestino(eVuelos* listaVuelos,char* destino);
int eVuelos_setIdVuelos(eVuelos* listaVuelos,int idVuelos);
int eVuelos_getIdVuelos(eVuelos* listaVuelos,int* idVuelos);
