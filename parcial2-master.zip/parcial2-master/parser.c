#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "vuelos.h"
#include "parser.h"
#include "piloto.h"
#define TAMCARACTERES 50

int parser_PilotosFromText(FILE* pFile, LinkedList* this)
{
    ePilotos* listaPilotos;

    char idPiloto[2000];
    char nombre[2000];

    int cant;
    int retorno = -1;

    pFile = fopen("Pilotos.csv", "r");

    if(pFile!= NULL)
    {

        cant = fscanf(pFile,"%[^,],%[^\n]\n",idPiloto, nombre );

        while(!feof(pFile))
        {

        cant = fscanf(pFile,"%[^,],%[^\n]\n",idPiloto, nombre );


            if(cant == 2)
            {
                listaPilotos = pilotos_newParametros(idPiloto, nombre );

                if(listaPilotos != NULL)
                {
                    ll_add(this, listaPilotos);
                    retorno = 0;
                }
            }
        }
    }


    return retorno;

}

int parser_VuelosFromText(FILE* pFile, LinkedList* this)
{
    eVuelos* listVuelos;
    char idVuelo[2000];
    char idAvion[2000];
    char idPiloto[2000];
    char destino[2000];
    char cantidadPasajeros[2000];
    char horaDespegue[2000];
    char horaLlegada[2000];
    char fecha[200];
    int cant;
    int retorno = -1;

    pFile = fopen("Vuelos.csv", "r");

    if(pFile!= NULL)
    {

        cant = fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^\n]\n", idVuelo, idAvion, idPiloto, fecha,destino,cantidadPasajeros, horaDespegue, horaLlegada );

        while(!feof(pFile))
        {

        cant = fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^\n]\n", idVuelo, idAvion, idPiloto, fecha,destino,cantidadPasajeros, horaDespegue, horaLlegada );


            if(cant == 8)
            {
                listVuelos = vuelos_newParametros(idVuelo, idAvion, idPiloto,fecha,destino,cantidadPasajeros, horaDespegue, horaLlegada);

                if(listVuelos != NULL)
                {
                    ll_add(this, listVuelos);
                    retorno = 0;
                }
            }
        }
    }


    return retorno;

}
