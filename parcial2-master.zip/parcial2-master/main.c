#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "vuelos.h"
#include "parser.h"
#include "Controller.h"
#include "piloto.h"
#define TAMCARACTERES 50

int opcionesMenu();
int main()
{

    char seguir = 's';

    LinkedList* thisVuelos = ll_newLinkedList();
    LinkedList* thisPiloto = ll_newLinkedList();

    do
    {
        switch(opcionesMenu())
        {
        case 1:
            if(ll_isEmpty(thisVuelos) ==1 )
                {
                     controller_loadFromText("Vuelos.csv",thisVuelos);
                    controller_loadFromTextPilotos("Pilotos.csv", thisPiloto);
                }else
                {
                    printf("ya hay algo cargado\n");
                }
            system("pause");
            break;
        case 2:
            if(ll_isEmpty(thisVuelos)==1)
                {
                    printf("no hay nada cargado\n");
                }else
                {
                     controller_ListarVuelos(thisVuelos,thisPiloto);
                }


            system("pause");
            break;
        case 3:
            if(ll_isEmpty(thisVuelos)==1 && ll_isEmpty(thisPiloto) == 1)
                {
                    printf("no hay nada cargado\n");
                }else
                {
                     controller_ListarPilotos(thisPiloto);
                    controller_pasajerosTotal(thisVuelos);
                }

            system("pause");
            break;
        case 4:
            if(ll_isEmpty(thisVuelos)==1)
                {
                    printf("no hay nada cargado\n");
                }else
                {

                controller_pasajerosAirlanda(thisVuelos);
                }

            system("pause");
            break;
        case 5:
            if(ll_isEmpty(thisVuelos)==1)
                {
                    printf("no hay nada cargado\n");
                }else
                {
                    controller_vuelosCortos(thisVuelos);
                }

            system("pause");
            break;
        case 6:
            if(ll_isEmpty(thisVuelos)==1 && ll_isEmpty(thisPiloto) == 1)
                {
                    printf("no hay nada cargado\n");
                }else
                {
                    controller_ListarVuelosPortugal(thisVuelos,thisPiloto);
                }

            system("pause");
            break;
        case 7:
            if(ll_isEmpty(thisVuelos)==1 && ll_isEmpty(thisPiloto) == 1)
                {
                    printf("no hay nada cargado\n");
                }else
                {
                  controller_ListarVueloSinAlex(thisVuelos,thisPiloto);
                }

            system("pause");;
            break;
        case 8:
            controller_Moya_ListaPorNombreApedido(thisPiloto);
            system("pause");

            break;
        case 9:
            printf("Salir");
            system("pause");
            seguir = 'n';
            break;

        }

    }
    while(seguir == 's');


    return 0;
}

/** \brief Lista el menu de opciones y pide la respuesta a ingresar mediante un menu y la retorna
 *
 * \return int respuesta
 * \return char* mensaje
 * \return char* mensajeError
 */
int opcionesMenu()
{
    int respuesta;

    system("cls");
    printf("\n\n 1. Cargar los datos de los empleados desde el archivo data.csv (modo texto)");
    printf("\n 2. imprimir vuelos");
    printf("\n 3. Cantidad de pasajeros");
    printf("\n 4. Cantidad de pasajeros  a Irlanda");
    printf("\n 5. Filtrar vuelos cortos");
    printf("\n 6. Listar vuelos a Portugal");
    printf("\n 7. vuelos sin alex");
    printf("\n 8.filtrar por nombre.");
    printf("\n 9. Salir.");
    printf("\ningrese numero de menu\n");
    fflush(stdin);
    scanf("%d", &respuesta);

    while(respuesta > 9 || respuesta < 1)
    {
        printf("ERROR ingrese numero de menu nuevamente");
        printf("\n\n Por favor ingrese otro numero: ");
        fflush(stdin);
        scanf("%d", &respuesta);
    }
    return respuesta;
}
