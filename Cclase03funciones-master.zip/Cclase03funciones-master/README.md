# moya agustin
# Tutorial de Git + GitHub

--la primera vez:
1-creo la carpeta contenedora de repositorios

2-ingreso a la carpeta por consola (cd)

3-por consola clono el repositorio
		git clone https://github.com/agustinmoyarancibia/Cclase03funciones.git

4-hago los cambios(modificar,borrar,agregar)

5-agregar cambios
		git add .


6-comitear cambios
		git commit -m "mensaje del cambio"

7-subir al repositorio web
		git push



# orden de los comandos


a- git clone(unico)

iteracion:
b- git add .
c- git commit -m "mensaje"

		solo para subir a la web
d-git push
