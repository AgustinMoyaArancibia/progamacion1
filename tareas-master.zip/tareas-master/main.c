#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    char usuario[30];
    int clave;


} eUsuario;

int main()
{
    eUsuario listaDeUsuarios[2];
    FILE* pArchivo;
    int i;

    for(i=0; i<2; i++)
    {
        printf("ingresse usuario\n");
        scanf("%s", listaDeUsuarios[i].usuario);

        printf("ingrese su clave\n");
        scanf("%d", &listaDeUsuarios[i].clave);
    }

    pArchivo = fopen("datos.csv", "w");

    if(pArchivo != NULL)
    {

        fprintf(pArchivo,"usuario,clave\n");
        for(i=0; i<2; i++)
        {
            fprintf(pArchivo," %s ; %d\n",listaDeUsuarios[i].usuario, listaDeUsuarios[i].clave);
        }
    }
     else
    {
        printf("Imposible guardar");
    }
    fclose(pArchivo);

    printf("Hello world!\n");
    return 0;
}
