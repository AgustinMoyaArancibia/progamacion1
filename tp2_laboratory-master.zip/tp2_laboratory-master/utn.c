
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utn.h"


int getInt(char mensaje[],char error[],int min,int max )
{
    int valor;

    printf("%s", mensaje);
    scanf("%d", &valor);

     while(valor<min || valor>max)
        {
            printf("%s",error);
            fflush(stdin);
            scanf("%d",&valor);
        }

    return valor;
}
long long getIntTel(char mensaje[],char error[],int min,int max )
{
    int valor;

    printf("%s", mensaje);
    scanf("%d", &valor);

     while(valor<min || valor>max)
        {
            printf("%s",error);
            fflush(stdin);
            scanf("%d",&valor);
        }

    return valor;
}

float getFloat(char mensaje[],char error[],int min,int max )
{
    float altura;

    printf("%s", mensaje);
    scanf("%f", &altura);

     while(altura<min || altura>max)
        {
            printf("%s",error);
            fflush(stdin);
            scanf("%f",&altura);
        }

    return altura;
}
int getChar(char mensaje[],char error[], char valor, char valor2)
{
    char letra;
     printf("%s", mensaje);
     fflush(stdin);
    scanf("%c", &letra);

    letra= tolower(letra);

    while(letra != valor && letra != valor2)
        {
            printf("%s",error );
            fflush(stdin);
            scanf("%c",&letra);
            letra= tolower(letra);
        }

    return letra;
}

void getString(char mensaje[], char input[])
{
    printf(mensaje);
    fflush(stdin);
    gets(input);
}
