#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayEmployees.h"
#include "utn.h"

int addEmployee(eEmployee* list, int len, int id, char name[],char lastName[],float salary,int sector)
{


    int retorno=-1;
    if (list!=NULL && len>0)
    {
        strcpy (list[id].name,name);
        strcpy (list[id].lastName,lastName);
        list[id].salary = salary;
        list[id].sector = sector;
        list[id].isEmpty=0;
        retorno=0;
    }
    return retorno;
}
int initEmployees(eEmployee* list,int len)
{
    int retorno=-1;
    if (list != NULL && len>0)
    {
        for (int i=0; i<len; i++)
        {
            list[i].isEmpty=1;
            retorno=0;
        }
    }
    return retorno;
}
int findEmployeeById(eEmployee* list, int len,int id)
{
    int retorno=-1;
    if (list!=NULL && len>0)
    {
        for (int i=0; i<len; i++)
        {
            if (list[i].id==id)
            {
                retorno=i;
                break;
            }
        }
    }
    return retorno;
}

int removeEmployee(eEmployee* list, int len, int id)
{
    int retorno=-1;
    if (list!=NULL && len>0)
    {
        for (int i=0; i<len; i++)
        {
            if (list[i].id==id)
            {
                list[i].isEmpty=1;
                retorno=0;
                break;
            }
            else
            {
                retorno=-1;
            }
        }
    }
    return retorno;
}
int sortEmployees(eEmployee* list, int len, int order)
{
    eEmployee aux;
    int retorno=-1;
    if (list!=NULL && len>0)
    {
        for (int i=0; i<len-1; i++)
        {
            for (int j=i+1; j<len; j++)
            {
                if (order==1)
                {
                    if (strcmp(list[i].lastName,list[j].lastName)>0)
                    {
                        aux = list[i];
                        list[i]=list[j];
                        list[j]=aux;
                    }
                    else if (strcmp(list[i].lastName,list[j].lastName)==0)
                    {
                        if (list[i].sector>list[j].sector)
                        {
                            aux = list[i];
                            list[i]=list[j];
                            list[j]=aux;
                        }
                    }
                }
                else        //si no se ordena de manera asceebte (1) hacemelo descendente
                {
                    if (strcmp(list[i].lastName,list[j].lastName)<0)
                    {
                        aux = list[i];
                        list[i]=list[j];
                        list[j]=aux;
                    }
                    else if (strcmp(list[i].lastName,list[j].lastName)==0)
                    {
                        if (list[i].sector<list[j].sector)
                        {
                            aux = list[i];
                            list[i]=list[j];
                            list[j]=aux;
                        }
                    }
                }
            }
        }
        retorno=0;
    }
    return retorno;

    printEmployees(list,len);
}

int printEmployees(eEmployee* list, int len)
{
    int retorno=-1;
    if (list!=NULL && len>0)
    {
        printf("id--nombre--apellido--salario--sector\n");
        for (int i=0; i<len; i++)
        {
            if (list[i].isEmpty==0)
            {
                printEmploye(list[i]);
                retorno=0;
            }
        }
    }
    return retorno;
}

void printEmploye(eEmployee list)
{
    printf(" %d - %s  - %s - %.f - %d\n",list.id,list.name,list.lastName,list.salary,list.sector);
}

int menuEmployee()
{

    int opcion ;

    system("cls");
    printf("\n*** Menu de Socios ***\n\n");
    printf(" 1- Alta \n");
    printf(" 2- modificar \n");
    printf(" 3- baja \n");
    printf(" 4- Listar empleados\n");
    printf(" 5- listar empleados ordenados\n");
    printf(" 6- Salir\n\n");
    printf(" Ingrese opcion: \n");
    scanf("%d",&opcion);

    while(opcion<0 || opcion>6)
    {
        printf(" REIngrese opcion: \n");
        fflush(stdin);
        scanf("%d",&opcion);

    }

    return opcion;
}



int buscarLibreEmployees(eEmployee* list, int len)
{
    int i;
    int indice = -1;
    for( i=0; i < len; i++)
    {
        if(list[i].isEmpty == 1)
        {
            indice = i;
            break;
        }
    }
    return indice;
}

void altaSocio(eEmployee* list, int len, int* pId)
{
    eEmployee nuevoEmployee;
    int idEmployee = *pId;
    int indice;
    char nombre[51];
    char apellido[51];
    int sector;
    float salario;


    indice= buscarLibreEmployees(list, len);

    if(indice== -1 )
    {
        printf("\n el sistema esta completo. no se puede dar de alta a mas socios.\n\n");
    }
    else
    {
        nuevoEmployee.id = idEmployee;

        nuevoEmployee.isEmpty=0;

        getString("ingrese Apellido",apellido);

        getString("ingrese Nombre",nombre);

        salario = getFloat("\nIngrese salario: ","ERROR vuelva a ingresar salario",0,999999999);

        printf("\nIngrese sector: ");
        scanf("%d",&sector);

        list[indice] = nuevoEmployee;

        *pId = idEmployee +1;

        nuevoEmployee.isEmpty = 0;

        list[indice] = nuevoEmployee;

        addEmployee(list,len,idEmployee,nombre,apellido,salario,sector);

        printf("alta exitosa");
    }
}


void modificacionEmployee(eEmployee* list, int len)
{

    char seguir = 's';
    int codigo;
    int esta;
    char confirma;
    int nuevoSector;

    system("cls");
    printf("---Modificacion empleado---\n\n");

    printEmployees(list,len);


    codigo = getInt(" ingrese  un numero de ID empleado: \n", "ERROR ingrse un codigo valido\n",0,100);

    esta = findEmployeeById(list, len, codigo);

    if(esta == -1)
    {
        printf("\nEl codigo %d no se encuentra en el sistema\n\n", codigo);

    }
    else
    {

        printEmploye(list[esta]);

        do
        {
            switch(menuModificar())
            {

            case 1:

                getString("ingrese nuevo apellido\n", list[esta].lastName);
                printf("cambio el apellido");
                system("pause");
                break;
            case 2:
                getString("ingrese nuevo nombre\n", list[esta].name);
                printf("cambio el nombre");
                system("pause");
                break;
            case 3:
                list[esta].salary = getFloat("ingrese nuevo salario: \n","error ingrese salario nuevamente\n",0,9999999);
                printf("cambio el salario");
                system("pause");
                break;
            case 4:
                printf("ingrese nuevo sector: ");
                scanf("%d", &nuevoSector);
                list[esta].sector = nuevoSector;
                printf("cambio el sector");
                system("pause");
                break;

            case 5:
                seguir = 'n';
                break;

            }
        }
        while(seguir == 's');

        confirma = getChar("\nConfirma Modificacion s/n?: \n","\nerror Confirma Modificacion s/n?: ",'s','n');

        if(confirma == 's')
        {

            printf("\nSe ha modificado lo pedido\n\n");
        }
        else
        {
            printf("\nSe ha cancelado la modificacion\n\n");
        }

    }
}

int menuModificar()
{
    int opcion ;

    printf("\n*** Menu de modificar ***\n\n");
    printf(" 1- apellido \n");
    printf(" 2- nombre \n");
    printf(" 3- salario \n");
    printf(" 4- sector\n");
    printf(" 5- Salir\n\n");

    opcion= getInt(" Ingrese opcion: \n"," REIngrese opcion: \n",0,6);

    return opcion;
}


void bajaEmployee(eEmployee* list, int len)
{
    int codigo;
    int esta;
    char confirma;

    system("cls");
    printf("-----baja de cliente-----\n\n");

    printEmployees(list, len);

    codigo= getInt("ingrese codigo de cliente\n"," reingrese  un numero: ",0,100);

    esta = findEmployeeById(list,len, codigo);

    if(esta== -1)
    {
        printf("\n el codigo %d no se encuentra en el sistema\n\n", codigo);
    }
    else
    {
        printEmploye(list[esta]);

        confirma = getChar("\n confirma la baja s/n?: ","ERROR ingrese nuevamente",'s','n');

        if(confirma== 's')
        {
            removeEmployee(list,len,codigo);
            printf("\n se ha realizado la baja \n\n");
        }
        else
        {
            printf("\n se ha cancelado la baja\n\n");
        }

    }
}
