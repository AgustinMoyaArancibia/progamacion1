#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "LinkedList.h"
#include "Employee.h"
/** \brief Pide espacio

 de memoria para la estructura Employee
 *
 * \return Employee*
 *
 */
Employee* employee_new()
{
    Employee* this = malloc(sizeof(Employee));

    return this;
}

/** \brief pide espacio de memoria y guarda todos los datos en la estructura
 *
 * \param char* idStr
 * \param char* nombreStr
 * \param char* horasTrabajadasStr
 * \param char* sueldoStr
 * \return Employee
 *
 */

Employee* employee_newParametros(char* idStr,char* nombreStr,char* horasTrabajadasStr, char* sueldoStr)
{
    Employee* empNew;
    Employee* returnEmp;
    int id;
    int horasTrabajadas;
    int sueldo;
    empNew = employee_new();

    if(empNew != NULL)
    {
        id = atoi(idStr);
        horasTrabajadas = atoi(horasTrabajadasStr);
        sueldo = atoi(sueldoStr);

        if(employee_setId(empNew, id) == 1 &&
                employee_setNombre(empNew, nombreStr) == 1 &&
                employee_setHorasTrabajadas(empNew, horasTrabajadas) == 1 &&
                employee_setSueldo(empNew, sueldo) == 1)
        {
            returnEmp = empNew;
        }
    }
    return returnEmp;
}


