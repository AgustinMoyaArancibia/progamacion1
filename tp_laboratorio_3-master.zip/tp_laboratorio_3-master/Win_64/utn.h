
#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

int opcionesMenu();

#endif
