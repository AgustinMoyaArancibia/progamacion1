#include <stdio.h>
#include <stdlib.h>
 //unsigned long factorial(float a );

 int factorial(int);
int main()
{
    int numero=12;

    int resultado;

    resultado=factorial(numero);
    printf(" factorial es %d", resultado);

    return 0;
}


 int factorial(int numero)
 {
     int resultado;

     if(numero==0)
        {
            resultado =1;
        }
     else
        {
            resultado= numero*factorial(numero-1);
        }
        return resultado;
 }










/*
    for(;;)
        {
            printf("hola"); //for infinito
        }
        */

/*
unsigned long factorial(float a )
{
    int entero;
    entero=(int)a;

    if(entero==1 )
    {
        return 1;
    }
    else
    {
        return entero * factorial(entero - 1);
    }

}*/

/*
 int numero=5;

    int resultado=1;
    int i;

    for(i=numero; i>=1;i--)
        {
            resultado = resultado * i;
        }
    printf("%d",resultado);
*/
