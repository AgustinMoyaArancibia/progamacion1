void cargarVector(int [], int );
void mostrarMaximo(int [], int);
int calcularMaximo(int [], int);
