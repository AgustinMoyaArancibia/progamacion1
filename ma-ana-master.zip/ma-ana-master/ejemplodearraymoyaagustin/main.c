#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
#define T 10


int main()
{
    printf("ejemplo de vectores \n\n\n");


    int vectorDeNumeros[T]= {-1,-2,-6,5,-4,-8,-8,-7,5,6};
    int i;
    int contadorPositivos=0;
    int  sumaPositivo=0;
    float promedio;
    //int numeroMaximo;
    int numeroMinimo;
    int flag;
    int opcion;

    do
    {
        printf("\n1.cargar numeros\n");
        printf("2.mostrar todo\n");
        printf("3.mostrar negativos\n");
        printf("4.mostrar promedios de positivos\n");
        printf("5.mostrar maximo\n");
        printf("6.mostrar minimo\n");
        printf("7. salir\n");
        printf("elija una opcion\n");
        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:

            cargarVector(vectorDeNumeros,T);
            /* for(i=0; i<T; i++)
             {
                 printf("ingrese un numero");
                 scanf("%d",&vectorDeNumeros[i]);
             }
             */
            break;
        case 2:
            for(i=0; i<T; i++)
            {
                printf("%d\n",vectorDeNumeros[i]); //muestro vector
            }
            break;
        case 3:


            printf("\nnegativos\n\n");
            for(i=0; i<T; i++)
            {
                if(vectorDeNumeros[i] <0) //muestro negativos
                {
                    printf("%d\n",vectorDeNumeros[i]);
                }

            }
            break;
        case 4:
            printf("\npositivos\n\n");
            for(i=0; i<T; i++)
            {
                if(vectorDeNumeros[i]>=0)
                {
                    sumaPositivo+= vectorDeNumeros[i];
                    contadorPositivos++;
                }
            }
            promedio= (float)sumaPositivo/contadorPositivos;
            printf("suma %d\n", sumaPositivo);
            printf("cantidad %d\n",contadorPositivos);

            printf("promedio de positivos %f\n\n", promedio);
            break;
        case 5:
            mostrarMaximo(vectorDeNumeros,T);
            /* flag=0;
             for(i=0; i<T; i++)
             {
                 if(flag==0 || vectorDeNumeros[i]>numeroMaximo)
                 {
                     numeroMaximo=vectorDeNumeros[i];
                 }
                 flag=1;
             }
             printf("numero maximo %d: \n", numeroMaximo);
             for(i=0; i<T; i++)
             {
                 if(vectorDeNumeros[i] == numeroMaximo)
                 {
                     printf("%d- ", i); //posicion del vector
                 }
             }*/
            break;
        case 6:
            flag=0;
            for(i=0; i<T; i++)
            {

                if(flag==0 || vectorDeNumeros[i]<numeroMinimo)
                {
                    numeroMinimo=vectorDeNumeros[i];
                }

                flag=1;

                printf("\nnumero minimo %d: \n", numeroMinimo);
                for(i=0; i<T; i++)
                {
                    if(vectorDeNumeros[i] == numeroMinimo)
                    {
                        printf("%d- ", i);
                    }
                }

            }
            break;
        case 7:
            break;
        }

        system("pause");
        system("cls");

    }
    while(opcion!= 7);

    /* for(i=0; i<T; i++)
         {
             vectorDeNumeros[i]=0; inicializo a cero
         }
     */
    /*for(i=0; i<T; i++)
        {
            printf("ingrese un numero");  pido que ingrese datos
            scanf("%d",&vectorDeNumeros[i]);
        }
    */




    return 0;
}
