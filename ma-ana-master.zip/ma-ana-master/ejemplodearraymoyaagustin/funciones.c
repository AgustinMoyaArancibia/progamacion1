#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
#define T 10


void cargarVector(int vector[], int tam)
{
    int i;
    for(i=0; i<T; i++)
    {
        printf("ingrese un numero");
        scanf("%d",&vector[i]);
    }
}

void mostrarMaximo(int vector [], int tam)
{

    int i;
    int numeroMaximo;

    numeroMaximo=calcularMaximo(vector,tam);


    printf("numero maximo %d: \n", numeroMaximo);
    for(i=0; i<T; i++)
    {
        if(vector[i] == numeroMaximo)
        {
            printf("esta en la posicion: %d- ", i); //posicion del vector
        }
    }
}

int calcularMaximo(int vector[], int tam)
{
    int flag=0;
    int i;
    int numeroMaximo;

    for(i=0; i<T; i++)
    {
        if(flag==0 || vector[i]>numeroMaximo)
        {
            numeroMaximo=vector[i];
        }


        flag=1;

    }
    return numeroMaximo;
}

