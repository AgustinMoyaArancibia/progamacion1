#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
#define T 5

int main()
{
    int sillas[T];
    int legajos[T];
    int libres;
    int edades[T];

    inicializarArray(sillas,T,-1);
    cargarSillas(sillas);
    cargarLegajos(legajos);
    cargarEdades(edades);
    printf("---sillas---\n");
    mostrarArray(sillas,T);
    printf("---legajos---\n");
    mostrarArray(legajos,T);
    printf("---edades---\n");
    mostrarArray(edades,T);






    printf("--------\n");
    mostrarMaximo(sillas,T);
    printf("--------\n");
    mostrarMinimo(sillas,T);





    return 0;
}
