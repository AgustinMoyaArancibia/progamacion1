#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int calcularMaximo(int vector[], int tam)
{
    int flag=0;
    int i;
    int numeroMaximo;

    for(i=0; i<tam; i++)
    {
        if(flag==0 || vector[i]>numeroMaximo)
        {
            numeroMaximo=vector[i];
        }


        flag=1;

    }
    return numeroMaximo;
}

void mostrarMaximo(int vector [], int tam)
{

    int i;
    int numeroMaximo;

    numeroMaximo=calcularMaximo(vector,tam);


    printf("numero maximo %d: \n", numeroMaximo);
    for(i=0; i<tam; i++)
    {
        if(vector[i] == numeroMaximo)
        {
            printf("esta en la posicion: %d- \n", i); //posicion del vector
        }
    }
}

int calcularMinimo(int vector[], int tam)
{
    int flag=0;
    int i;
    int numeroMinimo;

    for(i=0; i<tam; i++)
    {
        if(flag==0 || vector[i]<numeroMinimo)
        {
            numeroMinimo=vector[i];
        }


        flag=1;

    }
    return numeroMinimo;
}

void mostrarMinimo(int vector [], int tam)
{

    int i;
    int numeroMinimo;

    numeroMinimo=calcularMinimo(vector,tam);


    printf("numero minimo %d: \n", numeroMinimo);
    for(i=0; i<tam; i++)
    {
        if(vector[i] == numeroMinimo)
        {
            printf("esta en la posicion: %d- ", i); //posicion del vector
        }
    }



}

void mostrarArray(int vector[], int tam)
{
    int i;
    for(i=0; i<tam; i++)
            {
                printf("%d\n",vector[i]); //muestro vector
            }
}



void cargarSillas(int vec[])
{
    int i;
    int vecSillas []={55,11,22,33,44};

    for( i=0; i < 5; i++)
    {

        vec[i]=vecSillas[i];
    }


}

void inicializarArray(int vec[], int tam,int valorDeInicio)
{
int i;
    for( i=0; i < tam; i++)
    {

        vec[i]=valorDeInicio;
    }
}

int EstaLibre(int vec[], int tam, int LaSilla,int  valorInicial)
{
    int retorno=0;

    if(vec[LaSilla]== valorInicial)
        {
            retorno=1;
        }
    return retorno;
}

int ocuparSilla(int vec[], int tam, int LaSilla , int legajo)
{
    int retorno=-1;
    int estaLibreLaSilla;
      if(LaSilla<tam)
        {
            estaLibreLaSilla=EstaLibre(vec,tam,LaSilla,-1);
            if(estaLibreLaSilla==1   )
                {
                   vec[LaSilla]=legajo;
                   retorno=1;
                }
        }




    return retorno;
}


void cargarLegajos(int vec[])
{
    int i;
    int veclegajos []={1000,1001,1002,1003,1004};

    for( i=0; i < 5; i++)
    {

        vec[i]=veclegajos[i];
    }


}



int cantidadLibres(int vec[], int tam, int valorInicial)
{
    int i;
    int contador;
    int retorno;

    for(i =0; i<tam ; i++)
        {
            if(vec[i]== valorInicial)
                {
                   retorno= contador++;
                }else
                {
                    printf("no hay lugar libres");
                }
        }
        return retorno;

}

void cargarEdades(int vec[])
{
    int i;
    int vecEdades []={18,19,81,91,98};

    for( i=0; i < 5; i++)
    {

        vec[i]=vecEdades[i];
    }





}



