


int getInt(int*, char[], int, int);


