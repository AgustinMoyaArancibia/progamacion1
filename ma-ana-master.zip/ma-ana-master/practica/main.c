#include <stdio.h>
#include <stdlib.h>
#include "inputs.h"



int main()
{
    int edad;

    edad=getInt("ingrese edad", 1,50);
    printf("ingreso la edad de:%d ", edad);

    return 0;
}


