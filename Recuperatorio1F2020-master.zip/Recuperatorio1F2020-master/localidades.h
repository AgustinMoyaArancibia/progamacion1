#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#define OCUPADO 1
#define LIBRE 0

typedef struct
{
    char provincia[30];
    int codigoPostal;
    char descripcion[30];
    int idLocalidad;
    int estado;

}eLocalidad;

void inicializarLocalidades(eLocalidad listadoLocalidades[], int tamL);
void harcodearLocadidades(eLocalidad listadoLocalidades[]);
void listarLocalidades(eLocalidad listaLocalidades[] , int tamL);
