#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

#include "clientes-mascostas.razas.h"

#define TC 10
#define TM 20
#define TR 11
#define TL 3

#define OCUPADO 1
#define LIBRE 0

//moya agustin
void listarClientesConLocalidadYconMascotas(eClientes listaClientes[], int tamC,eMascotas listaMascotas[],int tamM, eLocalidad listaLocalidades[], int tamL);


int main()
{

    int opcion;
    int retornoAltaMascotas;
    int retornoBajaMascotas;
    int retornoModificarMascotas;
    int retornoBajaCliente;
    int retornoModificarCliente;
    float promedioEdadesMascotas;
    float promedioEdadesMascotasTipo;


    eClientes listaClientes[TC];
    eMascotas listaMascotas[TM];
    eRaza listaRazas[TR];
    eLocalidad listaLocalidades[TL];

    inicializarMascotas(listaMascotas,TM);
    inicializarClientes(listaClientes,TC);
    inicializaRaza(listaRazas,TR);
    inicializarLocalidades(listaLocalidades,TL);

    harcodearClientes(listaClientes);
    harcodearMascotas(listaMascotas);
    harcodeaRazas(listaRazas);
    harcodearLocadidades(listaLocalidades);



    do
    {
        opcion= menuPrincipal();


        switch (opcion)
        {
        case 1:
            mostrarListaClientesConProvincia(listaClientes,TC,listaLocalidades,TL);
            system("pause");
            system("cls");
            break;
        case 2:
            mostrarListaMascotaS(listaMascotas,TM,listaClientes,TC,listaRazas,TR);
            system("pause");
            system("cls");
            break;

        case 3:
            //mostrarClientesConMoscotas(listaMascotas,TM,listaClientes,TC);
            mostrarClientesConMoscotasLocalidades(listaMascotas,TM,listaClientes,TC, listaLocalidades, TL);
            system("pause");
            system("cls");
            break;
        case 4:
            retornoAltaMascotas = altaMascota(listaMascotas,TM,listaClientes,TC,listaRazas,TR);

            switch(retornoAltaMascotas)
            {
            case 1:
                printf("se dio de alta\n");
                break;
            case -1:
                printf("alta cancelada\n");
                break;
            }
            system("pause");
            system("cls");
            break;
        case 5:
            retornoBajaMascotas = eliminarMascota(listaMascotas,TM);
            switch(retornoBajaMascotas)
            {
            case 1:
                printf("se dio de BAJA\n");
                break;
            case -1:
                printf("BAJA  cancelada\n");
                break;
            }
            system("pause");
            system("cls");
            break;
        case 6:
            retornoModificarMascotas = modificarMascota(listaMascotas,TM,listaRazas,TR,listaClientes,TC);
            switch(retornoModificarMascotas)
            {
            case 1:
                printf("se modifico\n");
                break;
            case -1:
                printf("no se modifico\n");
                break;
            }
            system("pause");
            system("cls");
            break;
        case 7:
            //altaCliente(listaClientes,TC);
            altaClienteConLocalidad(listaClientes,TC, listaLocalidades, TL);

            system("cls");
            break;
        case 8:
            retornoBajaCliente = eliminarCliente(listaClientes,TC,listaMascotas,TM);

            switch(retornoBajaCliente)
            {
            case 1:
                printf("se dio de baja\n");
                break;
            case -1:
                printf("se cancelo la baja\n");
                break;
            }
            system("pause");
            system("cls");
            break;
        case 9:
            ordenarPorRaza(listaMascotas,TM,listaClientes,TC);
            system("pause");
            system("cls");
            break;
        case 10:
            retornoModificarCliente =  modificarCliente(listaClientes,TC);
            switch(retornoModificarCliente)
            {
            case 1:
                printf("se modifico\n");
                break;
            case -1:
                printf("no se modifico\n");
                break;
            }

            system("pause");
            system("cls");
            break;
        case 11:
            mostrarClientesConMasDeUnaMascota(listaMascotas,TM,listaClientes,TC);
            system("pause");
            system("cls");
            break;
        case 12:
            ListarMascotaMayorTresAnios(listaMascotas,TM,listaClientes,TC);
            system("pause");
            system("cls");
            break;
        case 13:
            mostrarListaMascotasPorTipo(listaMascotas,TM);
            system("pause");
            system("cls");
            break;
        case 14:
            ordenarClientesPorCantidadesMascotas(listaMascotas,TM,listaClientes,TC);

            system("pause");
            system("cls");
            break;
        case 15:
            ordenarClientesPorCantidadesMascotasYNombre(listaMascotas,TM,listaClientes,TC);
            system("pause");
            system("cls");
            break;

        case 16:
            promedioEdadesMascotas = mostrarPromedioDeEdadesMascotas(listaMascotas,TM);
            printf("el promedio de edades de las mascotas es: %.2f\n",promedioEdadesMascotas);
            system("pause");
            system("cls");
            break;

        case 17:
            promedioEdadesMascotasTipo =  mostrarListaMascotasPorTipoYedad(listaMascotas,TM);
            printf(" promedio del tipo seleccionado es : %.2f\n", promedioEdadesMascotasTipo);
            system("pause");
            system("cls");
            break;
        case 18:
            promedioEntreVaronesYmujeresDeClientes(listaClientes,TC);
            system("pause");
            system("cls");
            break;
        case 19:
            //mostrarListaClienesConMascotasMismoSexo(listaMascotas,TM, listaClientes,TC, listaRazas, TR);
           // listarClientesConLocalidadYconMascotas(listaClientes,TC, listaMascotas, TM, listaLocalidades, TL);
           //mostrarListaClientesPorLocalidad(listaClientes,TC, listaLocalidades, TL);
            system("pause");
            system("cls");
            break;
          case 20:
           mostrarListaClientesPorLocalidad(listaClientes,TC, listaLocalidades, TL);
            system("pause");
            system("cls");
            break;
        case 21:
            ordenarPorLocalidadYNombre(listaClientes, TC, listaLocalidades, TL);
            system("pause");
            system("cls");
            break;

        }// final switch

    }//final while
    while (opcion != 22);



    return 0;
}



void ordenarPorLocalidadYNombre(eClientes listaCliente[], int tamC, eLocalidad listaLocalidades[] , int tamL)
{
    eLocalidad auxL;
    eClientes auxC;

    int i;
    int j;

    for(i=0; i<tamL -1 ; i++)
    {

        for(j=i+1 ; j<tamL; j++)
        {

            if( listaLocalidades[i].estado == OCUPADO &&  stricmp(listaLocalidades[i].provincia,listaLocalidades[j].provincia)>0)
            {

                auxL = listaLocalidades[i];
                listaLocalidades[i] = listaLocalidades[j];
                listaLocalidades[j] = auxL;

                auxC = listaCliente[i];
                listaCliente[i] = listaCliente[j];
                listaCliente[j] = auxC;

            }
    }

    printf("ordenamiento con exito\n");
}
}

void listarClientesConLocalidadYconMascotas(eClientes listaClientes[], int tamC,eMascotas listaMascotas[],int tamM, eLocalidad listaLocalidades[], int tamL)
{
    int i;
    int j;
    int k;


    for(i= 0; i<tamC ; i++)
    {

        for(k= 0; k<tamL ; k++)
        {

            for(j= 0; j<tamM ; j++)
            {
                if(listaClientes[i].idCliente == listaMascotas[j].idMascota && listaClientes[i].idLocalidad == listaLocalidades[k].idLocalidad)
                {
                    printf(" duenio : %s-----s    su mascota es:  %s---- %s \n",listaClientes[i].nombre,listaLocalidades[k].provincia, listaMascotas[j].nombre, listaMascotas[j].TipoDeMascota);
                }
            }
        }
    }

}




