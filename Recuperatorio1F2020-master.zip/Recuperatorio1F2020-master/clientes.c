#include "clientes.h"
#include "fucionesUTN.h"



void harcodearClientes(eClientes listadoClientes[])
{
    int i;
    eClientes clientes[]=
    {
        {"damian", "sala",112563246,15,'m',101,1000,OCUPADO},
        {"alan", "ela",112563246,20,'m',102,1002,OCUPADO},
        {"ana", "cresi",112563246,10,'f',103,1001,OCUPADO},
        {"airto", "shamn",112563246,15,'m',104,1000,OCUPADO},
        {"rosa", "shamn",112563246,20,'m',105,1002,OCUPADO}
    };

    for( i=0; i < 5 ; i++)
    {

        listadoClientes[i] = clientes[i];
    }
}


void mostrarListaClientes(eClientes listaClientes[], int tamC)
{

    int i;

    printf("     nombre       apellido       localidad        telefono       edad     sexo   idcliente\n");
    for(i=0; i<tamC ; i++)
    {

        if(listaClientes[i].estado == OCUPADO)
        {
            printf("\n|%10s |%15s| %10d| %10d| %5c| %10d|\n",
                    listaClientes[i].nombre,
                   listaClientes[i].apellido,
                   listaClientes[i].telefono,
                   listaClientes[i].edad,
                   listaClientes[i].sexo,
                   listaClientes[i].idCliente);
        }
    }

}

void inicializarClientes(eClientes listadoClientes[], int tamC)
{
    int i;
    for(i=0; i<tamC; i++)
    {

        listadoClientes[i].estado = LIBRE;
    }
}
int buscarIdClientes(eClientes listaClientes[], int tamC, int id)
{


    int indice = -1;

    for(int i=0; i<tamC; i++)
    {
        if(listaClientes[i].estado == OCUPADO && listaClientes[i].idCliente == id)
        {
            indice = i;
            break;
        }
    }


    return indice;

}

int buscarLibreCliente(eClientes listaClientes[], int tamC)
{
    int i;
    int index = -1;
    for(i=0; i<tamC; i++)
    {
        if(listaClientes[i].estado == LIBRE)
        {
            index = i;
            break;
        }
    }
    return index;
}

void altaCliente(eClientes listaCliente[], int tamC)
{
    int indice;
    int id;
    int esta;
    eClientes nuevoCliente;

    mostrarListaClientes(listaCliente,tamC);

    indice = buscarLibreCliente(listaCliente, tamC);

    printf("*** Alta cliente ***\n\n");

    if( indice == -1)
    {

        printf("No hay lugar en el sistema\n\n");
        system("pause");
    }
    else
    {
        id = getInt("ingrese id de cliente\n", "ERROR id invalido\n",0,1000);

        esta = buscarIdClientes(listaCliente, tamC, id);

        if( esta != -1)
        {

            printf("Ya esta un cliente con el id %d\n", id);
            system("pause");

        }
        else
        {

            nuevoCliente.idCliente = id;

            getString("ingrese nombre : \n",nuevoCliente.nombre);
            getString("ingrese apellido : \n",nuevoCliente.apellido);
            nuevoCliente.edad = getInt("ingrese edad\n", "ERROR edad inexiste\n",0,100);
            nuevoCliente.telefono = getIntTel("ingrese numero telefonico","telefono invalido",0,9999999999);
            nuevoCliente.sexo = getChar("ingrese sexo m o f ","error ingrese f o m", 'f','m');

            nuevoCliente.estado = OCUPADO;

            listaCliente[indice] = nuevoCliente;



        }
    }

}

int modificarCliente(eClientes listadoClientes[], int tamC)
{
    int id;
    int esta;
    int opcionModificar;
    int retorno ;

    mostrarListaClientes(listadoClientes,tamC);

    id = getInt("ingrese el id que desea modificar\n","ERROR id entre 100 y 200\n",100,200);

    esta = buscarIdClientes(listadoClientes,tamC,id);


    if(esta == -1)
    {
        printf("el id elegido no esta registrado\n");
        retorno = -1;

    }
    else
    {

        do
        {


            printf("Que opcion quiere cambiar?\n");
            printf("1.nombre\n");
            printf("2.apellido\n");
            printf("3.localidad\n");
            printf("4.telefono\n");
            printf("5.edad\n");
            printf("6.sexo\n");
            printf("7.guardar modificaciones\n");
            scanf("%d", &opcionModificar);


            while(opcionModificar < 1 || opcionModificar> 7)
            {
                printf("ERROR Elija una opcion:\n ");
                fflush(stdin);
                scanf("%d", &opcionModificar);
            }


            switch(opcionModificar)
            {
            case 1:
                getString("Ingrese nombre del cliente: \n",listadoClientes[esta].nombre);
                printf("nombre cambiado\n");
                break;
            case 2:
                getString("Ingrese apellido del cliente: \n",listadoClientes[esta].apellido);
                printf("apellido cambiado\n");
                break;
            case 3:
              //  getString("Ingrese localidad del cliente: \n",listadoClientes[esta].localidad);
                printf("localidad cambiado\n");
                break;
            case 4:
                listadoClientes[esta].telefono = getInt("ingrese numero telefonico \n","ERROR id no valido\n",1,999999999);
                printf("telefono cambiado\n");
                break;
            case 5:
                listadoClientes[esta].edad = getInt("ingrese nuevo edad entre \n","ERROR peso no valido\n",0,100);
                printf("edad cambiado\n");
                break;
            case 6:
                listadoClientes[esta].sexo = getChar("ingrese sexo m o f","ERROR ingrese f o m ",'f','m');
                break;
            }
            retorno= 1;
        }
        while(opcionModificar != 7);

    }

    return retorno;

}

void promedioEntreVaronesYmujeresDeClientes(eClientes listaClientes[], int tamC)

{
    int i;
    int cantitadClientes = 0;
    int contadorM= 0;
    int contadorF= 0;
    float promedioClientesM;
    float promedioClientesF;
    for (i = 0; i<tamC ; i++)
    {
        if(listaClientes[i].estado == OCUPADO && listaClientes[i].sexo == 'f' )
        {
            contadorF++;
        }
        if(listaClientes[i].estado == OCUPADO && listaClientes[i].sexo == 'm' )
        {
            contadorM++;
        }
        if(listaClientes[i].estado == OCUPADO )
        {
            cantitadClientes ++;
        }

        //printf("cantidad de edades : %d --- cantidad de animales . %d\n", contador, cantitadEdad);
    }

    promedioClientesF =(float) (contadorF * cantitadClientes) / 100;
    promedioClientesM =(float) (contadorM * cantitadClientes) / 100;


    //promedioClientesF =(float) (contadorF / cantitadClientes) * 100;
    //promedioClientesM =(float) (contadorM / cantitadClientes) * 100;

    printf(" el porcentaje de mujeres es: %.2f \n", promedioClientesF);
    printf(" el el porcentaje de hombres es: %.2f \n", promedioClientesM);

}


