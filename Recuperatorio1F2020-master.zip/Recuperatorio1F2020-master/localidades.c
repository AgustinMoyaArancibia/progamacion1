#include "localidades.h"
#include "fucionesUTN.h"

void inicializarLocalidades(eLocalidad listadoLocalidades[], int tamL)
{
    int i;
    for(i=0; i<tamL; i++)
    {

        listadoLocalidades[i].estado = LIBRE;
    }
}

void harcodearLocadidades(eLocalidad listadoLocalidades[])
{


    int i;
    eLocalidad localidades[]=
    {
        {"quilmes",1849,"lindo",1000,OCUPADO},
        {"rosario",3014,"lindo",1001,OCUPADO},
        {"santa Rosa",2014,"lindo",1002,OCUPADO}
    };

    for( i=0; i < 3 ; i++)
    {

        listadoLocalidades[i] = localidades[i];
    }
}


void listarLocalidades(eLocalidad listaLocalidades[] , int tamL)
{
    int i;

    for(i=0; i<tamL ; i++)
        {
            if(listaLocalidades[i].estado == OCUPADO)
                {
                    printf("%s-----%d-----%s---- %d\n", listaLocalidades[i].provincia , listaLocalidades[i].codigoPostal, listaLocalidades[i].descripcion,listaLocalidades[i].idLocalidad);
                }
        }
}
