#include "razas.h"
#include "fucionesUTN.h"

void mostrarTipoDeRazas(eRaza listaRaza[], int tamR)
{
    int i;

    for(i=0; i<tamR; i++)
    {
        if(listaRaza[i].estado == OCUPADO)
        {
            printf("las razas disponibles son : %s---- id : %d \n", listaRaza[i].nombreRaza, listaRaza[i].idRaza);
        }
    }
}
void inicializaRaza(eRaza listaRaza[], int tamR)
{
    int i;
    for(i=0; i<tamR; i++)
    {

        listaRaza[i].estado = LIBRE;
    }
}

void mostrarListaRazas(eRaza listaRaza[], int tamR)
{
    int i;

    for(i=0; i<tamR; i++)
    {
        if(listaRaza[i].estado == OCUPADO)
        {
            printf("%15s %15s %5d\n",listaRaza[i].nombreRaza, listaRaza[i].pais, listaRaza[i].idRaza);
        }

    }
}

void harcodeaRazas(eRaza listadoRaza[])
{


    int i;
    eRaza razas[]=
    {
        {"ovejero","argentina",300,OCUPADO},
        {"noraza","australiano",301,OCUPADO},
        {"overo","argentina",302,OCUPADO},
        {"noraza","argentina",303,OCUPADO},
        {"pastor","aleman",304,OCUPADO},
        {"persa","persia",305,OCUPADO},
        {"persa","persia",306,OCUPADO},
        {"noraza","argentina",307,OCUPADO},
        {"pastor","aleman",308,OCUPADO},
        {"bulldog","frances",309,OCUPADO},
        {"noraza","holanda",310,OCUPADO}
    };

    for( i=0; i < 11 ; i++)
    {

        listadoRaza[i] = razas[i];
    }
}




