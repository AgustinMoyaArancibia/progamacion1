
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "fucionesUTN.h"


int getInt(char mensaje[],char error[],int min,int max )
{
    int valor;

    printf("%s", mensaje);
    scanf("%d", &valor);

     while(valor<min || valor>max)
        {
            printf("%s",error);
            fflush(stdin);
            scanf("%d",&valor);
        }

    return valor;
}
long long getIntTel(char mensaje[],char error[],int min,int max )
{
    int valor;

    printf("%s", mensaje);
    scanf("%d", &valor);

     while(valor<min || valor>max)
        {
            printf("%s",error);
            fflush(stdin);
            scanf("%d",&valor);
        }

    return valor;
}

float getFloat(char mensaje[],char error[],int min,int max )
{
    float altura;

    printf("%s", mensaje);
    scanf("%f", &altura);

     while(altura<min || altura>max)
        {
            printf("%s",error);
            fflush(stdin);
            scanf("%f",&altura);
        }

    return altura;
}
int getChar(char mensaje[],char error[], char valor, char valor2)
{
    char sexo;
     printf("%s", mensaje);
     fflush(stdin);
    scanf("%c", &sexo);

    sexo= tolower(sexo);

    while(sexo != valor && sexo != valor2)
        {
            printf("%s",error );
            fflush(stdin);
            scanf("%c",&sexo);
            sexo= tolower(sexo);
        }

    return sexo;
}

void getString(char mensaje[], char input[])
{
    printf(mensaje);
    fflush(stdin);
    gets(input);
}
