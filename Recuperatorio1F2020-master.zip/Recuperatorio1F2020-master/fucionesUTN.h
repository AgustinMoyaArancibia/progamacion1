

int getInt(char mensaje[],char error[],int min,int max );
long long getIntTel(char mensaje[],char error[],int min,int max );
float getFloat(char mensaje[],char error[],int min,int max );
int getChar(char mensaje[],char error[], char valor, char valor2);
void getString(char mensaje[], char input[]);

