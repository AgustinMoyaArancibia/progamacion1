#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayEmployees.h"
#define TAME 10




int main()
{
    eEmployee employee[TAME];
    initEmployees(employee,TAME);
    int idEmployee = 0 ;
    int flag=0;
    char seguir = 's';

    do
    {
        switch(menuEmployee())
        {

        case 1:

            altaSocio(employee,TAME,&idEmployee);
            flag=1;
            break;
        case 2:
            if(flag==1)
            {
                modificacionEmployee(employee,TAME);
            }
            else
            {
                printf("no ingreso a nadie de alta\n");
            }
            system("pause");
            break;
        case 3:
            if(flag==1)
            {
                bajaEmployee(employee,TAME);
            }
            else
            {
                printf("no ingreso a nadie de alta\n");
            }
            system("pause");

            break;
        case 4:
            if(flag==1)
            {
                printEmployees(employee,TAME);

            }
            else
            {
                printf("no ingreso a nadie de alta\n");
            }
            system("pause");
            break;
        case 5:
            if(flag==1)
            {
                sortEmployees(employee,TAME,1);
                printEmployees(employee,TAME);

            }
            else
            {
                printf("no ingreso a nadie de alta\n");
            }
            system("pause");
            break;

        case 6:
            printf("Salir");
            system("pause");
            seguir = 'n';
            break;

        }

    }
    while(seguir == 's');
    return 0;
}


/* \brief  To indicate that all position in the array are empty,
*          this function put the flag (isEmpty) in TRUE in all *          position of the array
* \param list Employee* Pointer to array of employees
* \param len int Array length * \return int Return (-1) if Error [Invalid length or NULL pointer] - (0) if Ok *
 */



