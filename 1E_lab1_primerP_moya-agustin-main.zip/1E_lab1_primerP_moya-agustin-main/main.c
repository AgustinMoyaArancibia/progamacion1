#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utn.h"
#include "todo.h"
#define TAMELECTRO 10
#define TAMMARCA 10
#define TAMSERVICIO 10
#define TAMREPARACION 10
#define TAMCLIENTE 10

//Moya agustin
int main()
{
    eElecotrodomestico listaElectro[TAMELECTRO];
    eMarca listaMarca[TAMMARCA];
    eReparacion listaReparaciones[TAMREPARACION];
    eServicio listaServicio[TAMSERVICIO];
    eClientes listaCliente[TAMCLIENTE];
    int opcion;
    int opcionMenuInformes;
    int idIncrementado = 6;
    int idIncrementadoElectro = 106;

    inicializarElectro(listaElectro,TAMELECTRO);
    harcodearElectrodomesticos(listaElectro);

    inicializarMarca(listaMarca,TAMMARCA);
    harcodearMarcas(listaMarca);

    inicializarReparaciones(listaReparaciones,TAMREPARACION);
    harcodearReparaciones(listaReparaciones);

    inicializarServicios(listaServicio,TAMSERVICIO);
    harcodearServicios(listaServicio);

    inicializaCliente(listaCliente,TAMCLIENTE);
    harcodearClientes(listaCliente);


    do
    {
        opcion= opcionesMenu();

        switch (opcion)
        {
        case 1:
            if(altaElectrodomesticosMarca(listaElectro,TAMELECTRO,&idIncrementadoElectro,listaMarca,TAMMARCA)==1)
            {
                printf("alta correcta\n");
            }
            else
            {
                printf("algo salio mal\n");
            }
            system("pause");
            system("cls");
            break;
        case 2:
            if(modificarElectro(listaElectro,TAMELECTRO,listaMarca,TAMMARCA)==1)
            {
                printf("todo ok\n");
            }
            else
            {
                printf("algo salio mal\n");
            }
            system("pause");
            system("cls");
            break;

        case 3:
            if(bajaElectro(listaElectro,TAMELECTRO,listaMarca,TAMMARCA)==1)
            {
                printf("todo ok\n");
            }
            else
            {
                printf("algo salio mal\n");
            }
            system("pause");
            system("cls");
            break;
        case 4:
            mostrarElectroMarca(listaElectro,TAMELECTRO,listaMarca,TAMMARCA);
            ordenarPorElec(listaElectro,TAMELECTRO);
            mostrarElectroMarca(listaElectro,TAMELECTRO,listaMarca,TAMMARCA);
            system("pause");
            system("cls");
            break;
        case 5:
            mostrarMarca(listaMarca,TAMMARCA);
            system("pause");
            system("cls");
            break;
        case 6:
            mostrarServicio(listaServicio,TAMSERVICIO);
            system("pause");
            system("cls");
            break;
        case 7:
            altaReparacionCompleto(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,&idIncrementado,listaCliente,TAMCLIENTE);
            system("pause");
            system("cls");
            break;
        case 8:
            mostrarCompleto(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
            system("pause");
            system("cls");
            break;
        case 9:
            do
            {
                opcionMenuInformes= opcionesMenuInformes();

                switch (opcionMenuInformes)
                {
                case 1:
                    mostrarElectroMarcaAnio2020(listaElectro,TAMELECTRO,listaMarca,TAMMARCA);
                    system("pause");
                    system("cls");
                    break;
                case 2:
                    mostrarElectroPorMarcaSeleccionada(listaElectro,TAMELECTRO,listaMarca,TAMMARCA);
                    system("pause");
                    system("cls");
                    break;

                case 3:
                    mostrarReparacionesElectros(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 4:
                  mostrarElectroSinReparacion(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 5:
                    mostrarElectroTotal(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 6:
                    mostrarReparacionServicioMasPedido(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO);
                    system("pause");
                    system("cls");
                    break;
                case 7:
                    mostrarFacturacionPorFecha(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 8:
                    mostrarReparacionesElectrosGarantia(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 9:
                    mostrarReparacionesElectrosModelo2018(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 10:
                    mostrarFacturacionMantenimiento(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 11:
                    //mostrarElectroConMasRefacciones(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                case 12:
                    //mostrarElectroConMasRefacciones(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                }// final switch

            }//final while
            while (opcionMenuInformes != 13);
            break;
        }// final switch

    }//final while
    while (opcion != 10);


    return 0;
}

