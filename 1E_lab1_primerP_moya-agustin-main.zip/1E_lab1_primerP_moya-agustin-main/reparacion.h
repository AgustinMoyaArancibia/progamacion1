#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utn.h"
#define OCUPADO 1
#define LIBRE 0

typedef struct
{
  int id;
  int cantidadServicios;
} eCantidadServicios;

typedef struct
{
    int idCliente;
    char nombre[51];
    char apellido[51];
    int estado;
}eClientes;


typedef struct
{
    int dia;
    int mes;
    int anio;
}eFechaReparacion;


typedef struct
{
    int id;
    char descripcion[51];
    float precio;
    int estado;
}eServicio;

typedef struct
{
    int idReparacion;
    int numeroSerie;
    int idServicio;
    eFechaReparacion fechaReparacion;
    int idCliente;
    int estado;
}eReparacion;

int mostrarServicio(eServicio listaServicio[], int tamS);
void harcodearReparaciones(eReparacion listaReparacion[]);
void harcodearServicios(eServicio listaServicio[]);
int inicializarServicios(eServicio listaServicio[], int tamS);
int inicializarReparaciones(eReparacion listaReparacion[], int tamR);
int buscarSerieReparacion(eReparacion listaReparacion[], int tamR, int serie);
int buscarLibreReparacion(eReparacion listaReparacion[], int tamR);
int mostrarReparacionServicio(eReparacion listaReparacion[], int tamR, eServicio listaServicio[], int tamS);
int altaReparacionServicio(eReparacion listaReparacion[], int tamR, int* idAsiganado, eServicio listaServicio[] , int tamS);
int buscarIdReparacion(eReparacion listaReparacion[], int tamR, int id);
int bajaReparacion(eReparacion listaReparaciones[], int tamR,eServicio listaServicio[], int tamS);
int modificarReparacion(eReparacion listaReparacion[], int tamR,eServicio listaServicio[], int tamS);
void harcodearClientes(eClientes listaCliente[]);
int mostrarClientes(eClientes listaCliente[],int tamC);
int inicializaCliente(eClientes listaCliente[], int tamC);
int mostrarReparacionServicioMasPedido(eReparacion listaReparacion[], int tamR, eServicio listaServicio[], int tamS);
