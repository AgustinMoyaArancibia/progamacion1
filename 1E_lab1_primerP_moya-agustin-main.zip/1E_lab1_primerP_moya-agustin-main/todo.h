
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utn.h"
#include "reparacion.h"
#include "electrodomestico.h"
#include "cliente.h"
int altaReparacionCompleto(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM,int* idAsiganado,eClientes listaCliente[] , int tamC);
void mostrarCompleto(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);
void mostrarReparacionesElectros(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);
void mostrarElectroSinReparacion(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);
void mostrarReparacionesElectrosModelo2018(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);
void mostrarElectroTotal(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);
void mostrarFacturacionMantenimiento(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);
void mostrarReparacionesElectrosGarantia(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);
void mostrarFacturacionPorFecha(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);
void mostrarElectroConMasRefacciones(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);
