
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utn.h"
#define OCUPADO 1
#define LIBRE 0

typedef struct
{
  int id;
  int cantidadElectro;
} eCantidadElectro;

typedef struct
{
    int idMarca;
    char descripcionMarca[51];
    int estado;
}eMarca;

typedef struct
{
    int idElectromestico;
    int serieElectrodomestico;
    int idMarca;
    int anioModelo;
    int estado;
}eElecotrodomestico;


void harcodearMarcas(eMarca listaMarca[]);
void harcodearElectrodomesticos(eElecotrodomestico listaElectro[]);
int mostrarElectroMarca(eElecotrodomestico listaElectro[], int tamE, eMarca listaMarca[], int tamM);
int inicializarElectro(eElecotrodomestico listaElectro[], int tamE);
int buscarIdClientes(eElecotrodomestico listaElectro[], int tamE, int id);
int buscarLibreElectro(eElecotrodomestico listaElectro[], int tamE);
int inicializarMarca(eMarca listaMarca[], int tamM);
int mostrarMarca(eMarca listaMarca[], int tamM);
int altaElectrodomesticosMarca(eElecotrodomestico listaElectro[], int tamE, int* idAsiganado, eMarca listaMarca[] , int tamM);
int buscarIdElectro(eElecotrodomestico listaElectro[], int tamE, int id);
int modificarElectro(eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[], int tamM);
int bajaElectro(eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[], int tamM);
void ordenarPorElec(eElecotrodomestico listaElectro[],int tamE );
int mostrarElectroMarcaAnio2020(eElecotrodomestico listaElectro[], int tamE, eMarca listaMarca[], int tamM);
int mostrarElectroPorMarcaSeleccionada(eElecotrodomestico listaElectro[], int tamE, eMarca listaMarca[], int tamM);


