#include "reparacion.h"


int mostrarReparacionServicioMasPedido(eReparacion listaReparacion[], int tamR, eServicio listaServicio[], int tamS)
{

    int i;
    int j;
    int retorno = -1;
    int maximo = 0;
    eCantidadServicios auxSer[tamS];

    for(i=0; i<tamS; i++)
    {
        auxSer[i].id = listaServicio[i].id; // copio el id de la estructura en el auxiliar para usar
        auxSer[i].cantidadServicios = 0;
    }


    for(i=0; i<tamS; i++)
    {
        for(j=0; j<tamR; j++)
        {
            if(listaReparacion[j].estado == OCUPADO && listaServicio[i].estado == OCUPADO && listaReparacion[j].idServicio == auxSer[i].id)    //igualo los id y el estado
            {
                auxSer[i].cantidadServicios++;
            }
        }

    }

    for(i=0; i<tamS; i++)
    {
        if( i == 0|| auxSer[i].cantidadServicios > maximo)
        {
            maximo = auxSer[i].cantidadServicios;
        }
    }





    printf("   descripcion     precio  \n");
    for(i=0; i<tamS ; i++)
    {
        for(j=0; j<tamS ; j++)
        {
            if(
                listaServicio[j].estado == OCUPADO &&
                auxSer[i].id == listaServicio[j].id &&
                auxSer[i].cantidadServicios == maximo
            )
            {
                printf("\n el mas pedido fue :  %15s %10.2f  \n",listaServicio[j].descripcion,listaServicio[j].precio);
                retorno = 0;
            }
        }
    }
    return retorno;
}


int modificarReparacion(eReparacion listaReparacion[], int tamR,eServicio listaServicio[], int tamS)
{
    int id;
    int esta;
    int opcionModificar;
    int retorno ;

    mostrarReparacionServicio(listaReparacion,tamR,listaServicio,tamS);


    id = getInt("ingrese el id que desea modificar\n","ERROR id entre 1 y 10\n",1,10);


    esta = buscarIdReparacion(listaReparacion,tamR,id);


    if(esta == -1)
    {
        printf("el id elegido no esta registrado\n");
        retorno = -1;

    }
    else
    {

        do
        {

            printf("Que opcion quiere cambiar?\n");
            printf("1.numero de serie\n");
            printf("2.servicio\n");
            printf("3.fecha\n");
            printf("4.guardar modificaciones\n");
            scanf("%d", &opcionModificar);

            while(opcionModificar < 1 || opcionModificar> 4)
            {
                printf("ERROR Elija una opcion:\n ");
                fflush(stdin);
                scanf("%d", &opcionModificar);
            }


            switch(opcionModificar)
            {
            case 1:
                listaReparacion[esta].numeroSerie = getInt("ingrese nuevo numero de serie entre 300 y 305\n", "ERRROR\n",300,305);
                printf("numero de serie cambiado\n");
                break;
            case 2:
                mostrarServicio(listaServicio,tamS);
                listaReparacion[esta].idServicio = getInt("ingrese nuevo sevicio entre 20000 y 20005\n","Errorr\n",20000,20005);
                printf("servicio cambiado\n");
                break;
            case 3:
                listaReparacion[esta].fechaReparacion.dia = getInt("eliga dia del mes entre 1 a 31\n", "ERROR numero invalido\n",0,31);
                listaReparacion[esta].fechaReparacion.mes = getInt("eliga mes del a�o entre 1 a 12\n", "ERROR numero invalido\n",0,12);
                listaReparacion[esta].fechaReparacion.anio = getInt("elija a�o 2020 - 2021\n", "ERROR numero invalido\n",2020,2021);
                printf("fecha cambiad\n");
                break;

                retorno= 1;
            }
        }
        while(opcionModificar != 4);


    }
    return retorno;
}
int bajaReparacion(eReparacion listaReparaciones[], int tamR,eServicio listaServicio[], int tamS)
{
    int id;
    char confirma;
    int retorno = -1;
    int esta;
//    int i;


    mostrarReparacionServicio(listaReparaciones,tamR, listaServicio,tamS);

    id = getInt("ingrese id de la reparacion\n","ERROR id invalido 1 y 10\n",1,10);

    esta = buscarIdReparacion(listaReparaciones,tamR,id); // si da -1 es porque el id no existe
    // sino muestra el indice de donde se encuentra el id

    if( esta == -1)
    {
        printf("el numero de id no existe\n");
    }
    else
    {
        printf("usted eligio este numero :%d\n",id);

        confirma=getChar("acepta la baja? s/n  \n","ERROR \n",'s','n');


        if ( confirma == 's' )
        {
            listaReparaciones[esta].estado = LIBRE;
            /*for( i=0; i<tamS ; i++)
            {
               if(id == listaServicio[i].id )
               {
                   listaServicio[i].estado = LIBRE;
                   break;
               }
            }*/

            retorno = 0;//baja
        }

        if (confirma == 'n')
        {
            retorno = -1; //no baja
        }



    }
    return retorno;
}


int altaReparacionServicio(eReparacion listaReparacion[], int tamR, int* idAsiganado, eServicio listaServicio[], int tamS)
{
    int retorno = -1;
    int indice;
    int id;
    eReparacion nuevaReparacion;
    int opcionServicio;

    id = *idAsiganado; // le paso el valor dado a id
    indice = buscarLibreReparacion(listaReparacion, tamR);

    printf("*** Alta reparacion ***\n\n");

    if( indice == -1)
    {

        printf("No hay lugar en el sistema\n\n");
        system("pause");
    }
    else
    {

        nuevaReparacion.idReparacion = id;
        *idAsiganado = id+1; //el puntero que voy a llevar al main, le aumento el id +1
        nuevaReparacion.numeroSerie = getInt("ingrese numero de serie entre 300 y 305\n", "ERROR numero de serie mal\n",300,305);

        mostrarServicio(listaServicio,tamS);
        opcionServicio = getInt("eliga id del servicio\n", " ERROR id ivalido\n",20000,20005);
        nuevaReparacion.idServicio = opcionServicio;
        nuevaReparacion.fechaReparacion.dia = getInt("eliga dia del mes entre 1 a 31\n", "ERROR numero invalido\n",0,31);
        nuevaReparacion.fechaReparacion.mes = getInt("eliga mes del a�o entre 1 a 12\n", "ERROR numero invalido\n",0,12);
        nuevaReparacion.fechaReparacion.anio = getInt("elija a�o 2020 - 2021\n", "ERROR numero invalido\n",2020,2021);

        nuevaReparacion.estado = OCUPADO;

        listaReparacion[indice] = nuevaReparacion;
        retorno = 0;
    }
    return retorno;
}



int mostrarServicio(eServicio listaServicio[], int tamS)
{

    int j;

    int retorno = -1;

    printf("    idServicio        descripcion     precio \n");

    for(j=0; j<tamS ; j++)
    {
        if(listaServicio[j].estado == OCUPADO )
        {
            printf("\n %15d  %15s %10.2f  \n",
                   listaServicio[j].id,
                   listaServicio[j].descripcion,
                   listaServicio[j].precio);
            retorno = 0;
        }
    }

    return retorno;
}
int mostrarReparacionServicio(eReparacion listaReparacion[], int tamR, eServicio listaServicio[], int tamS)
{

    int i;
    int j;
    int retorno = -1;

    printf("idReparacion   numSerie    idServicio      fecha      descripcion     precio  \n");
    for(i=0; i<tamR ; i++)
    {
        for(j=0; j<tamS ; j++)
        {
            if(listaReparacion[i].estado == OCUPADO &&
                    listaServicio[j].estado == OCUPADO &&
                    listaReparacion[i].idServicio == listaServicio[j].id)
            {
                printf("\n %d  %15d %15d     %d-%d-%d  %15s %10.2f  \n",
                       listaReparacion[i].idReparacion,
                       listaReparacion[i].numeroSerie,
                       listaReparacion[i].idServicio,
                       listaReparacion[i].fechaReparacion.dia,
                       listaReparacion[i].fechaReparacion.mes,
                       listaReparacion[i].fechaReparacion.anio,
                       listaServicio[j].descripcion,
                       listaServicio[j].precio);
                retorno = 0;
            }
        }
    }
    return retorno;
}


void harcodearReparaciones(eReparacion listaReparacion[])
{
    int i;
    eReparacion reparaciones[]=
    {
        {1,300,20003,{10,05,2020},500,OCUPADO},
        {2,301,20001,{10,06,2020},501,OCUPADO},
        {3,302,20002,{10,07,2020},502,OCUPADO},
        {4,303,20000,{10,02,2020},503,OCUPADO},
        {5,304,20001,{10,04,2020},504,OCUPADO}
    };

    for( i=0; i < 5 ; i++)
    {

        listaReparacion[i] = reparaciones[i];
    }
}


void harcodearServicios(eServicio listaServicio[])
{
    int i;
    eServicio servicios[]=
    {
        {20000,"garantia",250,OCUPADO},
        {20001,"mantenimiento",500,OCUPADO},
        {20002,"repuesto",400,OCUPADO},
        {20003,"refaccion",600,OCUPADO}
    };

    for( i=0; i < 4 ; i++)
    {

        listaServicio[i] = servicios[i];
    }
}



int inicializarServicios(eServicio listaServicio[], int tamS)
{
    int i;
    int retorno = -1;
    for(i=0; i<tamS; i++)
    {

        listaServicio[i].estado = LIBRE;
        retorno = 0;
    }
    return retorno;
}

int inicializarReparaciones(eReparacion listaReparacion[], int tamR)
{
    int i;
    int retorno = -1;
    for(i=0; i<tamR; i++)
    {

        listaReparacion[i].estado = LIBRE;
    }
    return retorno;
}
int buscarSerieReparacion(eReparacion listaReparacion[], int tamR, int serie)
{

    int indice = -1;

    for(int i=0; i<tamR; i++)
    {
        if(listaReparacion[i].estado == OCUPADO && listaReparacion[i].numeroSerie == serie)
        {
            indice = i;
            break;
        }
    }


    return indice;

}
int buscarIdReparacion(eReparacion listaReparacion[], int tamR, int id)
{

    int indice = -1;

    for(int i=0; i<tamR; i++)
    {
        if(listaReparacion[i].estado == OCUPADO && listaReparacion[i].idReparacion == id)
        {
            indice = i;
            break;
        }
    }


    return indice;

}
int buscarLibreReparacion(eReparacion listaReparacion[], int tamR)
{
    int i;
    int index = -1;
    for(i=0; i<tamR; i++)
    {
        if(listaReparacion[i].estado == LIBRE)
        {
            index = i;
            break;
        }
    }
    return index;
}


void harcodearClientes(eClientes listaCliente[])
{
    int i;
    eClientes clientes[]=
    {
        {500,"carlos","kapa",OCUPADO},
        {501,"trigo","metro",OCUPADO},
        {502,"laura","mel",OCUPADO},
        {503,"gasto","plata",OCUPADO},
        {504,"miriam","cejas",OCUPADO}
    };

    for( i=0; i < 5 ; i++)
    {

        listaCliente[i] = clientes[i];
    }
}

int mostrarClientes(eClientes listaCliente[],int tamC)
{
    int i;
    int retorno = -1;

    printf("idCliente    nombre apellido \n");
    for(i=0; i<tamC ; i++)
    {
        if(listaCliente[i].estado == OCUPADO )
        {
            printf("\n %d  %10s %10s  \n",
                   listaCliente[i].idCliente,
                   listaCliente[i].nombre,
                   listaCliente[i].apellido);
            retorno = 1;
        }

    }

    return retorno;
}

int inicializaCliente(eClientes listaCliente[], int tamC)
{
    int i;
    int retorno = -1;
    for(i=0; i<tamC; i++)
    {

        listaCliente[i].estado = LIBRE;
        retorno = 0;
    }
    return retorno;
}
