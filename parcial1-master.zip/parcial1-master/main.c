#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

#include "clientes-mascostas.razas.h"

#define TC 15
#define TM 20
#define TR 11

#define OCUPADO 1
#define LIBRE 0







int main()
{

    int opcion;
    int retornoAltaMascotas;
    int retornoBajaMascotas;
    int retornoModificarMascotas;
    int retornoBajaCliente;
    int retornoModificarCliente;
    float promedioEdadesMascotas;
    float promedioEdadesMascotasTipo;


    eClientes listaClientes[TC];
    eMascotas listaMascotas[TM];
    eRaza listaRazas[TR];

    inicializarMascotas(listaMascotas,TM);
    inicializarClientes(listaClientes,TC);
    inicializaRaza(listaRazas,TR);

    harcodearClientes(listaClientes);
    harcodearMascotas(listaMascotas);
    harcodeaRazas(listaRazas);


    do
    {
        opcion= menuPrincipal();


        switch (opcion)
        {
        case 1:
            mostrarListaClientes(listaClientes,TC);
            system("pause");
            system("cls");
            break;
        case 2:
            mostrarListaMascotaS(listaMascotas,TM,listaClientes,TC,listaRazas,TR);
            system("pause");
            system("cls");
            break;

        case 3:
            mostrarClientesConMoscotas(listaMascotas,TM,listaClientes,TC);
            system("pause");
            system("cls");
            break;
        case 4:
            retornoAltaMascotas = altaMascota(listaMascotas,TM,listaClientes,TC,listaRazas,TR);

            switch(retornoAltaMascotas)
            {
            case 1:
                printf("se dio de alta\n");
                break;
            case -1:
                printf("alta cancelada\n");
                break;
            }
            system("pause");
            system("cls");
            break;
        case 5:
            retornoBajaMascotas = eliminarMascota(listaMascotas,TM);
            switch(retornoBajaMascotas)
            {
            case 1:
                printf("se dio de BAJA\n");
                break;
            case -1:
                printf("BAJA  cancelada\n");
                break;
            }
            system("pause");
            system("cls");
            break;
        case 6:
            retornoModificarMascotas = modificarMascota(listaMascotas,TM,listaRazas,TR,listaClientes,TC);
            switch(retornoModificarMascotas)
            {
            case 1:
                printf("se modifico\n");
                break;
            case -1:
                printf("no se modifico\n");
                break;
            }
            system("pause");
            system("cls");
            break;
        case 7:
            altaCliente(listaClientes,TC);
            system("cls");
            break;
        case 8:
            retornoBajaCliente = eliminarCliente(listaClientes,TC,listaMascotas,TM);

            switch(retornoBajaCliente)
            {
            case 1:
                printf("se dio de baja\n");
                break;
            case -1:
                printf("se cancelo la baja\n");
                break;
            }
            system("pause");
            system("cls");
            break;
        case 9:
            ordenarPorRaza(listaMascotas,TM,listaClientes,TC);
            system("pause");
            system("cls");
            break;
        case 10:
            retornoModificarCliente =  modificarCliente(listaClientes,TC);
            switch(retornoModificarCliente)
            {
            case 1:
                printf("se modifico\n");
                break;
            case -1:
                printf("no se modifico\n");
                break;
            }

            system("pause");
            system("cls");
            break;
        case 11:
            mostrarClientesConMasDeUnaMascota(listaMascotas,TM,listaClientes,TC);
            system("pause");
            system("cls");
            break;
        case 12:
            ListarMascotaMayorTresAnios(listaMascotas,TM,listaClientes,TC);
            system("pause");
            system("cls");
            break;
        case 13:
            mostrarListaMascotasPorTipo(listaMascotas,TM);
            system("pause");
            system("cls");
            break;
        case 14:
            ordenarClientesPorCantidadesMascotas(listaMascotas,TM,listaClientes,TC);

            system("pause");
            system("cls");
            break;
        case 15:
            ordenarClientesPorCantidadesMascotasYNombre(listaMascotas,TM,listaClientes,TC);
            system("pause");
            system("cls");
            break;

        case 16:
            promedioEdadesMascotas = mostrarPromedioDeEdadesMascotas(listaMascotas,TM);
            printf("el promedio de edades de las mascotas es: %.2f\n",promedioEdadesMascotas);
            system("pause");
            system("cls");
            break;

        case 17:
            promedioEdadesMascotasTipo =  mostrarListaMascotasPorTipoYedad(listaMascotas,TM);
            printf(" promedio del tipo seleccionado es : %.2f\n", promedioEdadesMascotasTipo);
            system("pause");
            system("cls");
            break;
        case 18:
            promedioEntreVaronesYmujeresDeClientes(listaClientes,TC);
            system("pause");
            system("cls");
            break;
         case 19:
            mostrarListaClienesConMascotasMismoSexo(listaMascotas,TM, listaClientes,TC, listaRazas, TR);
            system("pause");
            system("cls");
            break;

        }// final switch

    }//final while
    while (opcion != 20);



    return 0;
}





