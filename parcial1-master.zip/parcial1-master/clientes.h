#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#define OCUPADO 1
#define LIBRE 0





typedef struct
{
    char nombre[20];
    char apellido[20];
    char localidad[20];
    int telefono;
    int edad;
    char sexo;
    int idCliente;



    int estado;

} eClientes;

void harcodearClientes(eClientes listadoClientes[]);
void mostrarListaClientes(eClientes listaClientes[], int tamC);
void inicializarClientes(eClientes listadoClientes[], int tamC);
int buscarIdClientes(eClientes listaClientes[], int tamC, int id);
int buscarLibreCliente(eClientes listaClientes[], int tamC);
void altaCliente(eClientes listaClienteCliente[], int tamC);
int modificarCliente(eClientes listadoClientes[], int tamC);
void promedioEntreVaronesYmujeresDeClientes(eClientes listaClientes[], int tamC);
