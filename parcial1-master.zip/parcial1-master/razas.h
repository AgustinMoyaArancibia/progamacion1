#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#define OCUPADO 1
#define LIBRE 0

typedef struct
{
    char nombreRaza[30];
    char pais[30];
    int idRaza;
    int estado;

}eRaza;

void harcodeaRazas(eRaza listadoRaza[]);
void inicializaRaza(eRaza listaRaza[], int tamR);
void mostrarListaRazas(eRaza listaRaza[], int tamR);
void mostrarTipoDeRazas(eRaza listaRaza[], int tamR);
