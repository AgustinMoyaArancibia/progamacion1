
#include "clientes.h"
#include "mascotas.h"
#include "razas.h"
#include "fucionesUTN.h"
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

#define OCUPADO 1
#define LIBRE 0




int menuPrincipal();

int eliminarCliente(eClientes listadoClientes[], int tamC, eMascotas listadoMascotas[], int tamM);
void ordenarPorRaza(eMascotas listaMascotas[],int tamM, eClientes listadoClientes[], int tamC );
void mostrarClientesConMasDeUnaMascota(eMascotas listaMascotas[], int tamM,eClientes listaClientes[], int tamC);
void ListarMascotaMayorTresAnios(eMascotas listaMascotas[], int tamM,eClientes listaClientes[], int tamC);
void ordenarClientesPorCantidadesMascotas(eMascotas listaMascotas[],int tamM, eClientes listadoClientes[], int tamC );
void ordenarClientesPorCantidadesMascotasYNombre(eMascotas listaMascotas[],int tamM, eClientes listaClientes[], int tamC );
void mostrarClientesConMoscotas(eMascotas listaMascotas[], int tamM,eClientes listaClientes[], int tamC);

int modificarMascota(eMascotas listadoMascotas[], int tamM, eRaza listaRaza[], int tamR, eClientes listaCliente[], int tamC);
void mostrarListaMascotaS(eMascotas listaMascotas[], int tamM,eClientes listaClientes[], int tamC, eRaza listaRaza[], int tamR);
void mostrarListaClienesConMascotasMismoSexo(eMascotas listaMascotas[], int tamM,eClientes listaClientes[], int tamC, eRaza listaRaza[], int tamR);
int altaMascota(eMascotas listaMascota[],int tamM,eClientes listaCliente[], int tamC, eRaza listaRaza[], int tamR);

