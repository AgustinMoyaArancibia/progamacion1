#include "mascotas.h"
#include "fucionesUTN.h"


#define OCUPADO 1
#define LIBRE 0

void harcodearMascotas(eMascotas listadoMascotas[])
{


    int i;
    eMascotas mascotas[]=
    {
        {"luana","perro",2,12,'f',104,OCUPADO,1,300},
        {"pepo","pajaro",3,2,'m',104,OCUPADO,2,301},
        {"quiot","lagarto",5,12,'f',103,OCUPADO,3,302},
        {"sapon","iguana",10,12,'m',103,OCUPADO,4,303},
        {"rino","perro",8,12,'m',101,OCUPADO,5,304},
        {"balnca","gato",2,12,'f',104,OCUPADO,6,305},
        {"azul","gato",6,12,'f',102,OCUPADO,7,306},
        {"verde","gato",2,12,'m',102,OCUPADO,8,307},
        {"tragon","perro",5,12,'f',102,OCUPADO,9,308},
        {"osil","perro",5,12,'f',105,OCUPADO,10,309},
        {"mara","gato",1,12,'f',105,OCUPADO,11,310}
    };

    for( i=0; i < 11 ; i++)
    {

        listadoMascotas[i] = mascotas[i];
    }
}



int buscarLibreMascota(eMascotas listadoMascotas[], int tamM)
{
    int i;
    int index = -1;
    for(i=0; i<tamM; i++)
    {
        if(listadoMascotas[i].estado == LIBRE)
        {
            index = i;
            break;
        }
    }
    return index;
}
void mostrarListaMascotas(eMascotas listaMascotas[], int tamM)
{

    int i; //mascotas


    printf("     nombre      tipo    edad    peso     sexo      id mascota");



    for(i=0; i<tamM ; i++)
    {

        if(listaMascotas[i].estado == OCUPADO )
        {
            printf("\n%10s   %8s    %4d   %5.2f   %5c  %10d\n", listaMascotas[i].nombre,
                   listaMascotas[i].TipoDeMascota,
                   listaMascotas[i].edad,
                   listaMascotas[i].peso,
                   listaMascotas[i].sexo,
                   listaMascotas[i].idMascota);
        }
    }




}

int buscarIdMascotas(eMascotas listadoMascotas[], int tamM, int id)
{


    int indice = -1;

    for(int i=0; i<tamM; i++)
    {
        if(listadoMascotas[i].estado == OCUPADO && listadoMascotas[i].idMascota == id)
        {
            indice = i;
            break;
        }
    }


    return indice;

}

int eliminarMascota(eMascotas listadoMascotas[], int tamM)
{
    int id;
    char confirma;
    int retorno = -1;
    int esta;

    mostrarListaMascotas(listadoMascotas,tamM);

    id = getInt("ingrese id de la mascota\n","ERROR id invalido 1 y 20\n",1,20);

    esta = buscarIdMascotas(listadoMascotas,tamM,id); // si da -1 es porque el id no existe
    // sino muestra el indice de donde se encuentra el id

    if( esta == -1)
    {
        printf("el numero de id no existe\n");
    }
    else
    {
        printf("usted eligio este numero :%d\n",id);

        confirma=getChar("acepta la baja? s/n  \n","ERROR \n",'s','n');

        printf(" confirma : %c\n", confirma);
        switch(confirma)
        {
        case 's':
            listadoMascotas[esta].estado = LIBRE;
            retorno = 1;//baja
            break;
        case 'n':
            retorno = -1; //no baja
        }

    }
    return retorno;
}





void inicializarMascotas(eMascotas listadoMascotas[], int tamM)
{
    int i;
    for(i=0; i<tamM; i++)
    {

        listadoMascotas[i].estado = LIBRE;
    }
}

void obtenerTipoMascota(eMascotas listaMascotas[], int tamM, int idMascotas, char cadena[])
{
    int i;
    for( i=0; i < tamM; i++)
    {

        if( listaMascotas[i].idMascota == idMascotas)
        {
            strcpy(cadena, listaMascotas[i].TipoDeMascota);
        }
    }

}

float mostrarPromedioDeEdadesMascotas(eMascotas listaMascotas[], int tamM)
{
    int i;
    int cantitadEdad = 0;
    int contador= 0;
    float promedioEdad;
    for (i = 0; i<tamM ; i++)
        {
        if(listaMascotas[i].estado == OCUPADO )
        {
            contador++;
            cantitadEdad = cantitadEdad + listaMascotas[i].edad;
        }
        //printf("cantidad de edades : %d --- cantidad de animales . %d\n", contador, cantitadEdad);
    }

    promedioEdad =(float)  cantitadEdad / contador;

    return promedioEdad;
}

void mostrarTipoDeMascotas(eMascotas listaMascotas[], int tamM)
{
    int i;

    for(i=0; i<tamM; i++)
        {
            if(listaMascotas[i].estado == OCUPADO)
                {
                    printf("tipo de mascotas : %s \n", listaMascotas[i].TipoDeMascota);
                }
        }
}



void mostrarListaMascotasPorTipo(eMascotas listaMascotas[], int tamM)
{


    int j; //clientes
    char tipoMascota[30];
    int flag = 0;


    mostrarTipoDeMascotas(listaMascotas,tamM);

    getString("elija tipo de mascota\n",tipoMascota);



    printf("nombre              tipo           edad     peso    sexo    id mascota\n");

    for(j=0; j<tamM; j++)
    {

            if( listaMascotas[j].estado == OCUPADO  && stricmp(tipoMascota,listaMascotas[j].TipoDeMascota)==0)
            {
                printf("\n|%s    \t|      %s\t|  %d\t| %.2f\t|    %c\t|     %d \t |\n",
                       listaMascotas[j].nombre,
                       listaMascotas[j].TipoDeMascota,
                       listaMascotas[j].edad,
                       listaMascotas[j].peso,
                       listaMascotas[j].sexo,
                       listaMascotas[j].idMascota);
                        flag = 1;
            }

    }

     if (flag == 0)
                {
                    printf("no hay resultados\n");
                }

}

float mostrarListaMascotasPorTipoYedad(eMascotas listaMascotas[], int tamM)
{


    int i; //clientes
    char tipoMascota[30];
    int flag = 0;
    float promedioEdad;
    int contador = 0;
    int cantitadEdad =0;
    mostrarTipoDeMascotas(listaMascotas,tamM);

    getString("elija tipo de mascota\n",tipoMascota);


    for(i=0; i<tamM; i++)
    {
        if(listaMascotas[i].estado == OCUPADO && stricmp(tipoMascota,listaMascotas[i].TipoDeMascota)==0)
        {
            contador++;
            cantitadEdad = cantitadEdad + listaMascotas[i].edad;

            printf("contador : %d --- cantidad : %d \n",contador,cantitadEdad);
            flag =1;
        }

    }

    if (flag == 0)
    {
        printf("no hay resultados\n");
    }

    return  promedioEdad =(float)  cantitadEdad / contador;  //promedioEdad =(float) contador / cantitadEdad;

}



