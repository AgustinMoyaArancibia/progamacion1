#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

typedef struct
{
  int idMascota;
  int cantidadMascota;
} eAux;


/*
Agregamos la estructura RAZA (nombre de raza, pa�s )
{pastor , alem�n}{lagarto overo, argentina}{gato,persa}...
como m�nimo 2 dos raza por tipo
*/



typedef struct
{
    char nombre[20];
    char TipoDeMascota[20];

    //char raza[20];
    int edad;
    float peso;
    char sexo;
    int idCliente;
    int estado;
    int idMascota;
    int idRaza;


} eMascotas;



void harcodearMascotas(eMascotas listadoMascotas[]);
int buscarLibreMascota(eMascotas listadoMascotas[], int tamM);
void mostrarListaMascotas(eMascotas listaMascotas[], int tamM);
void inicializarMascotas(eMascotas listadoMascotas[], int tamM);
int buscarIdMascotas(eMascotas listadoMascotas[], int tamM, int id);

int eliminarMascota(eMascotas listadoMascotas[], int tamM);
void obtenerTipoMascota(eMascotas listaMascotas[], int tamM, int idMascotas, char cadena[]);
float mostrarPromedioDeEdadesMascotas(eMascotas listaMascotas[], int tamM);
void mostrarTipoDeMascotas(eMascotas listaMascotas[], int tamM);
void mostrarListaMascotasPorTipo(eMascotas listaMascotas[], int tamM);
float mostrarListaMascotasPorTipoYedad(eMascotas listaMascotas[], int tamM);


