#include "clientes-mascostas.razas.h"


int menuPrincipal()
{
    int opcion;

    printf("---primera parte---\n\n");
    printf ("1.mostrar clientes\n");
    printf ("2.mostrar  mascotas\n");
    printf ("3.mostrar clientes con sus mascotas\n");
    printf("\n---segunda parte---\n\n");
    printf ("4.alta mascota\n");
    printf ("5.baja mascota\n");
    printf ("6.modificar mascota\n");
    printf("\n---tercera parte---\n\n");
    printf ("7.alta cliente\n");
    printf ("8.eliminar cliente\n");
    printf ("9.ordenar por tipo de mascota\n");
    printf("\n---cuarta parte---\n\n");
    printf ("10.modificar cliente\n");
    printf ("11.listar clientes con mas de unas mascota\n");
    printf ("12.listar mascotas mayores de 3 anios\n");
    printf("\n---quinta parte---\n\n");
    printf ("13.listar mascotas segun el tipo\n");
    printf ("14.ordenar clientes por cantidad de mascotas\n");
    printf ("15.ordenar clientes por cantidad de mascotas orden alfabetico \n");
    printf ("16.promedio de edad entre las mascotas\n");
    printf ("17.promedio de edad entre tipo de mascotas\n");
    printf ("18.el promedio que tengo entre varones y mujeres de mis clientes\n");
    printf ("19.mostrar clientes con mascotas por sexo\n");
    printf ("20.salir\n");
    opcion = getInt("ingrese numero del menu entrer el 1 y el 20\n","ERROR \n",0,20)   ;
    system("cls");
    return opcion;
}





void mostrarClientesConMoscotas(eMascotas listaMascotas[], int tamM,eClientes listaClientes[], int tamC)
{
    int i;
    int j; //mascotas
    char flagEntra;

    printf("cliente     animal         raza \n");

    for(i=0; i<tamC; i++)
    {
        if(listaClientes[i].estado == OCUPADO)
        {
            printf("\n%s\n", listaClientes[i].nombre);
        }


        flagEntra='n';
        for(j=0; j<tamM; j++)
        {
            if(listaMascotas[j].idCliente == listaClientes[i].idCliente && listaClientes[i].estado == OCUPADO &&listaMascotas[j].estado== OCUPADO )
            {
                printf(" %15s %15s \n", listaMascotas[j].nombre, listaMascotas[j].TipoDeMascota);
                flagEntra = 's';

            }

        }

    }
    if(flagEntra == 'n')
    {
        printf("no tiene productos\n\n");

    }
}

int eliminarCliente(eClientes listadoClientes[], int tamC, eMascotas listadoMascotas[], int tamM)
{
    int id;
    char confirma;
    int retorno = -1;
    int esta;
    int i;

    mostrarListaClientes(listadoClientes,tamC);

    id = getInt("ingrese id del cliente\n","ERROR id invalido 100 y 200\n",100,200);

    esta = buscarIdClientes(listadoClientes,tamC,id); // si da -1 es porque el id no existe
    // sino muestra el indice de donde se encuentra el id

    if( esta == -1)
    {
        printf("el numero de id no existe\n");
    }
    else
    {
        printf("usted eligio este numero :%d\n",id);

        confirma=getChar("acepta la baja? s/n  \n","ERROR \n",'s','n');

        printf(" confirma : %c\n", confirma);

        if ( confirma == 's' )
        {
            listadoClientes[esta].estado = LIBRE;

            for( i=0; i<tamM ; i++)
            {
                if(id == listadoMascotas[i].idCliente )
                {
                    listadoMascotas[i].estado = LIBRE;
                }
            }

            retorno = 1;//baja
        }

        if (confirma == 'n')
        {
            retorno = -1; //no baja
        }



    }
    return retorno;
}

void ordenarPorRaza(eMascotas listaMascotas[],int tamM, eClientes listadoClientes[], int tamC )
{
    int i;
    int j;

    eMascotas auxM;


    for(i=0; i<tamM-1; i++)
    {

        for(j=i+1 ; j<tamM; j++)
        {

            if(strcmp(listaMascotas[i].TipoDeMascota, listaMascotas[j].TipoDeMascota)>0  && listaMascotas[i].estado == OCUPADO && listaMascotas[j].estado == OCUPADO)

            {

                auxM = listaMascotas[i];
                listaMascotas[i] = listaMascotas[j];
                listaMascotas[j] = auxM;

            }
        }
    }


    printf("ordenamiento con exito\n");
}

void mostrarClientesConMasDeUnaMascota(eMascotas listaMascotas[], int tamM,eClientes listaClientes[], int tamC)
{
    eAux auxClientes[tamC];

    int i;
    int j;


    for(i=0; i<tamC; i++)
    {
        auxClientes[i].idMascota = listaClientes[i].idCliente; // copio el id de la estructura en el auxiliar para usar
        auxClientes[i].cantidadMascota = 0;
    }


    for(i=0; i<tamC; i++)
    {
        for(j=0; j<tamM; j++)
        {
            if(listaMascotas[j].estado == OCUPADO && listaClientes[i].estado == OCUPADO && listaMascotas[j].idCliente == auxClientes[i].idMascota) //igualo los id y el estado
            {
                auxClientes[i].cantidadMascota++;

            }
        }
    }


    for(i=0; i<tamC; i++)
    {
        if(listaClientes[i].estado== OCUPADO && auxClientes[i].cantidadMascota > 1 )
        {
            printf("%s\n",listaClientes[i].nombre);
        }
        for(j=0; j<tamM; j++)
        {
            if(listaMascotas[j].idCliente == auxClientes[i].idMascota && auxClientes[i].cantidadMascota > 1)
            {

                printf(" mascotas: %s - %s \n", listaMascotas[j].nombre, listaMascotas[j].TipoDeMascota);

            }
        }
    }
}

void ListarMascotaMayorTresAnios(eMascotas listaMascotas[], int tamM,eClientes listaClientes[], int tamC)
{

    int i; //mascotas
    int j; //clientes

    printf("nombre     tipo          edad     peso           sexo    nombreCliente   id mascota");

    for(j=0; j<tamM; j++)
    {

        for(i=0; i<tamC ; i++)
        {

            if(listaMascotas[j].idCliente == listaClientes[i].idCliente  && listaMascotas[j].estado == OCUPADO && listaClientes[i].estado == OCUPADO && listaMascotas[j].edad >= 3 )
            {
                printf("\n|%s\t|     %s\t|   %d\t|   %.2f\t| %c\t|   %s  \t|   %d\t|\n",
                       listaMascotas[j].nombre,
                       listaMascotas[j].TipoDeMascota,
                       listaMascotas[j].edad,
                       listaMascotas[j].peso,
                       listaMascotas[j].sexo,
                       listaClientes[i].nombre,
                       listaMascotas[j].idMascota);
            }
        }
    }



}

void ordenarClientesPorCantidadesMascotas(eMascotas listaMascotas[],int tamM, eClientes listaClientes[], int tamC )
{
    eAux auxiliarMascotas[tamC];

    int i;
    int j;


    for(i=0; i<tamC; i++)
    {
        auxiliarMascotas[i].idMascota = listaClientes[i].idCliente;
        auxiliarMascotas[i].cantidadMascota = 0;
    }


    for(i=0; i<tamC; i++)
    {
        for(j=0; j<tamM; j++)
        {
            if(listaMascotas[j].estado == OCUPADO && listaClientes[i].estado == OCUPADO && listaMascotas[j].idCliente == auxiliarMascotas[i].idMascota) //igualo los id y el estado
            {
                auxiliarMascotas[i].cantidadMascota++;

            }
        }


    }



    eClientes auxC;
    eAux aux;

    for(i=0; i<tamC -1 ; i++)
    {

        for(j=i+1 ; j<tamC; j++)
        {

            if( listaClientes[i].estado == OCUPADO &&  auxiliarMascotas[i].cantidadMascota > auxiliarMascotas[j].cantidadMascota)
            {

                aux = auxiliarMascotas[i];
                auxiliarMascotas[i] = auxiliarMascotas[j];
                auxiliarMascotas[j] = aux;

                auxC = listaClientes[i];
                listaClientes[i] = listaClientes[j];
                listaClientes[j] = auxC;

            }

        }
    }

    printf("ordenamiento con exito\n");
}

void ordenarClientesPorCantidadesMascotasYNombre(eMascotas listaMascotas[],int tamM, eClientes listaClientes[], int tamC )
{
    eAux auxiliarMascotas[tamC];

    int i;
    int j;


    for(i=0; i<tamC; i++)
    {
        auxiliarMascotas[i].idMascota = listaClientes[i].idCliente;
        auxiliarMascotas[i].cantidadMascota = 0;
    }


    for(i=0; i<tamC; i++)
    {
        for(j=0; j<tamM; j++)
        {
            if(listaMascotas[j].estado == OCUPADO && listaClientes[i].estado == OCUPADO && listaMascotas[j].idCliente == auxiliarMascotas[i].idMascota) //igualo los id y el estado
            {
                auxiliarMascotas[i].cantidadMascota++;

            }
        }


    }



    eClientes auxC;
    eAux aux;

    for(i=0; i<tamC -1 ; i++)
    {

        for(j=i+1 ; j<tamC; j++)
        {

            if( listaClientes[i].estado == OCUPADO &&  auxiliarMascotas[i].cantidadMascota > auxiliarMascotas[j].cantidadMascota)
            {

                aux = auxiliarMascotas[i];
                auxiliarMascotas[i] = auxiliarMascotas[j];
                auxiliarMascotas[j] = aux;

                auxC = listaClientes[i];
                listaClientes[i] = listaClientes[j];
                listaClientes[j] = auxC;

            }
            else
            {
                if(auxiliarMascotas[i].cantidadMascota == auxiliarMascotas[j].cantidadMascota && stricmp(listaClientes[i].nombre,listaClientes[j].nombre)>0)
                {
                    aux = auxiliarMascotas[i];
                    auxiliarMascotas[i] = auxiliarMascotas[j];
                    auxiliarMascotas[j] = aux;

                    auxC = listaClientes[i];
                    listaClientes[i] = listaClientes[j];
                    listaClientes[j] = auxC;
                }
            }

        }
    }

    printf("ordenamiento con exito\n");
}

int modificarMascota(eMascotas listadoMascotas[], int tamM, eRaza listaRaza[], int tamR, eClientes listaCliente[], int tamC)
{
    int id;
    int esta;
    int opcionModificar;
    int retorno ;
    int idRaza;
    int idDuenio;

    mostrarListaMascotaS(listadoMascotas,tamM,listaCliente,tamC,listaRaza,tamR );


    id = getInt("ingrese el id que desea modificar\n","ERROR id entre 1 y 20\n",1,20);


    esta = buscarIdMascotas(listadoMascotas,tamM,id);


    if(esta == -1)
    {
        printf("el id elegido no esta registrado\n");
        retorno = -1;

    }
    else
    {

        do
        {

            printf("Que opcion quiere cambiar?\n");
            printf("1.nombre\n");
            printf("2.tipo de mascota\n");
            printf("3.raza\n");
            printf("4.edad\n");
            printf("5.peso\n");
            printf("6.duenio\n");
            printf("7.guardar modificaciones\n");
            scanf("%d", &opcionModificar);

            while(opcionModificar < 1 || opcionModificar> 7)
            {
                printf("ERROR Elija una opcion:\n ");
                fflush(stdin);
                scanf("%d", &opcionModificar);
            }


            switch(opcionModificar)
            {
            case 1:
                getString("Ingrese nombre de la mascota: \n",listadoMascotas[esta].nombre);
                printf("nombre cambiado\n");
                break;
            case 2:
                getString("Ingrese tipo de la mascota: \n",listadoMascotas[esta].TipoDeMascota);
                printf("tipo cambiado\n");
                break;
            case 3:
                printf("ingrese raza a modificar\n");
                mostrarTipoDeRazas(listaRaza,tamR);
                scanf("%d", &idRaza);

                while(idRaza <300 || idRaza >311)
                {
                    printf("error raza no encontrada\n");
                    fflush(stdin);
                    scanf("%d", &idRaza);
                }

                listadoMascotas[esta].idRaza = idRaza;

                printf("raza cambiado\n");
                break;
            case 4:
                listadoMascotas[esta].edad = getInt("ingrese nuevo edad entre 0 y 20\n","ERROR id no valido\n",0,20);
                printf("edad cambiado\n");
                break;
            case 5:
                listadoMascotas[esta].peso = getFloat("ingrese nuevo peso entre 0 y 30k\n","ERROR peso no valido\n",0,30);
                printf("peso cambiado\n");
                break;
            case 6:
                printf("ingrese id del duenio nuevo \n");
                mostrarListaClientes(listaCliente, tamC);
                scanf("%d", &idDuenio);

                while(idDuenio <100 || idDuenio >120)
                {
                    printf("error duenio no encontrado\n");
                    fflush(stdin);
                    scanf("%d", &idDuenio);
                }



                listadoMascotas[esta].idCliente = idDuenio;
                printf("duenio cambiado\n");
                break;
            }
            retorno= 1;
        }
        while(opcionModificar != 7);

    }


    return retorno;

}

void mostrarListaClienesConMascotasMismoSexo(eMascotas listaMascotas[], int tamM,eClientes listaClientes[], int tamC, eRaza listaRaza[], int tamR)
{

    int i; //cliente
    int j;
    int k;//raza
    //int flag = 0;

    printf("mascotas femeninas\n");
    printf("nombre            tipo         edad     peso     sexo    nombreCliente   id mascota      raza           pais   \n");

    for(j=0; j<tamM; j++)
    {

        for(i=0; i<tamC ; i++)
        {

            for(k = 0; k<tamR; k++)
            {
                if(  listaMascotas[j].idCliente == listaClientes[i].idCliente
                        &&listaMascotas[j].idRaza == listaRaza[k].idRaza
                        && listaMascotas[j].estado == OCUPADO
                        && listaRaza[k].estado == OCUPADO
                        && listaClientes[i].estado == OCUPADO
                        && listaMascotas[j].sexo == 'f')
                {
                    printf("\n|%10s|  %15s|  %5d| %5.2f|    %5c|   %15s|   %5d  | %15s| %15s|\n",
                           listaMascotas[j].nombre,
                           listaMascotas[j].TipoDeMascota,
                           listaMascotas[j].edad,
                           listaMascotas[j].peso,
                           listaMascotas[j].sexo,
                           listaClientes[i].nombre,
                           listaMascotas[j].idMascota,
                           listaRaza[k].nombreRaza,
                           listaRaza[k].pais );
                }
            }
        }
    }

    printf("\n\nmascotas masculinas\n");
     printf("nombre            tipo         edad     peso     sexo    nombreCliente   id mascota      raza           pais   \n");

    for(j=0; j<tamM; j++)
    {

        for(i=0; i<tamC ; i++)
        {

            for(k = 0; k<tamR; k++)
            {
                if(  listaMascotas[j].idCliente == listaClientes[i].idCliente
                        &&listaMascotas[j].idRaza == listaRaza[k].idRaza
                        && listaMascotas[j].estado == OCUPADO
                        && listaRaza[k].estado == OCUPADO
                        && listaClientes[i].estado == OCUPADO
                        && listaMascotas[j].sexo == 'm')
                {
                    printf("\n|%10s|  %15s|  %5d| %5.2f|    %5c|   %15s|   %5d  | %15s| %15s|\n",
                           listaMascotas[j].nombre,
                           listaMascotas[j].TipoDeMascota,
                           listaMascotas[j].edad,
                           listaMascotas[j].peso,
                           listaMascotas[j].sexo,
                           listaClientes[i].nombre,
                           listaMascotas[j].idMascota,
                           listaRaza[k].nombreRaza,
                           listaRaza[k].pais );
                }

            }
        }


    }

}





void mostrarListaMascotaS(eMascotas listaMascotas[], int tamM,eClientes listaClientes[], int tamC, eRaza listaRaza[], int tamR)
{

    int i; //cliente
    int j;
    int k;//raza
    //int flag = 0;

    printf("nombre            tipo         edad     peso     sexo    nombreCliente   id mascota      raza           pais   \n");


    for(j=0; j<tamM; j++)
    {

        for(i=0; i<tamC ; i++)
        {

            for(k = 0; k<tamR; k++)
            {
                if(  listaMascotas[j].idCliente == listaClientes[i].idCliente
                        &&listaMascotas[j].idRaza == listaRaza[k].idRaza
                        && listaMascotas[j].estado == OCUPADO
                        && listaRaza[k].estado == OCUPADO
                        && listaClientes[i].estado == OCUPADO)
                {
                    printf("\n|%10s|  %15s|  %5d| %5.2f|    %5c|   %15s|   %5d  | %15s| %15s|\n",
                           listaMascotas[j].nombre,
                           listaMascotas[j].TipoDeMascota,
                           listaMascotas[j].edad,
                           listaMascotas[j].peso,
                           listaMascotas[j].sexo,
                           listaClientes[i].nombre,
                           listaMascotas[j].idMascota,
                           listaRaza[k].nombreRaza,
                           listaRaza[k].pais );

                }
            }


        }
    }



}

int altaMascota(eMascotas listaMascota[],int tamM,eClientes listaCliente[], int tamC, eRaza listaRaza[], int tamR)
{
    int indice;
    int id;
    int idCliente;
    int idRaza;
    int esta;
    int retorno = -1;
    eMascotas miMascota;
    //char auxRaza[30];
    // int i;

    indice = buscarLibreMascota(listaMascota, tamM);


    printf("*** Alta mascota ***\n\n");

    if( indice == -1)
    {

        printf("No hay lugar en el sistema\n\n");
        system("pause");
    }
    else
    {
        //mostrarListaMascotaS(listaMascota,tamM,listaCliente,tamC);

        id = getInt("ingrese id de mascota", "ERROR id invalido",0,1000);

        esta = buscarIdMascotas(listaMascota, tamM, id);

        if( esta != -1)
        {

            printf("Ya esta una mascota con el id %d\n", id);
            system("pause");

        }
        else
        {
            miMascota.idMascota = id;
            getString("ingrese nombre de la mascota: \n",miMascota.nombre);
            getString("ingrese tipo de la mascota: \n",miMascota.TipoDeMascota);

            printf("elija id de la raza disponible\n");

            mostrarTipoDeRazas(listaRaza,tamR);
            scanf("%d", &idRaza);

             while(idRaza < 300 || idRaza> 310 )
            {
                printf("ERROR Elija una opcion entre el 300 y 310:\n ");
                fflush(stdin);
                scanf("%d", &idRaza);
            }

            miMascota.idRaza = idRaza;
            miMascota.edad = getInt("ingrese edad de la mascota\n", "ERROR edad fuera de limites\n",0,20);
            miMascota.peso = getFloat("ingrese peso de la mascota\n", "ERROR peso fuera de limites\n",0,20);
            miMascota.sexo = getChar("ingrese sexo de la mascota f o m \n", "ERROR no existe sexo\n",'m','f');

            printf("elija id del cliente?\n");
            mostrarListaClientes(listaCliente,tamC);
            scanf("%d", &idCliente );

            while(idCliente < 100 || idCliente> 120 )
            {
                printf("ERROR Elija una opcion entre el 100 y 120:\n ");
                fflush(stdin);
                scanf("%d", &idCliente);
            }
            miMascota.idCliente = idCliente;

            miMascota.estado = OCUPADO;

            listaMascota[indice] = miMascota;

            retorno = 1;

        }
    }
    return retorno;
}






