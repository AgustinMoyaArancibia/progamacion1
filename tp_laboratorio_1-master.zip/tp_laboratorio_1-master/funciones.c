#include <stdio.h>
#include <stdlib.h>
float pedirOperando(char mensaje[])
{

    float numero;

    printf("%s",mensaje);
    while(scanf("%f", &numero) !=1)
    {
        printf("error ingrese un numero\n");
        fflush(stdin);
    }

    return numero;

}

float sumarValores(float a, float b)
{
    float resultado;

    resultado=a+b;

    return resultado;

}

float restaValores(float a, float b)
{
    float resultado;

    resultado=a-b;

    return resultado;
}

float divisionValores(float a, float b)
{
    float resultado;

    resultado=a/b;



    return resultado;
}

float multiplicarValores(float a, float b)
{
    float resultado;

    resultado=a*b;

    return resultado;
}

unsigned long factorial(float a )
{
    int entero;
    entero=(int)a;

    if(entero==1 )
    {
        return 1;
    }
    else
    {
        return entero * factorial(entero - 1);
    }

}


