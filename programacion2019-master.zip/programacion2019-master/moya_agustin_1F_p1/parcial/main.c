#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utn.h"
#include "parcial.h"
#define TAML 10
#define TAMA 5
#define TAMS 6
#define TAMP 6




int main()
{

    char seguir = 's';
     int idSocio = 100;
     int idPrestamos=2000;
    eLibros libross[TAML];
    eAutor autores[TAMA];
    eSocios socios[TAMS];
    ePrestamos prestamos[TAMP];
    inicializarSocios(socios,TAMS);
    inicializarPrestamos(prestamos,TAMP);
    cargarLibros(libross);
    cargarAutores(autores);
    cargarSocios(socios);
    cargarPrestamos(prestamos);

     do
    {
        switch(menuSocios())
        {

        case 1:
           altaSocio(socios,TAMS,&idSocio);
            system("pause");
            break;
        case 2:
          modificacionSocio(socios,TAMS);
            system("pause");
            break;
        case 3:
         bajaSocio(socios,TAMS);
            system("pause");
            break;
        case 4:
           mostrarSocios(socios,TAMS);
            system("pause");
            break;
        case 5:
          ordenarSocios(socios,TAMS);
            system("pause");
            break;
        case 6:
           mostrarLibros(libross,TAML,autores,TAMA);
            system("pause");
            break;
        case 7:
           ordenarLibros(libross,TAML);
            system("pause");
            break;
        case 8:
            listarPrestamos(prestamos,TAMP,socios,TAMS);
            system("pause");
            break;
        case 9:
            listarAutores(autores,TAMA);
            system("pause");
            break;
         case 10:
             ordenarAutores(autores,TAMA);
            system("pause");
            break;

        case 11:
            altaPrestamos(prestamos,TAMS,&idPrestamos,libross,TAML,autores,TAMA,socios,TAMS);
            system("pause");
            break;

        case 12:
            printf("Salir");
            system("pause");
            seguir = 'n';
            break;

        }
    }

    while(seguir == 's');


    return 0;
}


