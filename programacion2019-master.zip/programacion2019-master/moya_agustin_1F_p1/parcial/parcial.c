#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utn.h"
#include "parcial.h"


int menuSocios()
{

    int opcion;

    system("cls");
    printf("\n*** Menu de Socios ***\n\n");
    printf(" 1- Alta socio\n");
    printf(" 2- modificar socio\n");
    printf(" 3- baja socio\n");
    printf(" 4- Listar socios\n");
    printf(" 5- Ordenar socios por apellido y nombre\n");
    printf(" 6- listar libros\n");
    printf(" 7- ordenar libros\n");
    printf(" 8- Listar prestamos\n");
    printf(" 9- listar autores\n");
    printf(" 10- ordenar autores\n");
    printf(" 11- alta prestamos\n");
    printf(" 12- Salir\n\n");
    printf(" Ingrese opcion: ");
    while(scanf("%d", &opcion) !=1)
    {
        printf(" reingrese  un numero: ");
        scanf("%d", &opcion);
        fflush(stdin);
    }

    return opcion;
}

void cargarLibros(eLibros libross[])
{
    int i;
    eLibros lib[]=
    {
        {1, "Principito",1005},
        {2, "Caos",1002},
        {3, "Odisea",1000},
        {4, "cornelia",1003},
        {5, "toda la verdad",1004},
        {6, "rey leon",1001},
        {7, "quiereme siempre",1003},
        {8, "patria",1008},
        {9, "el orden del dia",1005},
        {10, "un amor",1001}
    };

    for( i=0; i < 10; i++)
    {
        libross[i] = lib[i];
    }
}

void cargarAutores(eAutor autores[])
{
    int i;
    eAutor aut[]=
    {
        {1001, "juan","arancbia"},
        {1002, "ana","moya"},
        {1003, "leo","sanchez"},
        {1004, "agus","cleo"},
        {1005, "lujan","barrios"}
    };

    for( i=0; i < 5; i++)
    {
        autores[i] = aut[i];
    }
}

void listarAutores(eAutor autores[], int tam)
{
    int i;
    printf("\nLista de autores\n\n");
    printf("id autor---  nombre  ---apellido\n");

    for(i=0; i < tam; i++)
    {
        printf(" %d\t      %s\t    %s\t  \n",autores[i].idAutor, autores[i].apellidoAutor, autores[i].nombreAutor);
    }
    printf("\n\n");
}



void mostrarLibros(eLibros lista[], int tamL, eAutor autores[], int tamA)
{
    int i;

    printf("titulo libro---    id del libro---     autor\n");
    for(i=0; i<tamL; i++)
    {


        mostrarLibro(lista[i], autores, tamA);


    }
}
void mostrarLibro(eLibros unLibro, eAutor autores[], int tamA)
{

    char descripcionAutor[51];
    int i;

    for(i=0; i<tamA; i++)
    {
        if(unLibro.idAutorXlibro==autores[i].idAutor)
        {
            strcpy(descripcionAutor, autores[i].apellidoAutor);
            break;
        }
    }


    printf("%5s /   %13d  /   %s \n", unLibro.titulo,unLibro.idLibro,descripcionAutor);




}


int buscarSocio(eSocios listaSocios[], int tamS, int codigoSocio)
{
    int i;
    int indice = -1;
    for( i=0; i < tamS; i++)
    {
        if(listaSocios[i].estado == 0 && listaSocios[i].codigoSocio == codigoSocio)
        {
            indice = i;
            break;
        }
    }
    return indice;
}

int buscarLibreSocio(eSocios listaSocio[], int tamS)
{
    int i;
    int indice = -1;
    for( i=0; i < tamS; i++)
    {
        if(listaSocio[i].estado == 1)
        {
            indice = i;
            break;
        }
    }
    return indice;
}

void inicializarSocios(eSocios listaSocios[], int tamS)
{
    int i;
    for( i=0; i < tamS; i++)
    {

        listaSocios[i].estado = 1;
    }
}

void altaSocio(eSocios listaSocios[], int tamS, int* pId)
{
    eSocios nuevoSocio;
    int idSocio = *pId;
    int indice;
    indice= buscarLibreSocio(listaSocios, tamS);

    if(indice== -1 )
    {
        printf("\n el sistema esta completo. no se puede dar de alta a mas socios.\n\n");
    }
    else
    {
        nuevoSocio.codigoSocio = idSocio;


        nuevoSocio.estado=0;


        printf("ingrese apellido\n");
        fflush(stdin);
        gets(nuevoSocio.apellidoSocio);
        printf("ingrese nombre\n");
        fflush(stdin);
        gets(nuevoSocio.nombreSocio);
        printf("ingrese sexo\n");
        scanf("%c", &nuevoSocio.sexoSocio);
        printf("ingrese telefono\n");
        while(scanf("%d", &nuevoSocio.telefono) !=1)
        {
            printf(" reingrese  un numero: ");
            scanf("%d", &nuevoSocio.telefono);
            fflush(stdin);
        }
        printf("ingrese email\n");
        fflush(stdin);
        gets(nuevoSocio.email);
        printf("ingrese anio");
        while(scanf("%d",&nuevoSocio.fechaSocio.anio)!=1 )
        {
            printf(" reingrese  anio apartir 2000: ");
            scanf("%d", &nuevoSocio.fechaSocio.anio);
            fflush(stdin);
        }
        printf("ingrese mes");
        while(scanf("%d",&nuevoSocio.fechaSocio.mes)!=1 )
        {
            printf(" reingrese  mes entre 0 y 31: ");
            scanf("%d", &nuevoSocio.fechaSocio.mes);
            fflush(stdin);
        }
        printf("ingrese dia");
        while(scanf("%d",&nuevoSocio.fechaSocio.dia)!=1 )
        {
            printf(" reingrese  dia entre 0 y 31: ");
            scanf("%d", &nuevoSocio.fechaSocio.dia);
            fflush(stdin);

        }




        listaSocios[indice] = nuevoSocio;



        *pId = idSocio +1;

        nuevoSocio.estado = 0;

        listaSocios[indice] = nuevoSocio;

    }
}


void mostrarSocio(eSocios socios)
{

    printf(" %d\t      %s\t    %s\t   %c\t    %d\t     %s\t   %d/%d/%d \n",socios.codigoSocio, socios.apellidoSocio, socios.nombreSocio, socios.sexoSocio, socios.telefono, socios.email ,socios.fechaSocio.anio,socios.fechaSocio.mes,socios.fechaSocio.dia);

}

void mostrarSocios(eSocios listaSocios[], int tamS)
{
    printf("id socio---apellido socio-- nombre socio---sexo socio---telefono socio---mail socio---ingreso del socio\n");

    int i;

    for( i=0; i < tamS; i++)
    {

        if( listaSocios[i].estado == 0)
        {
            mostrarSocio(listaSocios[i]);
        }
    }
    system("pause");
}

void modificacionSocio(eSocios listaSocio[], int tamS)
{

    char seguir = 's';
    int codigo;
    int esta;
    char confirma;
    char nuevoApellido[51];
    char nuevoNombre[51];
    char nuevoSexo;
    int nuevoTelefono;
    char nuevoEmail[51];

    system("cls");
    printf("---Modificacion socio---\n\n");

    mostrarSocios(listaSocio,tamS);

    printf("Ingrese codigo de socio entre 100 y 1000: ");
    while(scanf("%d", &codigo) !=1)
    {
        printf(" reingrese  un numero entre el 100 y el 1000: ");
        scanf("%d", &codigo);
        fflush(stdin);
    }

    esta = buscarSocio(listaSocio, tamS, codigo);

    if(esta == -1)
    {
        printf("\nEl codigo %d no se encuentra en el sistema\n\n", codigo);

    }
    else
    {

        mostrarSocio(listaSocio[esta]);

            do
            {
                switch(menuModificar())
                {

                case 1:
                    printf("\nIngrese nuevo apellido: ");
                    fflush(stdin);
                    gets(nuevoApellido);
                    strcpy(listaSocio[esta].apellidoSocio, nuevoApellido);

                    break;
                case 2:
                    printf("\nIngrese nuevo nombre: ");
                    fflush(stdin);
                    gets(nuevoNombre);
                    strcpy(listaSocio[esta].nombreSocio, nuevoNombre);

                    break;
                case 3:
                     printf("ingrese nuevo sexo: ");
                     fflush(stdin);
                    scanf("%c", &nuevoSexo);
                    listaSocio[esta].sexoSocio = nuevoSexo;

                    break;
                    case 4:
                     printf("ingrese nuevo telefono: ");
                    scanf("%d", &nuevoTelefono);
                    listaSocio[esta].telefono = nuevoTelefono;

                    break;

                 case 5:
                    printf("\nIngrese nuevo email: ");
                    fflush(stdin);
                    gets(nuevoEmail);
                    strcpy(listaSocio[esta].email, nuevoEmail);
                case 6:
                    seguir = 'n';
                    break;

                }
            }
            while(seguir == 's');


        printf("\nConfirma Modificacion?: ");
        fflush(stdin);
        scanf("%c", &confirma);

        if(confirma == 's')
        {




            printf("\nSe ha modificado lo pedido\n\n");
        }
        else
        {
            printf("\nSe ha cancelado la modificacion\n\n");
        }

    }
}


int menuModificar()
{

    int opcion;

    system("cls");
    printf("\n*** Menu de modificacion ***\n\n");
    printf(" 1- cambiar apellido \n");
    printf(" 2- cambiar nombre \n");
    printf(" 3- cambiar sexo\n");
    printf(" 4- cambiar telefono\n");
    printf(" 5- cambiar email \n");
    printf(" 6- terminar modificacion \n\n");
    printf(" Ingrese opcion: ");
    while(scanf("%d", &opcion) !=1)
    {
        printf(" reingrese  un numero entre el 1 y el 6: ");
        scanf("%d", &opcion);
        fflush(stdin);
    }

    return opcion;
}

void bajaSocio(eSocios listaSocio[], int tamS)
{
    int codigo;
    int esta;
    char confirma;

    system("cls");
    printf("-----baja de socio-----\n\n");

    mostrarSocios(listaSocio, tamS);

    printf("ingrese codigo de socio entre 100 y 1000\n");
    while(scanf("%d", &codigo) !=1)
    {
        printf(" reingrese  un numero: ");
        scanf("%d", &codigo);
        fflush(stdin);
    }

    esta = buscarSocio(listaSocio,tamS, codigo);

    if(esta== -1)
    {
        printf("\n el codigo %d no se encuentra en el sistema\n\n", codigo);
    }
    else
    {
        mostrarSocio(listaSocio[esta]);

        printf("\n confirma la baja?: ");
        fflush(stdin);
        scanf("%c", &confirma);

        if(confirma== 's')
        {
            listaSocio[esta].estado=1;
            printf("\n se ha realizado la baja \n\n");
        }
        else
        {
            printf("\n se ha cancelado la baja\n\n");
        }

    }
}



int buscarPrestamos(ePrestamos listaPrestamos[], int tamP, int codigoPrestamos)
{
    int i;
    int indice = -1;
    for( i=0; i < tamP; i++)
    {
        if(listaPrestamos[i].estado == 0 && listaPrestamos[i].codigoPrestamo == codigoPrestamos)
        {
            indice = i;
            break;
        }
    }
    return indice;
}

int buscarLibrePrestamos(ePrestamos listaPrestamos[], int tamP)
{
    int i;
    int indice = -1;
    for( i=0; i < tamP; i++)
    {
        if(listaPrestamos[i].estado == 1)
        {
            indice = i;
            break;
        }
    }
    return indice;
}

void inicializarPrestamos(ePrestamos listaPrestamos[], int tamP)
{
    int i;
    for( i=0; i < tamP; i++)
    {

        listaPrestamos[i].estado = 1;
    }
}

void altaPrestamos(ePrestamos listaPrestamos[], int tamP, int* pId, eLibros listaLibros[], int tamL , eAutor listaAutores[], int tamA, eSocios listaSocios[], int tamS )
{
    ePrestamos nuevoPrestamos;
    int idPrestamo = *pId;
    int indice;
    indice= buscarLibrePrestamos(listaPrestamos, tamP);

    if(indice== -1 )
    {
        printf("\n el sistema esta completo. no se puede dar de alta a mas prestamos.\n\n");
    }
    else
    {
        nuevoPrestamos.codigoPrestamo = idPrestamo;


        nuevoPrestamos.estado=0;

        mostrarLibros(listaLibros,tamL,listaAutores, tamA);


        printf("ingrese codigo de libro\n\n");
        while(scanf("%d", &nuevoPrestamos.codigoLibro) !=1)
        {
            printf(" reingrese  un numero entre el 1 y el 10: ");
            scanf("%d", &nuevoPrestamos.codigoLibro);
            fflush(stdin);
        }

        mostrarSocios(listaSocios,tamS);
         printf("ingrese codigo de socio\n");
        while(scanf("%d", &nuevoPrestamos.codigoSocio) !=1)
        {
            printf(" reingrese  un numero entre el 100 y el 200: ");
            scanf("%d", &nuevoPrestamos.codigoSocio);
            fflush(stdin);
        }

        printf("ingrese anio");
        while(scanf("%d", &nuevoPrestamos.fechaPrestamos.anio)!=1 )
        {
            printf(" reingrese  anio apartir 2000: ");
            scanf("%d", &nuevoPrestamos.fechaPrestamos.anio);
            fflush(stdin);
        }

        printf("ingrese mes");
        while(scanf("%d", &nuevoPrestamos.fechaPrestamos.mes)!=1 )
        {
            printf(" reingrese  mes entre 0 y 31: ");
            scanf("%d", &nuevoPrestamos.fechaPrestamos.mes);
            fflush(stdin);
        }

        printf("ingrese dia");
        while(scanf("%d", &nuevoPrestamos.fechaPrestamos.dia)!=1 )
        {
            printf(" reingrese  dia entre 0 y 31: ");
            scanf("%d", &nuevoPrestamos.fechaPrestamos.dia);
            fflush(stdin);

        }






        listaPrestamos[indice] = nuevoPrestamos;



        *pId = idPrestamo +1;

        nuevoPrestamos.estado = 0;

        listaPrestamos[indice] = nuevoPrestamos;

    }
}

void cargarSocios(eSocios socios[])
{
    int i;
    eSocios soc[]=
    {
        {190, "socal","luca",'m',1221122554,"asdasd@assad",15,2,2004,0},
        {150, "serel","lore",'f',1221122554,"asdasd@assad",20,8,2005,0},
        {140, "loraa","caro",'f',1221122554,"asdasd@assad",10,4,2004,0},
        {180, "fersa","leo",'m',1221122554,"asdasd@assad",16,5,2007,0},
        {160, "fisaa","yanina",'f',1221122554,"asdasd@assad",10,5,2005,0}
    };

    for( i=0; i < 5; i++)
    {
        socios[i] = soc[i];
    }
}




void listarPrestamos(ePrestamos listaP[], int tamP, eSocios listaS[], int tamS)
{
    int i;


    printf("codigo prestamo--- id del libro---     socio--- fecha\n");
    for(i=0; i<tamS; i++)
    {

          if( listaP[i].estado == 0){
        listarPrestamo(listaP[i],listaS,tamS);
            }

    }
}
void listarPrestamo(ePrestamos unPrestamos, eSocios listaS[], int tamS)
{

    char descripcionSocio[51];
    int i;

    for(i=0; i<tamS; i++)
    {
        if(unPrestamos.codigoSocio==listaS[i].codigoSocio)
        {
            strcpy(descripcionSocio, listaS[i].apellidoSocio);
            break;
        }
    }


    printf("%d----  %d ----   %s---- %d/%d/%d \n", unPrestamos.codigoPrestamo,unPrestamos.codigoLibro,descripcionSocio, unPrestamos.fechaPrestamos.anio,unPrestamos.fechaPrestamos.mes,unPrestamos.fechaPrestamos.dia);




}



void cargarPrestamos(ePrestamos prestamos[])
{
    int i;
    ePrestamos pres[]=
    {
        {2006,2,190,2,2004,8,0},
        {2008,9,160,8,2005,10,0}
    };

    for( i=0; i < 2; i++)
    {
        prestamos[i] = pres[i];
    }
}

void ordenarSocios(eSocios listaS[], int tamS)
{

    eSocios auxSocios;
    int i;
    int j;

    for( i=0; i< tamS-1; i++)
    {
        for( j=i +1; j< tamS; j++)
        {
            if(listaS[i].apellidoSocio > listaS[j].apellidoSocio)
            {
                auxSocios = listaS[i];
                listaS[i] = listaS[j];
                listaS[j] = auxSocios;
            }
            else
            {
                if(listaS[i].apellidoSocio == listaS[j].apellidoSocio)
                {
                    if(strcmp(listaS[i].nombreSocio, listaS[j].nombreSocio)>0)
                    {
                        auxSocios = listaS[i];
                        listaS[i] = listaS[j];
                        listaS[j] = auxSocios;
                    }

                }

            }
        }
    }
printf("sistema socios ordenado");
}

void ordenarLibros(eLibros listaL[], int tamL)
{

    eLibros aux;
    int i;
    int j;

    for( i=0; i< tamL-1; i++)
    {
        for( j=i +1; j< tamL; j++)
        {
            if(listaL[i].titulo > listaL[j].titulo)
            {
                aux = listaL[i];
                listaL[i] = listaL[j];
                listaL[j] = aux;
            }
        }
    }
printf("sistema de libros ordenado");
}

void ordenarAutores(eAutor listaA[], int tamA)
{

    eAutor aux;
    int i;
    int j;

    for( i=0; i< tamA-1; i++)
    {
        for( j=i +1; j< tamA; j++)
        {
            if(listaA[i].apellidoAutor > listaA[j].apellidoAutor)
            {
                aux = listaA[i];
                listaA[i] = listaA[j];
                listaA[j] = aux;
            }
            else
            {
                if(listaA[i].apellidoAutor == listaA[j].apellidoAutor)
                {
                    if(strcmp(listaA[i].nombreAutor, listaA[j].nombreAutor)>0)
                    {
                        aux = listaA[i];
                        listaA[i] = listaA[j];
                        listaA[j] = aux;
                    }

                }

            }
        }
    }
printf("sistema de autores ordenado");
}
