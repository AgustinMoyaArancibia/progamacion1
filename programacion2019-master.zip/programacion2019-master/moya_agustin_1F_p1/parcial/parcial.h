typedef struct
{
    int idAutor;
    char apellidoAutor[31];
    char nombreAutor[31];
}eAutor;

typedef struct
{
    int idLibro;
    char titulo[51];
    int idAutorXlibro;
}eLibros;

typedef struct
{
    int dia,mes,anio;
} eFechaSocios;

typedef struct
{
    int codigoSocio;
    char apellidoSocio[31];
    char nombreSocio[31];
    char sexoSocio;
    int telefono;
    char email[31];
    eFechaSocios fechaSocio;
    int estado;

}eSocios;

typedef struct
{
    int dia,mes,anio;
} eFechaPrestamos;

typedef struct
{
   int codigoPrestamo;
   int codigoLibro;
   int codigoSocio;
   eFechaPrestamos fechaPrestamos;
   int estado;


}ePrestamos;



void cargarLibros(eLibros libross[]);
int menuSocios();
void cargarAutores(eAutor autores[]);
void listarAutores(eAutor autores[], int tam);
void mostrarLibro(eLibros unLibro, eAutor autores[], int tamA);
void mostrarLibros(eLibros lista[], int tamL, eAutor autores[], int tamA);
int buscarSocio(eSocios listaSocios[], int tamS, int codigoSocio);
int buscarLibreSocio(eSocios listaSocio[], int tamS);
void inicializarSocios(eSocios listaSocios[], int tamS);
void altaSocio(eSocios listaSocios[], int tamS, int* pId);
void mostrarSocio(eSocios socios);
void mostrarSocios(eSocios listaSocios[], int tamS);
int menuModificar();
void modificacionSocio(eSocios listaSocio[], int tamS);
void bajaSocio(eSocios listaSocio[], int tamS);
void inicializarPrestamos(ePrestamos listaPrestamos[], int tamP);
int buscarLibrePrestamos(ePrestamos listaPrestamos[], int tamP);
int buscarPrestamos(ePrestamos listaPrestamos[], int tamP, int codigoPrestamos);
void altaPrestamos(ePrestamos listaPrestamos[], int tamP, int* pId, eLibros listaLibros[], int tamL , eAutor listaAutores[], int tamA, eSocios listaSocios[], int tamS );
void cargarSocios(eSocios socios[]);
void listarPrestamo(ePrestamos unPrestamos, eSocios listaS[], int tamS);
void listarPrestamos(ePrestamos listaP[], int tamP, eSocios listaS[], int tamS);
void cargarPrestamos(ePrestamos prestamos[]);
void ordenarSocios(eSocios listaS[], int tamS);
void ordenarLibros(eLibros listaL[], int tamL);


