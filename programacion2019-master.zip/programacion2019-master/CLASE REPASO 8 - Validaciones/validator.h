#ifndef VALIDATOR_H_INCLUDED
#define VALIDATOR_H_INCLUDED

void getNumero(int numero);
int getNombre(char*nombre);
int getEmail(char*email);


#endif // VALIDATOR_H_INCLUDED
