/*1. Modificar las estructuras para poder trabajar con relaciones muchos a muchos.
2. Hardcodear datos para Empleados-Sectores (Interrelacion)
3. Modificar el alta de empleados, permitiendo seleccionar un sector.
4. Agregar una opcion al menu, para poder asociar un empleado en
particular a otro sector.
5. Resolver el calculo de sueldo bruto y neto. Teniendo en cuenta que si el
empleado trabaja en varios sectores el sueldo resultara de la suma del producto de las
 horas trabajadas por el valor hora de cada sector
*/
