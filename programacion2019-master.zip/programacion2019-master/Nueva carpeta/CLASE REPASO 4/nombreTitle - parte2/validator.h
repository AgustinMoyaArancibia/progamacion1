#ifndef VALIDATOR_H_INCLUDED
#define VALIDATOR_H_INCLUDED

int getNombre(char*nombre);
int getEmail(char*email);

#endif // VALIDATOR_H_INCLUDED
