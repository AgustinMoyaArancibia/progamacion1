void printIntArray(int array[], int size);
int compactar(int array[], int size, int indice);
int calcularIndiceMinimo(int array[], int size);

void nadiaSort(int array[], int size,int arrayOrdenado[]);
void nadiaSort2(int array[], int size);
void insertionSortNum(int array[], int size);
void insertionSortStr(char* array[], int size);
void bubleSort(int array[], int size);
void bubleSort2(int array[], int size);
void quickSort(int array[], int size);
void selectionSort(int array[], int size);
int swapInts(int* pArray, int indiceA, int indiceB);
int fillFromFile(int array[], int maxSize);
