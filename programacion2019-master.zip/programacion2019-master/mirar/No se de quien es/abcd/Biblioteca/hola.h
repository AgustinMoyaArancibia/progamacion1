int pedirEntero (char []);
