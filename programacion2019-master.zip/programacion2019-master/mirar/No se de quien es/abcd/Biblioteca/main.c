#include <stdio.h>
#include <stdlib.h>
#include "hola.h"
#include "rec.h"

int main()
{
   int opcion;
   char seguir ='s';
   do
   {
       printf("1.alta\n2.baja\n3.informar\n4.salir\n elija un opcion)");
       scanf("%d", &opcion);
   switch(opcion)
   {
   case 1:
    printf("estoy dando de alta\n");
    break;
   case 2:
    printf("estoy dando de baja\n");
    break;
   case 3:
    printf( "estoy informando\n");
   break;
   case 4:
    printf("estoy saliendo del programa\n");
    seguir="n";
    break;
   default:

    printf("no ingreso un dato valido\n");
    break;
   }
   system("pause");
   system("cls");
   }while(seguir=='s');


   /* int resultado = factorial(5);
    printf("%d", resultado);

   /* int edad;
    int legajo;
    int peso;

    edad=pedirEntero("Ingrese edad: ");
    legajo=pedirEntero("Ingrese legajo: ");
    peso=pedirEntero("Ingrese peso: ");*/

    return 0;
}
