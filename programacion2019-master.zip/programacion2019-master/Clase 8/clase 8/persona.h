#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    int id;
    char descripcionNacionalidad[31];
} eNacion;

typedef struct
{
    int dia;
    int mes;
    int anio;
} eFecha;


typedef struct
{
    char apellido[31];
    char nombre[31];
    char sexo;
    int edad;
    int isEmpty;
    int idNacionalidad;
    eFecha fechaMes;
} ePersona;


void alta(ePersona per[], int cant);
void mostrarUno(ePersona per);
void mostrarTodos(ePersona per[], int cant);
void ordenar (ePersona per[], int cant);
void cargarPaises(eNacion pais[]);
void mostrarTodosPaises(eNacion pais[], int cant);
void mostrarPais(eNacion pais);

