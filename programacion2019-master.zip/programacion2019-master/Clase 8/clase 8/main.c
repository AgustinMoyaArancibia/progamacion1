#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "persona.h"

#define CANT 2




int main()
{
   ePersona per[CANT];
   //eNacion pais[3];

//   cargarPaises(pais);
   alta(per,CANT);

   system("cls");

    mostrarTodos(per, CANT);




    //mostrarTodosPaises(pais, 3);
    return 0;
}

