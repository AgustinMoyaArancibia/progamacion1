#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "persona.h"

void alta(ePersona per[], int cant)
{
    int i;

    for( i =0; i<cant ; i++)
    {
        printf("ingrese apellido: ");
        fflush(stdin);
        scanf("%s", per[i].apellido);

        printf("ingrese nombre: ");
        fflush(stdin);
        scanf("%s", per[i].nombre);

        printf("ingrese edad: ");
        scanf("%d", &per[i].edad);

        printf("ingrese sexo M o F: ");
        fflush(stdin);
        scanf("%c", &per[i].sexo);

        printf("ingrese dia de nacimiento: ");
        scanf("%d", &per[i].fechaMes.dia);

        printf("ingrese mes de nacimiento: ");
        scanf("%d", &per[i].fechaMes.mes);

        printf("ingrese anio de nacimiento: ");
        scanf("%d", &per[i].fechaMes.anio);



        per[i].isEmpty = 0;

    }

}

void mostrarUno(ePersona per)
{
    printf("%s\t%s\t%c\t%d\t%d%d%d\t%d\n", per.apellido, per.nombre,per.sexo, per.edad,per.fechaMes.dia,per.fechaMes.mes,per.fechaMes.anio,per.isEmpty);
}

void mostrarTodos(ePersona per[], int cant)
{
    int i;
    for(i=0; i < cant; i++)
    {
        mostrarUno(per[i]);
    }
}
void cargarPaises(eNacion pais[])
{
    int i;

    eNacion pai[]=
    {
        {1,"argentina"},
        {2,"uruguay"},
        {3,"chile"}
    };

    for( i=0; i < 3; i++)
    {
        pais[i] = pai[i];
    }
}

void mostrarPais(eNacion pais)
{
    printf("%d%s\t\n", pais.id, pais.descripcionNacionalidad);
}

void mostrarTodosPaises(eNacion pais[], int cant)
{
    int i;
    for(i=0; i < cant; i++)
    {
        mostrarPais(pais[i]);
    }
}


void ordenar (ePersona per[], int cant)
{
    int i;
    int j;
    ePersona aux;

    for(i=0 ; i<cant-1; i++)
    {
        for(j=i+1; i <cant; j++)
        {
            if(strcmp(per[i].apellido, per[j].apellido)>0)
            {
                aux=per[i];
                per[i]=per[j]; //se iguala al ser un tipo de dato
                per[j]=aux;
            }
        }
    }
}

