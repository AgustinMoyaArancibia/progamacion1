struct alumno
{
    char nombre[50];
    int nota;
};
void ordenar(struct alumno* arrayPunterosAlumnos[3], int longitudArray);
