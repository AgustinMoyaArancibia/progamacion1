#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include"funcion.h"
#define CANTIDAD 3


int main()
{
    int i,auxiliarNota;
    char auxiliarNombre[50];
    struct alumno arrayAlumnos[CANTIDAD];
    struct alumno* arrayPunterosAlumnos[CANTIDAD];
    for(i=0; i<CANTIDAD; i++)
    {

        arrayPunterosAlumnos[i] = &arrayAlumnos[i];// Copiamos la posici�n de memoria de cada elemento
        printf("\nIngrese el nombre: ");
        scanf("%s",auxiliarNombre);
        strcpy(arrayAlumnos[i].nombre, auxiliarNombre); //FALTARIA VALIDAR
        printf("\nIngrese la Nota: ");
        scanf("%i",&auxiliarNota);
        arrayAlumnos[i].nota = auxiliarNota; //FALTA VALIDAR

    }
        printf("\n-MOSTRAMOS EL SIN ORDENAR ARRAY-");
        for(i=0; i<CANTIDAD; i++)
        {
            printf("\n%s", arrayPunterosAlumnos[i]->nombre);
            printf("-%i",arrayPunterosAlumnos[i]->nota);
        }
        ordenar(arrayPunterosAlumnos, CANTIDAD);
        printf("\n-MOSTRAMOS EL ARRAY ORDENADO por nota-");
        for(i=0; i<CANTIDAD; i++)
        {
            printf("\n%s", arrayPunterosAlumnos[i]->nombre);
            printf("-%i",arrayPunterosAlumnos[i]->nota);
        }




    return 0;
}

