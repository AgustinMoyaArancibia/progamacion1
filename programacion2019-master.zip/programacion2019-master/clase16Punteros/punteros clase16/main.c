#include <stdio.h>
#include <stdlib.h>
void mostrarCadena(char* punteroCadena);
void mostrarCadena2(char* punteroCadena, int tam);

int main()
{
    char *p;
    char vec[5]="hola";

    p=vec;

 mostrarCadena(p);
    printf("---\n");
    mostrarCadena2(p,5);



    return 0;
}

void mostrarCadena(char* punteroCadena)
{
    while(*punteroCadena != '\0')
    {
        printf("%c\n",*punteroCadena);
        printf("%p\n", &*punteroCadena);
        punteroCadena++;
    }
}

void mostrarCadena2(char* punteroCadena, int tam)
{
    int i;
    for(i=0;  i<tam;)
    {

            printf("%c\n",*(punteroCadena+i));
            printf("%p\n", &*punteroCadena+i);
            i++;

    }
}
