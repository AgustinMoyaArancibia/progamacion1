#include <stdio.h>
#include <stdlib.h>
#define CANT 2

int main()
{


    return 0;
}

/*
    int legajo[CANT];
    int nota1[CANT];
    int nota2[CANT];
    float nota3[CANT];
    int i;

    for(i=0; i<CANT; i++)
        {
            printf("ingrese numero de legajo ");
            scanf("%d", &legajo[i]);
            printf("ingrese nota1 ");
            scanf("%d", &nota1[i]);
            printf("ingrese nota2 ");
            scanf("%d", &nota2[i]);
            printf("\n");

        }



    for(i=0; i<CANT; i++)
        {
            nota3[i]=(float)(nota1[i] + nota2[i]) /2;
            printf("su numero de legajo es:%d \n su nota1 es:%d \n su nota2 es:%d \n su nota3 es:%f \n\n ", legajo[i], nota1[i], nota2[i],nota3[i]);
        }

*/



 /*
    int datos[5];
    int i;
    int acum=0;

    for(i=0; i<CANT; i++)
    {
        printf("ingrese edad: \n");
        scanf("%d",&datos[i]);
        acum=acum+datos[i];

    }
     for(i=0; i<CANT; i++)
        {
            printf("las edades son: %d \n",datos[i]);
        }
    printf("%d", acum);*/
