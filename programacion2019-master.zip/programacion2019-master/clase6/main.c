#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char nombre[20];

        printf("ingrese sombre:  ");
        scanf("%s", nombre);
        //gets(nombre);
        printf("su nombre es %s", nombre);


    return 0;
}
