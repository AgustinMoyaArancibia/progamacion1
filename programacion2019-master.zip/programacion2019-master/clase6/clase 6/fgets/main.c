#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char buffer[64];
    int cantidad;

    printf("Nombre: ");
    //fgets(buffer, 62, stdin);0
    fgets(buffer,sizeof(buffer)-2,stdin);

    cantidad = strlen(buffer);

    buffer[cantidad-1] = '\0';

    printf("%s \n", buffer);
   // printf("%d", cantidad);

    return 0;
}
