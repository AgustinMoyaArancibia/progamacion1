#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void pedirCadena (char[],char[],int);
void validarTamCadena (char[],char[],int);

int main()
{
    char nombre[20];
    char apellido[20];
    char apellidoNombre[41];

    pedirCadena("Nombre: ", nombre,20);
    pedirCadena("Apellido: ", apellido,20);
    strcat(apellidoNombre, apellido);
    puts(apellidoNombre);
}
void pedirCadena(char mensaje[], char cadena[],int tam )
{
    printf("Ingrese %s", mensaje);
    scanf("%[^\n]", cadena);
    validarTamCadena(mensaje,cadena,tam);
}
void validarTamCadena(char mensajeError[],char cadena[], int tam)
{
    while(strlen(cadena)>tam)
        {
            printf("%s",mensajeError);
            fflush(stdin);
            scanf("%[^\n]", cadena);
        }
}
