#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Employee.h"


int parserEmployee(FILE* fileName , ArrayList* pArrayListEmployee, int len)
{
     FILE *pFile;
    int r,i=0;
    char var1[50],var3[50],var2[50],var4[50];
    pFile = fopen(fileName,"r");

    if(pFile == NULL){
        return -1;
    }

    do{
        r = fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",var1,var2,var3,var4);
        if(r==4){
            pArrayListEmployee[i].id = atoi(var1);
            strncpy(pArrayListEmployee[i].nombre,var2,sizeof(pArrayListEmployee[i].nombre));
            strncpy(pArrayListEmployee[i].apellido,var3,sizeof(pArrayListEmployee[i].apellido));
            pArrayListEmployee[i].edad = atoi(var4);
            i++;
        }
        else
            break;
    }while(!feof(pFile) && i<len);

    fclose(pFile);

    return i;
    return 0;
}
