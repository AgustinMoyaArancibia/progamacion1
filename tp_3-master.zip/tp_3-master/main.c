#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Employee.h"
#include "utn.h"

/*****************************************************
    Menu:
     1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).
     2. Cargar los datos de los empleados desde el archivo data.csv (modo binario).
     3. Alta de empleado
     4. Modificar datos de empleado
     5. Baja de empleado
     6. Listar empleados
     7. Ordenar empleados
     8. Guardar los datos de los empleados en el archivo data.csv (modo texto).
     9. Guardar los datos de los empleados en el archivo data.csv (modo binario).
    10. Salir
*****************************************************/


int main()
{
    char seguir = 's';
    LinkedList* listaEmpleados = ll_newLinkedList();

    do
    {
        switch(opcionesMenu())
        {
        case 1:
           controller_loadFromText("data.csv", listaEmpleados);//pk
            break;
        case 2:
            controller_loadFromBinary("data.bin", listaEmpleados);//ok
            system("pause");
            break;
        case 3:
            controller_addEmployee(listaEmpleados);//ok
            break;
        case 4:
            controller_editEmployee(listaEmpleados);//ok
            system("pause");
            break;
        case 5:
            controller_removeEmployee(listaEmpleados);//ok
            system("pause");
            break;
        case 6:
            controller_ListEmployee(listaEmpleados);//ok
            system("pause");
            break;
        case 7:
           controller_sortEmployee(listaEmpleados);
            system("pause");
            break;
        case 8:
            controller_saveAsText("data.csv", listaEmpleados); //ok
            system("pause");
            break;
        case 9:
            controller_saveAsBinary("data.bin", listaEmpleados);//ok
            system("pause");
            break;
        case 10:
            printf("Salir");
            system("pause");
            seguir = 'n';
            break;

        }

    }
    while(seguir == 's');


    return 0;
}

