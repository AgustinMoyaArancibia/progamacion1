
#include "todo.h"


void mostrarReparacionPorFecha(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC)
{

    int i; //reparaciones
    int j;//electro
    int k;//marca
    int a;//servicio
    int l;
    int dia;
    int mes;
    int anio;
    int flag = -1;

    mostrarCompleto(listaReparaciones,tamR,listaServicio,tamS,listaElectro,tamE,listaMarca,tamM,listaCliente,tamC);

    dia = getInt("ingrese dia \n", "dia mal puesto\n",0,31);
    mes= getInt("ingrese mes \n", "mes mal elegido\n",0,12);
    anio = getInt("ingrese anio entre 1980 - 2020\n", "anio mal elegido\n",1980,2022);


    for(i=0; i<tamR ; i++)
    {
        for(j=0; j<tamE; j++)
        {
            for(k = 0; k<tamM; k++)
            {
                for(a = 0; a<tamS; a++)
                {
                    for(l = 0; l<tamC; l++)
                    {
                        if(     listaReparaciones[i].estado == OCUPADO &&
                                listaElectro[j].estado == OCUPADO &&
                                listaMarca[k].estado == OCUPADO &&
                                listaServicio[a].estado ==OCUPADO &&
                                listaCliente[l].estado ==OCUPADO &&
                                listaReparaciones[i].numeroSerie == listaElectro[j].serieElectrodomestico &&
                                listaElectro[j].idMarca == listaMarca[k].idMarca &&
                                listaReparaciones[i].idCliente == listaCliente[l].idCliente &&
                                listaReparaciones[i].idServicio == listaServicio[a].id &&
                                listaReparaciones[i].fechaReparacion.dia == dia &&
                                listaReparaciones[i].fechaReparacion.mes == mes &&
                                listaReparaciones[i].fechaReparacion.anio == anio)
                        {
                            flag = 0;
                            printf("%5d %15d %10d        %d-%d-%d %10s %10s     %20s  %7.2f %7d   %10d  %10d  %10s\n",
                                   listaReparaciones[i].idReparacion,
                                   listaReparaciones[i].numeroSerie,
                                   listaReparaciones[i].idServicio,
                                   listaReparaciones[i].fechaReparacion.dia,
                                   listaReparaciones[i].fechaReparacion.mes,
                                   listaReparaciones[i].fechaReparacion.anio,
                                   listaCliente[l].nombre,
                                   listaCliente[l].apellido,
                                   listaServicio[a].descripcion,
                                   listaServicio[a].precio,
                                   listaElectro[j].idElectromestico,
                                   listaElectro[j].anioModelo,
                                   listaElectro[j].idMarca,
                                   listaMarca[k].descripcionMarca);

                        }
                    }


                }

            }
        }

    }
    if(flag == -1)
    {
        printf("no hay nada en esa fecha\n");
    }
}

void mostrarElectroConMasRefacciones(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC)
{

    int i; //reparaciones
    int j;//electro

    int contadorWirpoll = 0;
    int contadorSony = 0;
    int contadorlillianal = 0;
    int contadorGafa = 0;
    int contadorPhilips = 0;
    int contadores[5];
    int max = 0 ;


    for(j=0; j<tamE ; j++)
    {
        for(i=0; i<tamR ; i++)
        {
            if(listaElectro[j].idMarca == 1001 && listaElectro[j].serieElectrodomestico == listaReparaciones[i].numeroSerie)
            {
                contadorWirpoll++;
            }
        }

    }
    contadores[0] = contadorWirpoll;
    printf("electrodomestico: Wirpoll  \t cantidad de reparaciones: %d \n", contadorWirpoll);


    for(j=0; j<tamE ; j++)
    {
        for(i=0; i<tamR ; i++)
        {
            if(listaElectro[j].idMarca == 1002 && listaElectro[j].serieElectrodomestico == listaReparaciones[i].numeroSerie)
            {
                contadorSony++;
            }
        }

    }
    contadores[1] = contadorSony;
    printf("electrodomestico: sony  \t cantidad de reparaciones: %d \n", contadorSony);


    for(j=0; j<tamE ; j++)
    {
        for(i=0; i<tamR ; i++)
        {
            if(listaElectro[j].idMarca == 1003 && listaElectro[j].serieElectrodomestico == listaReparaciones[i].numeroSerie)
            {
                contadorlillianal++;
            }
        }

    }
    contadores[2] = contadorlillianal;
    printf("electrodomestico: liliana  \t cantidad de reparaciones: %d \n", contadorlillianal);




    for(j=0; j<tamE ; j++)
    {
        for(i=0; i<tamR ; i++)
        {
            if(listaElectro[j].idMarca == 1004 && listaElectro[j].serieElectrodomestico == listaReparaciones[i].numeroSerie)
            {
                contadorGafa++;
            }
        }

    }
    contadores[3] = contadorGafa;
    printf("electrodomestico: gafa  \t cantidad de reparaciones: %d \n", contadorGafa);





    for(j=0; j<tamE ; j++)
    {
        for(i=0; i<tamR ; i++)
        {
            if(listaElectro[j].idMarca == 1005 && listaElectro[j].serieElectrodomestico == listaReparaciones[i].numeroSerie)
            {
                contadorPhilips++;
            }
        }

    }
    contadores[4] = contadorWirpoll;
    printf("electrodomestico: phillips \t cantidad de reparaciones: %d \n", contadorPhilips);



    for(i=0; i<5; i++)
    {
        if(i==0 || contadores[i]>max)
        {
            max = contadores[i];

        }
    }
    printf(" reparaciones maximas %d \n", max);



}

void mostrarFacturacionPorFecha(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC)
{

    int i; //reparaciones
    int j;//electro
    int k;//marca
    int a;//servicio
    int l;
    int dia;
    int mes;
    int anio;
    float total;

    mostrarCompleto(listaReparaciones,tamR,listaServicio,tamS,listaElectro,tamE,listaMarca,tamM,listaCliente,tamC);

    dia = getInt("ingrese dia \n", "dia mal puesto\n",0,31);
    mes= getInt("ingrese mes \n", "mes mal elegido\n",0,12);
    anio = getInt("ingrese anio\n", "anio mal elegido\n",2018,2022);


    for(i=0; i<tamR ; i++)
    {
        for(j=0; j<tamE; j++)
        {
            for(k = 0; k<tamM; k++)
            {
                for(a = 0; a<tamS; a++)
                {
                    for(l = 0; l<tamC; l++)
                    {
                        if(     listaReparaciones[i].estado == OCUPADO &&
                                listaElectro[j].estado == OCUPADO &&
                                listaMarca[k].estado == OCUPADO &&
                                listaServicio[a].estado ==OCUPADO &&
                                listaCliente[l].estado ==OCUPADO &&
                                listaReparaciones[i].numeroSerie == listaElectro[j].serieElectrodomestico &&
                                listaElectro[j].idMarca == listaMarca[k].idMarca &&
                                listaReparaciones[i].idCliente == listaCliente[l].idCliente &&
                                listaReparaciones[i].idServicio == listaServicio[a].id &&
                                listaReparaciones[i].fechaReparacion.dia == dia &&
                                listaReparaciones[i].fechaReparacion.mes == mes &&
                                listaReparaciones[i].fechaReparacion.anio == anio)
                        {
                            total = total+ listaServicio[a].precio;
                            printf("%5d %15d %10d        %d-%d-%d %10s %10s     %20s  %7.2f %7d   %10d  %10d  %10s\n",
                                   listaReparaciones[i].idReparacion,
                                   listaReparaciones[i].numeroSerie,
                                   listaReparaciones[i].idServicio,
                                   listaReparaciones[i].fechaReparacion.dia,
                                   listaReparaciones[i].fechaReparacion.mes,
                                   listaReparaciones[i].fechaReparacion.anio,
                                   listaCliente[l].nombre,
                                   listaCliente[l].apellido,
                                   listaServicio[a].descripcion,
                                   listaServicio[a].precio,
                                   listaElectro[j].idElectromestico,
                                   listaElectro[j].anioModelo,
                                   listaElectro[j].idMarca,
                                   listaMarca[k].descripcionMarca);

                        }
                    }


                }

            }
        }
    }
    printf("el total de la reparacion de esa fecha es %.2f \n",total);
}

void mostrarReparacionesElectrosGarantia(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC)
{

    int i; //reparaciones
    int j;//electro
    int k;//marca
    int a;//servicio
    int l;


    printf("idReparacion   numSerie    idServicio      fecha   nombreCliente  apellidoCliente   descripcion    precio  idElectro    fechaModelo   idMarca   marca \n");


    for(i=0; i<tamR ; i++)
    {
        for(j=0; j<tamE; j++)
        {
            for(k = 0; k<tamM; k++)
            {
                for(a = 0; a<tamS; a++)
                {
                    for(l = 0; l<tamC; l++)
                    {
                        if(     listaReparaciones[i].estado == OCUPADO &&
                                listaElectro[j].estado == OCUPADO &&
                                listaMarca[k].estado == OCUPADO &&
                                listaServicio[a].estado ==OCUPADO &&
                                listaCliente[l].estado ==OCUPADO &&
                                listaReparaciones[i].numeroSerie == listaElectro[j].serieElectrodomestico &&
                                listaElectro[j].idMarca == listaMarca[k].idMarca &&
                                listaReparaciones[i].idCliente == listaCliente[l].idCliente &&
                                listaReparaciones[i].idServicio == listaServicio[a].id && strncmp(listaServicio[a].descripcion,"garantia",51)==0)

                        {
                            printf("%5d %15d %10d        %d-%d-%d %10s %10s     %20s  %7.2f %7d   %10d  %10d  %10s\n",
                                   listaReparaciones[i].idReparacion,
                                   listaReparaciones[i].numeroSerie,
                                   listaReparaciones[i].idServicio,
                                   listaReparaciones[i].fechaReparacion.dia,
                                   listaReparaciones[i].fechaReparacion.mes,
                                   listaReparaciones[i].fechaReparacion.anio,
                                   listaCliente[l].nombre,
                                   listaCliente[l].apellido,
                                   listaServicio[a].descripcion,
                                   listaServicio[a].precio,
                                   listaElectro[j].idElectromestico,
                                   listaElectro[j].anioModelo,
                                   listaElectro[j].idMarca,
                                   listaMarca[k].descripcionMarca);

                        }
                    }


                }

            }
        }
    }

}

void mostrarFacturacionMantenimiento(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC)
{

    int i; //reparaciones
    int j;//electro
    int k;//marca
    int a;//servicio
    int l;
    float acumulador = 0;

    for(i=0; i<tamR ; i++)
    {
        for(j=0; j<tamE; j++)
        {
            for(k = 0; k<tamM; k++)
            {
                for(a = 0; a<tamS; a++)
                {
                    for(l = 0; l<tamC; l++)
                    {
                        if(     listaReparaciones[i].estado == OCUPADO &&
                                listaElectro[j].estado == OCUPADO &&
                                listaMarca[k].estado == OCUPADO &&
                                listaServicio[a].estado ==OCUPADO &&
                                listaCliente[l].estado ==OCUPADO &&
                                listaReparaciones[i].numeroSerie == listaElectro[j].serieElectrodomestico &&
                                listaElectro[j].idMarca == listaMarca[k].idMarca &&
                                listaReparaciones[i].idCliente == listaCliente[l].idCliente &&
                                listaReparaciones[i].idServicio == listaServicio[a].id)
                        {

                            acumulador = acumulador + listaServicio[a].precio;

                        }
                    }


                }

            }
        }
    }
    printf("el precio acumulado de todos  es %.2f\n",acumulador);
}

void mostrarElectroSinReparacion(eReparacion listaReparaciones[],int tamR, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC)
{
    int i;
    int j;

    eElecotrodomestico elecAux[tamE];

    printf("idElectro    fechaModelo   idMarca   marca \n");

    for(i = 0; i<tamE; i++)
    {
        elecAux[i] = listaElectro[i];
    }

    for(i=0; i<tamE; i++)
    {
        for(j = 0 ; j<tamR ; j++)
        {
            if(elecAux[i].estado== OCUPADO && elecAux[i].serieElectrodomestico == listaReparaciones[j].numeroSerie)
            {
                elecAux[i].estado = LIBRE;
            }
        }

        if(elecAux[i].estado == OCUPADO)
        {
            printf("%d    %d   \n", elecAux[i].idMarca, elecAux[i].anioModelo);
        }
    }






}

void mostrarReparacionesElectrosModelo2018(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC)
{

    int i; //reparaciones
    int j;//electro
    int k;//marca
    int a;//servicio
    int l;
    int flag = -1;


    printf("idReparacion   numSerie    idServicio      fecha   nombreCliente  apellidoCliente   descripcion    precio  idElectro    fechaModelo   idMarca   marca \n");


    for(i=0; i<tamR ; i++)
    {
        for(j=0; j<tamE; j++)
        {
            for(k = 0; k<tamM; k++)
            {
                for(a = 0; a<tamS; a++)
                {
                    for(l = 0; l<tamC; l++)
                    {
                        if(     listaReparaciones[i].estado == OCUPADO &&
                                listaElectro[j].estado == OCUPADO &&
                                listaMarca[k].estado == OCUPADO &&
                                listaServicio[a].estado ==OCUPADO &&
                                listaCliente[l].estado ==OCUPADO &&
                                listaReparaciones[i].numeroSerie == listaElectro[j].serieElectrodomestico &&
                                listaElectro[j].idMarca == listaMarca[k].idMarca &&
                                listaReparaciones[i].idCliente == listaCliente[l].idCliente &&
                                listaReparaciones[i].idServicio == listaServicio[a].id &&
                                listaElectro[j].anioModelo == 2018)
                        {
                            flag = 0;
                            printf("%5d %15d %10d        %d-%d-%d %10s %10s     %20s  %7.2f %7d   %10d  %10d  %10s\n",
                                   listaReparaciones[i].idReparacion,
                                   listaReparaciones[i].numeroSerie,
                                   listaReparaciones[i].idServicio,
                                   listaReparaciones[i].fechaReparacion.dia,
                                   listaReparaciones[i].fechaReparacion.mes,
                                   listaReparaciones[i].fechaReparacion.anio,
                                   listaCliente[l].nombre,
                                   listaCliente[l].apellido,
                                   listaServicio[a].descripcion,
                                   listaServicio[a].precio,
                                   listaElectro[j].idElectromestico,
                                   listaElectro[j].anioModelo,
                                   listaElectro[j].idMarca,
                                   listaMarca[k].descripcionMarca);

                        }
                    }


                }

            }
        }
    }
    if(flag == -1)
    {
        printf("no hay nada para mostrar \n");
    }
}


void mostrarElectroTotal(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC)
{

    int i; //reparaciones
    int j;//electro
    int k;//marca
    int a;//servicio
    int l;
    int serieElectro;

    float acumulador = 0;

    /*  eCantidadElectro auxElectro[tamE];

      for(i=0; i<tamE; i++)
      {
          auxElectro[i].id = listaElectro[i].serieElectrodomestico; // copio el id de la estructura en el auxiliar para usar
          auxElectro[i].cantidadElectro = 0;
      }


      for(i=0; i<tamE; i++)
      {
          for(j=0; j<tamR; j++)
          {
              if(listaReparaciones[j].estado == OCUPADO && listaElectro[i].estado == OCUPADO && listaReparaciones[j].numeroSerie == auxElectro[i].id) //igualo los id y el estado
              {
                  auxElectro[i].cantidadElectro++;

              }
          }

           printf("cantidadElectro : %d \n", auxElectro[i].cantidadElectro);
      }
    */


    mostrarElectroMarca(listaElectro,tamE,listaMarca,tamM);
    serieElectro = getInt("elija serie de electrodomestico a mostrar\n", "serie no existe\n",300,305);

    printf("idReparacion   numSerie    idServicio      fecha   nombreCliente  apellidoCliente   descripcion    precio  idElectro    fechaModelo   idMarca   marca \n");


    for(i=0; i<tamR ; i++)
    {
        for(j=0; j<tamE; j++)
        {
            for(k = 0; k<tamM; k++)
            {
                for(a = 0; a<tamS; a++)
                {
                    for(l = 0; l<tamC; l++)
                    {
                        if(     listaReparaciones[i].estado == OCUPADO &&
                                listaElectro[j].estado == OCUPADO &&
                                listaMarca[k].estado == OCUPADO &&
                                listaServicio[a].estado ==OCUPADO &&
                                listaCliente[l].estado ==OCUPADO &&
                                listaReparaciones[i].numeroSerie == listaElectro[j].serieElectrodomestico &&
                                listaElectro[j].idMarca == listaMarca[k].idMarca &&
                                listaReparaciones[i].idCliente == listaCliente[l].idCliente &&
                                listaReparaciones[i].idServicio == listaServicio[a].id  &&
                                listaReparaciones[i].numeroSerie == serieElectro )
                        {

                            acumulador = acumulador + listaServicio[a].precio;
                            printf("%5d %15d %10d        %d-%d-%d %10s %10s     %20s  %7.2f %7d   %10d  %10d  %10s\n",
                                   listaReparaciones[i].idReparacion,
                                   listaReparaciones[i].numeroSerie,
                                   listaReparaciones[i].idServicio,
                                   listaReparaciones[i].fechaReparacion.dia,
                                   listaReparaciones[i].fechaReparacion.mes,
                                   listaReparaciones[i].fechaReparacion.anio,
                                   listaCliente[l].nombre,
                                   listaCliente[l].apellido,
                                   listaServicio[a].descripcion,
                                   listaServicio[a].precio,
                                   listaElectro[j].idElectromestico,
                                   listaElectro[j].anioModelo,
                                   listaElectro[j].idMarca,
                                   listaMarca[k].descripcionMarca);

                        }
                    }


                }

            }
        }
    }
    printf("el precio acumulado es %.2f\n",acumulador);
}




void mostrarReparacionesElectros(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC)
{

    int i; //reparaciones
    int j;//electro
    int k;//marca
    int a;//servicio
    int l;
    int serieElectro;

    mostrarElectroMarca(listaElectro,tamE,listaMarca,tamM);
    serieElectro = getInt("elija serie de electrodomestico a mostrar\n", "serie no existe\n",300,305);



    printf("idReparacion   numSerie    idServicio      fecha   nombreCliente  apellidoCliente   descripcion    precio  idElectro    fechaModelo   idMarca   marca \n");


    for(i=0; i<tamR ; i++)
    {
        for(j=0; j<tamE; j++)
        {
            for(k = 0; k<tamM; k++)
            {
                for(a = 0; a<tamS; a++)
                {
                    for(l = 0; l<tamC; l++)
                    {
                        if(     listaReparaciones[i].estado == OCUPADO &&
                                listaElectro[j].estado == OCUPADO &&
                                listaMarca[k].estado == OCUPADO &&
                                listaServicio[a].estado ==OCUPADO &&
                                listaCliente[l].estado ==OCUPADO &&
                                listaReparaciones[i].numeroSerie == listaElectro[j].serieElectrodomestico &&
                                listaElectro[j].idMarca == listaMarca[k].idMarca &&
                                listaReparaciones[i].idCliente == listaCliente[l].idCliente &&
                                listaReparaciones[i].idServicio == listaServicio[a].id &&
                                listaReparaciones[i].numeroSerie == serieElectro)
                        {
                            printf("%5d %15d %10d        %d-%d-%d %10s %10s     %20s  %7.2f %7d   %10d  %10d  %10s\n",
                                   listaReparaciones[i].idReparacion,
                                   listaReparaciones[i].numeroSerie,
                                   listaReparaciones[i].idServicio,
                                   listaReparaciones[i].fechaReparacion.dia,
                                   listaReparaciones[i].fechaReparacion.mes,
                                   listaReparaciones[i].fechaReparacion.anio,
                                   listaCliente[l].nombre,
                                   listaCliente[l].apellido,
                                   listaServicio[a].descripcion,
                                   listaServicio[a].precio,
                                   listaElectro[j].idElectromestico,
                                   listaElectro[j].anioModelo,
                                   listaElectro[j].idMarca,
                                   listaMarca[k].descripcionMarca);

                        }
                    }


                }

            }
        }
    }

}



void mostrarCompleto(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC)
{

    int i; //reparaciones
    int j;//electro
    int k;//marca
    int a;//servicio
    int l;
    //int flag = 0;

    printf("idReparacion   numSerie    idServicio      fecha   nombreCliente  apellidoCliente   descripcion    precio  idElectro    fechaModelo   idMarca   marca \n");


    for(i=0; i<tamR ; i++)
    {
        for(j=0; j<tamE; j++)
        {
            for(k = 0; k<tamM; k++)
            {
                for(a = 0; a<tamS; a++)
                {
                    for(l = 0; l<tamC; l++)
                    {
                        if(     listaReparaciones[i].estado == OCUPADO &&
                                listaElectro[j].estado == OCUPADO &&
                                listaMarca[k].estado == OCUPADO &&
                                listaServicio[a].estado ==OCUPADO &&
                                listaCliente[l].estado ==OCUPADO &&
                                listaReparaciones[i].numeroSerie == listaElectro[j].serieElectrodomestico &&
                                listaElectro[j].idMarca == listaMarca[k].idMarca &&
                                listaReparaciones[i].idCliente == listaCliente[l].idCliente &&
                                listaReparaciones[i].idServicio == listaServicio[a].id)
                        {
                            printf("%5d %15d %10d        %d-%d-%d %10s %10s     %20s  %7.2f %7d   %10d  %10d  %10s\n",
                                   listaReparaciones[i].idReparacion,
                                   listaReparaciones[i].numeroSerie,
                                   listaReparaciones[i].idServicio,
                                   listaReparaciones[i].fechaReparacion.dia,
                                   listaReparaciones[i].fechaReparacion.mes,
                                   listaReparaciones[i].fechaReparacion.anio,
                                   listaCliente[l].nombre,
                                   listaCliente[l].apellido,
                                   listaServicio[a].descripcion,
                                   listaServicio[a].precio,
                                   listaElectro[j].idElectromestico,
                                   listaElectro[j].anioModelo,
                                   listaElectro[j].idMarca,
                                   listaMarca[k].descripcionMarca);

                        }
                    }


                }

            }
        }
    }

}



int altaReparacionCompleto(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM,int* idAsiganado,eClientes listaCliente[], int tamC)
{
    int indice;
    int id;
    int retorno = -1;
    int opcionServicio;
    int opcionSerie;
    int opcionCliente;
    eReparacion nuevaReparacion;

    id = *idAsiganado;
    indice = buscarLibreReparacion(listaReparaciones, tamR);


    printf("*** Alta repaaracion ***\n\n");

    if( indice == -1)
    {

        printf("No hay lugar en el sistema\n\n");
        system("pause");
    }

    else
    {
        nuevaReparacion.idReparacion = id;
        *idAsiganado = id+1; //el puntero que voy a llevar al main, le aumento el id +1

        mostrarServicio(listaServicio,tamS);
        opcionServicio = getInt("eliga id del servicio\n", " ERROR id ivalido\n",20000,20005);
        nuevaReparacion.idServicio = opcionServicio;
        nuevaReparacion.fechaReparacion.dia = getInt("eliga dia del mes entre 1 a 31\n", "ERROR numero invalido\n",0,31);
        nuevaReparacion.fechaReparacion.mes = getInt("eliga mes del a�o entre 1 a 12\n", "ERROR numero invalido\n",0,12);
        nuevaReparacion.fechaReparacion.anio = getInt("elija a�o 2019 - 2020\n", "ERROR numero invalido\n",2019,2021);

        mostrarClientes(listaCliente,tamC);
        opcionCliente = getInt("elija cliente a adjuntar\n", "no hay clientes con ese id\n", 500,504);
        nuevaReparacion.idCliente = opcionCliente;

        mostrarElectroMarca(listaElectro,tamE,listaMarca,tamM); //ACA PIDO LA SERIE Y LA MUESTRO
        opcionSerie = getInt("eliga la serie del electrodomestico\n", " ERROR serie ivalido\n",300,305);
        nuevaReparacion.numeroSerie = opcionSerie;

        nuevaReparacion.estado= OCUPADO;
        listaReparaciones[indice] = nuevaReparacion;


        retorno = 1;

    }

    return retorno;
}

