
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utn.h"
#include "reparacion.h"
#include "electrodomestico.h"
#include "cliente.h"
/** \brief da de alta reparacion con todos sus complementos
 *
 * \param listaReparaciones[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \param idAsiganado int*
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return 1 si esta bien , -1 si no funciona
 *
 */
int altaReparacionCompleto(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM,int* idAsiganado,eClientes listaCliente[] , int tamC);


/** \brief muestra una lista con todos laa datos
 *
 * \param listaReparaciones[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return void
 *
 */
void mostrarCompleto(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);


/** \brief muestra electros por serie elejida
 *
 * \param listaReparaciones[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return void
 *
 */
void mostrarReparacionesElectros(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);


/** \brief muestras las reparaciones del anio 2018
 *
 * \param listaReparaciones[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return void
 *
 */
void mostrarReparacionesElectrosModelo2018(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);


/** \brief muestra el precio total de cada servicio a un electro
 *
 * \param listaReparaciones[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return void
 *
 */
void mostrarElectroTotal(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);


/** \brief muestra el total de las reparaciones de mantenimiento *
 * \param listaReparaciones[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return void
 *
 */
void mostrarFacturacionMantenimiento(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);


/** \brief muestras los electro que estan en garantia
 *
 * \param listaReparaciones[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return void
 *
 */
void mostrarReparacionesElectrosGarantia(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);


/** \brief muestra la cantidad total por fecha
 *
 * \param listaReparaciones[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return void
 *
 */
void mostrarFacturacionPorFecha(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);


/** \brief muestra electrodomestico que tuvo mas refaccion
 *
 * \param listaReparaciones[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return void
 *
 */
void mostrarElectroConMasRefacciones(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);


/** \brief muestra las reparaciion por fecha elegida
 *
 * \param listaReparaciones[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return void
 *
 */
void mostrarReparacionPorFecha(eReparacion listaReparaciones[],int tamR,eServicio listaServicio[], int tamS, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);


/** \brief muestra los electo sin reparaciones
 *
 * \param listaReparaciones[] eReparacion
 * \param tamR int
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return void
 *
 */
void mostrarElectroSinReparacion(eReparacion listaReparaciones[],int tamR, eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[],int tamM, eClientes listaCliente[], int tamC);
