#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utn.h"
#define OCUPADO 1
#define LIBRE 0

typedef struct
{
  int id;
  int cantidadServicios;
} eCantidadServicios;

typedef struct
{
    int idCliente;
    char nombre[51];
    char apellido[51];
    int estado;
}eClientes;


typedef struct
{
    int dia;
    int mes;
    int anio;
}eFechaReparacion;


typedef struct
{
    int id;
    char descripcion[51];
    float precio;
    int estado;
}eServicio;

typedef struct
{
    int idReparacion;
    int numeroSerie;
    int idServicio;
    eFechaReparacion fechaReparacion;
    int idCliente;
    int estado;
}eReparacion;

/** \brief lista los servicios
 *
 * \param listaServicio[] eServicio
 * \param tamS int
 * \return 1 si funciona , -1 si no funciona
 *
 */
int mostrarServicio(eServicio listaServicio[], int tamS);


/** \brief carga las reparaciones
 *
 * \param listaReparacion[] eReparacion
 * \return void
 *
 */
void harcodearReparaciones(eReparacion listaReparacion[]);


/** \brief carga los servicios
 *
 * \param listaServicio[] eServicio
 * \return void
 *
 */
void harcodearServicios(eServicio listaServicio[]);


/** \brief inicializa los servicios en 0
 *
 * \param listaServicio[] eServicio
 * \param tamS int
 * \return 0 si funcioa , -1 si no funciona
 *
 */
int inicializarServicios(eServicio listaServicio[], int tamS);


/** \brief inicializa en 0 las reparaciones
 *
 * \param listaReparacion[] eReparacion
 * \param tamR int
 * \return 0 si funciona , -1 si no funciona
 *
 */
int inicializarReparaciones(eReparacion listaReparacion[], int tamR);


/** \brief buscar la serie de una reparacion
 *
 * \param listaReparacion[] eReparacion
 * \param tamR int
 * \param serie int
 * \return la posicion de la serie , -1 si no la encuentra
 *
 */
int buscarSerieReparacion(eReparacion listaReparacion[], int tamR, int serie);


/** \brief busca un lugar libre para una reparacion
 *
 * \param listaReparacion[] eReparacion
 * \param tamR int
 * \return la posicion del lugar libre , -1 si no hay espacio
 *
 */
int buscarLibreReparacion(eReparacion listaReparacion[], int tamR);


/** \brief muestra una lista de repaciones junto a sus servicios
 *
 * \param listaReparacion[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \return 0 si funciona , -1 si no funciona
 *
 */
int mostrarReparacionServicio(eReparacion listaReparacion[], int tamR, eServicio listaServicio[], int tamS);


/** \brief da de alta un servicio
 *
 * \param listaReparacion[] eReparacion
 * \param tamR int
 * \param idAsiganado int*
 * \param listaServicio[] eServicio
 * \param tamS int
 * \return 0 si se da el alta , -1 si no funciona
 *
 */
int altaReparacionServicio(eReparacion listaReparacion[], int tamR, int* idAsiganado, eServicio listaServicio[] , int tamS);


/** \brief busca el id de una repacion
 *
 * \param listaReparacion[] eReparacion
 * \param tamR int
 * \param id int
 * \return la posicion del id , -1 si no funciona
 *
 */
int buscarIdReparacion(eReparacion listaReparacion[], int tamR, int id);


/** \brief da de baja una reparacion dada de alta
 *
 * \param listaReparaciones[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \return 0 si da de baja , -1 si no funciona
 *
 */
int bajaReparacion(eReparacion listaReparaciones[], int tamR,eServicio listaServicio[], int tamS);


/** \brief modifica una reparacion dada de alta
 *
 * \param listaReparacion[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \return 1 si funciona , -1 si no funciona
 *
 */
int modificarReparacion(eReparacion listaReparacion[], int tamR,eServicio listaServicio[], int tamS);


/** \brief cargar a los clientes
 *
 * \param listaCliente[] eClientes
 * \return void
 *
 */
void harcodearClientes(eClientes listaCliente[]);


/** \brief muestra una lista de clientes
 *
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return 1 si funciona , -1 si no funciona
 *
 */
int mostrarClientes(eClientes listaCliente[],int tamC);


/** \brief inicializa al cliente en 0
 *
 * \param listaCliente[] eClientes
 * \param tamC int
 * \return 1 si funciona , -1 si no funciona
 *
 */
int inicializaCliente(eClientes listaCliente[], int tamC);


/** \brief muestra la reparacion mas pedida
 *
 * \param listaReparacion[] eReparacion
 * \param tamR int
 * \param listaServicio[] eServicio
 * \param tamS int
 * \return 0 si funciona , -1 si no funcionma
 *
 */
int mostrarReparacionServicioMasPedido(eReparacion listaReparacion[], int tamR, eServicio listaServicio[], int tamS);
