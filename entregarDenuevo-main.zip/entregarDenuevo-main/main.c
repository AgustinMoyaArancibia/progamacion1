
//Listar Reparaciones no funciona. SI FUNCIONA , SOLO LO MEJORE
//Alta Reparaciones pide serie y no las muestra. SI MUSTRA LAS SERIE , LO HICE MAS ESPECIFICO
//Los informes no funcionan. NO SE PORQUE PUSO QUE NINGUNO FUNCIONA
//Debe mostrar un men� para seleccionar un informe, no mostrarlos todos juntos pidiendo datos y no se sabe que muestra.
//EL SUBMENU ESTA ECHO Y MUESTRA LOS TITULOS DE LOS INFORMES
//La opci�n salir no funciona LA OPCION SALIR DEL SUBMENU ME REGRESA AL MENU PRINCIPAL Y LA OPCION SALIR DEL MENU
//PRINCIPAL ME SALE DEL PROGRAMA, LE AGREGA UN PRINT PARA QUE LO VEA MEJOR .

//PARCIAL DE MOYA AGUSTIN 14/11

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utn.h"
#include "todo.h"
#define TAMELECTRO 10
#define TAMMARCA 10
#define TAMSERVICIO 10
#define TAMREPARACION 10
#define TAMCLIENTE 10


int main()
{
    eElecotrodomestico listaElectro[TAMELECTRO];
    eMarca listaMarca[TAMMARCA];
    eReparacion listaReparaciones[TAMREPARACION];
    eServicio listaServicio[TAMSERVICIO];
    eClientes listaCliente[TAMCLIENTE];
    int opcion;
    int opcionMenuInformes;
    int idIncrementado = 0;
    int idIncrementadoElectro = 100;
    //int flagAltaReparacion;
    int flagAltaElectro = -1;

    inicializarElectro(listaElectro,TAMELECTRO);
    harcodearElectrodomesticos(listaElectro);
    flagAltaElectro = 0;  //SI TENGO CARGADOS LOS DATOS PONGO EL FLAG EN 0 PARA PODER MODIFICAR Y DAR DE BAJA

    inicializarMarca(listaMarca,TAMMARCA);
    harcodearMarcas(listaMarca);

    inicializarReparaciones(listaReparaciones,TAMREPARACION);
    harcodearReparaciones(listaReparaciones);

    inicializarServicios(listaServicio,TAMSERVICIO);
    harcodearServicios(listaServicio);

    inicializaCliente(listaCliente,TAMCLIENTE);
    harcodearClientes(listaCliente);


    do
    {
        opcion= opcionesMenu();

        switch (opcion)
        {
        case 1:
            if(altaElectrodomesticosMarca(listaElectro,TAMELECTRO,&idIncrementadoElectro,listaMarca,TAMMARCA)==1)
            {
                printf("alta correcta\n");
                flagAltaElectro = 0;
            }
            else
            {
                printf("algo salio mal\n");
            }
            system("pause");
            system("cls");
            break;
        case 2:
            if(flagAltaElectro == 0)
            {
                if(modificarElectro(listaElectro,TAMELECTRO,listaMarca,TAMMARCA)==1)
                {
                    printf("todo ok\n");
                }
                else
                {
                    printf("algo salio mal\n");
                }
            }
            if(flagAltaElectro != 0)
            {
                printf("no se ingrese un electrodomestico para modificar\n");
            }

            system("pause");
            system("cls");
            break;

        case 3:
            if(flagAltaElectro == 0)
            {
                if(bajaElectro(listaElectro,TAMELECTRO,listaMarca,TAMMARCA, &idIncrementadoElectro)==1)
                {
                    printf("todo ok\n");

                }
                else
                {
                    printf("algo salio mal\n");
                }
            }
            if(flagAltaElectro != 0)
            {
                printf("no se ingrese un electrodomestico para dar de baja\n");
            }
            system("pause");
            system("cls");
            break;
        case 4:
            mostrarElectroMarca(listaElectro,TAMELECTRO,listaMarca,TAMMARCA);
            ordenarPorElec(listaElectro,TAMELECTRO);
            mostrarElectroMarca(listaElectro,TAMELECTRO,listaMarca,TAMMARCA);
            system("pause");
            system("cls");
            break;
        case 5:
            mostrarMarca(listaMarca,TAMMARCA);
            system("pause");
            system("cls");
            break;
        case 6:
            mostrarServicio(listaServicio,TAMSERVICIO);
            system("pause");
            system("cls");
            break;
        case 7:
            if(flagAltaElectro == 0 )
            {
                altaReparacionCompleto(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,&idIncrementado,listaCliente,TAMCLIENTE);
            }
            if(flagAltaElectro != 0 ||  idIncrementadoElectro<100)
            {
                printf("no se ingreso ningun electrodomestico para dar el alta a una reparacion\n");
            }
            system("pause");
            system("cls");
            break;
        case 8:
            mostrarCompleto(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
            system("pause");
            system("cls");
            break;
        case 9:
            do
            {
                opcionMenuInformes= opcionesMenuInformes();

                switch (opcionMenuInformes)
                {
                case 1:
                    mostrarElectroMarcaAnio2020(listaElectro,TAMELECTRO,listaMarca,TAMMARCA);
                    system("pause");
                    system("cls");
                    break;
                case 2:
                    mostrarElectroPorMarcaSeleccionada(listaElectro,TAMELECTRO,listaMarca,TAMMARCA);
                    system("pause");
                    system("cls");
                    break;

                case 3:
                    mostrarReparacionesElectros(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 4:
                    mostrarElectroSinReparacion(listaReparaciones,TAMREPARACION,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 5:
                    mostrarElectroTotal(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 6:
                    mostrarReparacionServicioMasPedido(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO);
                    system("pause");
                    system("cls");
                    break;
                case 7:
                    mostrarFacturacionPorFecha(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 8:
                    mostrarReparacionesElectrosGarantia(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 9:
                    mostrarReparacionesElectrosModelo2018(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 10:
                    mostrarFacturacionMantenimiento(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 11:
                    mostrarElectroConMasRefacciones(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 12:
                    mostrarReparacionPorFecha(listaReparaciones,TAMREPARACION,listaServicio,TAMSERVICIO,listaElectro,TAMELECTRO,listaMarca,TAMMARCA,listaCliente,TAMCLIENTE);
                    system("pause");
                    system("cls");
                    break;
                case 13:
                    printf("USTED SALIO DEL MENU DE INFORMES , SE DIRIGE AL MENU PRINCIPAL\n");
                    system("pause");
                }// final switch

            }//final while
            while (opcionMenuInformes != 13);
            break;
        case 10:
            printf("USTED SALIO DEL SISTEMA!!!!!!!\n");
            break;
        }// final switch

    }//final while
    while (opcion != 10);


    return 0;
}

