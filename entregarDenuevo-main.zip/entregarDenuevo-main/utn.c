#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utn.h"



/** \brief Lista el menu de opciones y pide la respuesta a ingresar mediante un menu y la retorna
 *
 * \return int respuesta
 * \return char* mensaje
 * \return char* mensajeError
 */
int opcionesMenu()
{
    int respuesta;

    system("cls");
    printf("\n\n 1. alta electro");
    printf("\n 2. modificar electro");
    printf("\n 3. baja electro");
    printf("\n 4. listar electro");
    printf("\n 5. lista marcas.");
    printf("\n 6. lista servicios.");
    printf("\n 7. alta preparacion.");
    printf("\n 8. lista reparaciones.");
    printf("\n 9. menu informes.");
    printf("\n 10. salir.");
    printf("\ningrese numero de menu\n");
    fflush(stdin);
    scanf("%d", &respuesta);

    while(respuesta > 11 || respuesta < 1)
    {
        printf("ERROR ingrese numero de menu nuevamente");
        printf("\n\n Por favor ingrese otro numero: ");
        fflush(stdin);
        scanf("%d", &respuesta);
    }
    return respuesta;
}



int opcionesMenuInformes()
{
    int respuesta;

    system("cls");
    printf("\n1- Mostrar Electrodom�sticos del anio 2020");
    printf("\n2- Mostrar Electrodom�sticos de una marca seleccionada");
    printf("\n3- Mostrar todos las reparaciones efectuadas al Electrodom�stico seleccionado");
    printf("\n4- Listar los Electrodom�sticos que no tuvieron reparaciones");
    printf("\n5- Informar importe total de las reparaciones realizadas a un Electrodom�stico");
    printf("\n6- Mostrar el servicio m�s pedido");
    printf("\n7- Mostrar la recaudaci�n en una fecha en particular");
    printf("\n8- Mostrar todos los Electrodom�sticos que realizaron una garant�a y la fecha");
    printf("\n9- Trabajos realizados a Electrodom�sticos del a�o(modelo) 2018");
    printf("\n10- Facturaci�n total por los mantenimientos");
    printf("\n11- Informar la marca de Electrodom�sticos que efectuaron m�s refacciones");
    printf("\n12- Listar los Electrodom�sticos que recibieron reparaci�n en un fecha determinada");
    printf("\n13- salir al menu principal\n");
    printf("ingrese numero de menu\n");
    fflush(stdin);
    scanf("%d", &respuesta);

    while(respuesta > 14 || respuesta < 1)
    {
        printf("ERROR ingrese numero de menu nuevamente");
        printf("\n\n Por favor ingrese otro numero: ");
        fflush(stdin);
        scanf("%d", &respuesta);
    }
    return respuesta;
}




int getInt(char mensaje[],char error[],int min,int max )
{
    int valor;

    printf("%s", mensaje);
    scanf("%d", &valor);

    while(valor<min || valor>max)
    {
        printf("%s",error);
        fflush(stdin);
        scanf("%d",&valor);
    }

    return valor;
}
long long getIntTel(char mensaje[],char error[],int min,int max )
{
    int valor;

    printf("%s", mensaje);
    scanf("%d", &valor);

    while(valor<min || valor>max)
    {
        printf("%s",error);
        fflush(stdin);
        scanf("%d",&valor);
    }

    return valor;
}

float getFloat(char mensaje[],char error[],int min,int max )
{
    float altura;

    printf("%s", mensaje);
    scanf("%f", &altura);

    while(altura<min || altura>max)
    {
        printf("%s",error);
        fflush(stdin);
        scanf("%f",&altura);
    }

    return altura;
}
int getChar(char mensaje[],char error[], char valor, char valor2)
{
    char sexo;
    printf("%s", mensaje);
    fflush(stdin);
    scanf("%c", &sexo);

    sexo= tolower(sexo);

    while(sexo != valor && sexo != valor2)
    {
        printf("%s",error );
        fflush(stdin);
        scanf("%c",&sexo);
        sexo= tolower(sexo);
    }

    return sexo;
}

void getString(char mensaje[], char input[])
{
    printf(mensaje);
    fflush(stdin);
    gets(input);
}

