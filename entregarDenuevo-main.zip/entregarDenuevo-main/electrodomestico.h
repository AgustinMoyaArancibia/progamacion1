
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utn.h"
#define OCUPADO 1
#define LIBRE 0

typedef struct
{
  int id;
  int cantidadElectro;
} eCantidadElectro;

typedef struct
{
    int idMarca;
    char descripcionMarca[51];
    int estado;
}eMarca;

typedef struct
{
    int idElectromestico;
    int serieElectrodomestico;
    int idMarca;
    int anioModelo;
    int estado;
}eElecotrodomestico;


/** \brief da de alta marcas
 *
 * \param listaMarca[] eMarca
 * \return void
 *
 */
void harcodearMarcas(eMarca listaMarca[]);


/** \brief da de altas electrodomesticos
 *
 * \param listaElectro[] eElecotrodomestico
 * \return void
 *
 */
void harcodearElectrodomesticos(eElecotrodomestico listaElectro[]);


/** \brief muestra los electrodomesticos con marca
 *
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \return 0 si funciona , -1 si no funciona
 *
 */
int mostrarElectroMarca(eElecotrodomestico listaElectro[], int tamE, eMarca listaMarca[], int tamM);


/** \brief inicia en 0 los valores de electrodomesticos
 *
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \return 0 si funciona , -1 si no funciona
 */
int inicializarElectro(eElecotrodomestico listaElectro[], int tamE);


/** \brief busca id del cliente
 *
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param id int
 * \return retorna la posicion del id , -1 si no encuentra el id
 *
 */
int buscarIdClientes(eElecotrodomestico listaElectro[], int tamE, int id);


/** \brief busca si hay una posicion libre
 *
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \return retorna la posicion libre , -1 si no funciona
 *
 */
int buscarLibreElectro(eElecotrodomestico listaElectro[], int tamE);


/** \brief inicia en 0 los valores de marca
 *
 * \param listaMarca[] eMarca
 * \param tamM int
 * \return retorna la posicion del id , -1 si no encuentra el id
 *
 */
int inicializarMarca(eMarca listaMarca[], int tamM);


/** \brief muestra listado de marcas
 *
 * \param listaMarca[] eMarca
 * \param tamM int
 * \return 0 si funciona , -1 si no funciona
 *
 */
int mostrarMarca(eMarca listaMarca[], int tamM);



/** \brief da de alta un electrodomestico junto a su marca
 *
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param idAsiganado int*
 * \param listaMarca[] eMarca
 * \param tamM int
 * \return 1 si funciona , -1 si no funciona
 *
 */
int altaElectrodomesticosMarca(eElecotrodomestico listaElectro[], int tamE, int* idAsiganado, eMarca listaMarca[] , int tamM);



/** \brief busca id de electrodomesticos
 *
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param id int
 * \return el id si lo encuentra , -1 si no encuentra
 *
 */
int buscarIdElectro(eElecotrodomestico listaElectro[], int tamE, int id);



/** \brief modifica un electrodomestico dado de alta
 *
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \return 1 si modifica , -1 si no funciona
 *
 */
int modificarElectro(eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[], int tamM);


/** \brief da de baja a un electrodomestico dado de alta
 *
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \param idAsiganado int*
 * \return 1 si funciona , -1 si no funciona
 *
 */
int bajaElectro(eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[], int tamM , int* idAsiganado);


/** \brief ordena los electrodomesticos por fecha de modelo
 *
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \return void
 *
 */
void ordenarPorElec(eElecotrodomestico listaElectro[],int tamE );


/** \brief muestra los electrodomesticos del anio 2020
 *
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \return 0 si funciona , -1 si no funciona
 *
 */
int mostrarElectroMarcaAnio2020(eElecotrodomestico listaElectro[], int tamE, eMarca listaMarca[], int tamM);


/** \brief muestra los electrodomesticos por marca elegida
 *
 * \param listaElectro[] eElecotrodomestico
 * \param tamE int
 * \param listaMarca[] eMarca
 * \param tamM int
 * \return 0 si funciona, -1 si no funciona
 *
 */
int mostrarElectroPorMarcaSeleccionada(eElecotrodomestico listaElectro[], int tamE, eMarca listaMarca[], int tamM);


