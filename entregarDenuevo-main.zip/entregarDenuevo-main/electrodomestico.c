#include "electrodomestico.h"


int mostrarElectroPorMarcaSeleccionada(eElecotrodomestico listaElectro[], int tamE, eMarca listaMarca[], int tamM)
{

    int i;
    int j;
    int retorno = -1;
    int idMarca;

    mostrarMarca(listaMarca,tamM);
    idMarca = getInt("elija id de la marca a mostrar\n", "id de marca invalido\n",1000,1005 );

    printf("idElectro   numSerie    fechaModelo   idMarca   marca \n");
    for(i=0; i<tamM ; i++)
    {
        for(j=0; j<tamE ; j++)
        {
            if(listaElectro[i].estado == OCUPADO &&
                    listaMarca[j].estado == OCUPADO &&
                    listaElectro[i].idMarca == listaMarca[j].idMarca &&
                    listaMarca[j].idMarca == idMarca)
            {
                printf("\n %d    %10d    %5d    %10d %10s  \n",
                       listaElectro[i].idElectromestico,
                       listaElectro[i].serieElectrodomestico,
                       listaElectro[i].anioModelo,
                       listaElectro[i].idMarca,
                       listaMarca[j].descripcionMarca);
                retorno = 0;
            }
        }


    }

    return retorno;
}

int mostrarElectroMarcaAnio2020(eElecotrodomestico listaElectro[], int tamE, eMarca listaMarca[], int tamM)
{

    int i;
    int j;
    int retorno = -1;

    printf("idElectro   numSerie    fechaModelo   idMarca   marca \n");
    for(i=0; i<tamM ; i++)
    {
        for(j=0; j<tamE ; j++)
        {
            if(listaElectro[i].estado == OCUPADO &&
                    listaMarca[j].estado == OCUPADO &&
                    listaElectro[i].idMarca == listaMarca[j].idMarca &&
                    listaElectro[i].anioModelo == 2020)
            {
                printf("\n %d    %10d    %5d    %10d %10s  \n",
                       listaElectro[i].idElectromestico,
                       listaElectro[i].serieElectrodomestico,
                       listaElectro[i].anioModelo,
                       listaElectro[i].idMarca,
                       listaMarca[j].descripcionMarca);
                retorno = 0;
            }
        }


    }

    return retorno;
}

void ordenarPorElec(eElecotrodomestico listaElectro[],int tamE )
{
    eElecotrodomestico auxElec;


    int i;
    int j;

    for(i=0; i<tamE-1; i++)
    {
        for(j=i+1; j<tamE; j++)
        {

            if(listaElectro[i].anioModelo > listaElectro[i].anioModelo )
            {


                auxElec = listaElectro[i];
                listaElectro[i] = listaElectro[j];
                listaElectro[j] = auxElec;

            }
            else
            {

                if(listaElectro[i].anioModelo == listaElectro[i].anioModelo && listaElectro[i].serieElectrodomestico > listaElectro[j].serieElectrodomestico && listaElectro[i].estado == OCUPADO && listaElectro[j].estado ==OCUPADO )
                {


                    auxElec = listaElectro[i];
                    listaElectro[i] = listaElectro[j];
                    listaElectro[j] = auxElec;



                }
            }
        }

    }
    printf("\n\nsistema ordenado\n");


}


int bajaElectro(eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[], int tamM , int* idAsiganado)
{
    int id;
    char confirma;
    int retorno = -1;
    int esta;
//    int i;
    mostrarElectroMarca(listaElectro,tamE, listaMarca,tamM);



    id = getInt("ingrese id del electro\n","ERROR id invalido 100 y 1005\n",100,105);

    esta = buscarIdElectro(listaElectro,tamE,id); // si da -1 es porque el id no existe
    // sino muestra el indice de donde se encuentra el id

    if( esta == -1)
    {
        printf("el numero de id no existe\n");
    }
    else
    {
        printf("usted eligio este numero :%d\n",id);

        confirma=getChar("acepta la baja? s/n  \n","ERROR \n",'s','n');


        if ( confirma == 's' )
        {
            listaElectro[esta].estado = LIBRE;

            retorno = 1;//baja
        }

        if (confirma == 'n')
        {
            retorno = -1; //no baja
        }



    }
    return retorno;
}

int buscarIdElectro(eElecotrodomestico listaElectro[], int tamE, int id)
{

    int indice = -1;

    for(int i=0; i<tamE; i++)
    {
        if(listaElectro[i].estado == OCUPADO && listaElectro[i].idElectromestico == id)
        {
            indice = i;
            break;
        }
    }


    return indice;

}

int modificarElectro(eElecotrodomestico listaElectro[], int tamE,eMarca listaMarca[], int tamM)
{
    int id;
    int esta;
    int opcionModificar;
    int retorno ;

    mostrarElectroMarca(listaElectro,tamE,listaMarca,tamM);


    id = getInt("ingrese el id que desea modificar\n","ERROR id entre 100 y 105\n",100,105);


    esta = buscarIdElectro(listaElectro,tamE,id);


    if(esta == -1)
    {
        printf("el id elegido no esta registrado\n");
        retorno = -1;

    }
    else
    {

        do
        {

            printf("Que opcion quiere cambiar?\n");
            printf("1.numero de serie\n");
            printf("2.anio modelo\n");
            printf("3.guardar modificaciones\n");
            scanf("%d", &opcionModificar);

            while(opcionModificar < 1 || opcionModificar> 4)
            {
                printf("ERROR Elija una opcion:\n ");
                fflush(stdin);
                scanf("%d", &opcionModificar);
            }


            switch(opcionModificar)
            {
            case 1:
                listaElectro[esta].serieElectrodomestico = getInt("ingrese nuevo numero de serie entre 300 y 305\n", "ERRROR\n",300,305);
                printf("numero de serie cambiado\n");
                break;

            case 2:
                listaElectro[esta].anioModelo = getInt("elija a�o entre 1990- 2020\n", "ERROR numero invalido\n",1990,2020);
                printf("fecha cambiad\n");
                break;


            }
            retorno= 1;
        }
        while(opcionModificar != 3);


    }
    return retorno;
}

int altaElectrodomesticosMarca(eElecotrodomestico listaElectro[], int tamE, int* idAsiganado, eMarca listaMarca[], int tamM)
{
    int retorno = -1;
    int indice;
    int id;
    eElecotrodomestico nuevoElectro;
    int opcionMarca;

    id = *idAsiganado; // le paso el valor dado a id
    indice = buscarLibreElectro(listaElectro, tamE);

    printf("*** Alta electro ***\n\n");

    if( indice == -1)
    {

        printf("No hay lugar en el sistema\n\n");
        system("pause");
    }
    else
    {

        nuevoElectro.idElectromestico = id;
        *idAsiganado = id+1; //el puntero que voy a llevar al main, le aumento el id +1
        nuevoElectro.serieElectrodomestico = getInt("ingrese numero de serie entre 300 y 305\n", "ERROR numero de serie mal\n",300,305);

        mostrarMarca(listaMarca,tamM);
        opcionMarca = getInt("eliga id del servicio\n", " ERROR id ivalido\n",1000,1005);
        nuevoElectro.idMarca = opcionMarca;
        nuevoElectro.anioModelo = getInt("elija a�o 1990- 2020\n", "ERROR numero invalido\n",1990,2021);

        nuevoElectro.estado = OCUPADO;

        listaElectro[indice] = nuevoElectro;
        retorno = 1;
    }
    return retorno;
}


void harcodearMarcas(eMarca listaMarca[])
{
    int i;
    eMarca marcas[]=
    {
        {1001,"wirpoll",OCUPADO},
        {1002,"sony",OCUPADO},
        {1003,"liliana",OCUPADO},
        {1004,"gafa",OCUPADO},
        {1005,"philips",OCUPADO}
    };

    for( i=0; i < 5 ; i++)
    {

        listaMarca[i] = marcas[i];
    }
}

void harcodearElectrodomesticos(eElecotrodomestico listaElectro[])
{
    int i;
    eElecotrodomestico electro[]=
    {
        {101,300,1001,2018,OCUPADO},
        {102,304,1002,2021,OCUPADO},
        {103,301,1003,2020,OCUPADO},
        {104,303,1004,2021,OCUPADO},
        {105,302,1003,2020,OCUPADO}
    };

    for( i=0; i < 5 ; i++)
    {

        listaElectro[i] = electro[i];
    }
}

int mostrarMarca(eMarca listaMarca[], int tamM)
{
    int i;
    int retorno = -1;
    int flagMarca = -1;

    printf("idMarca    marca \n");
    for(i=0; i<tamM ; i++)
    {
        if(listaMarca[i].estado == OCUPADO )
        {
            printf("\n %d  %10s  \n",
                   listaMarca[i].idMarca,
                   listaMarca[i].descripcionMarca);
            retorno = 0;
            flagMarca = 0;
        }

    }
    if(flagMarca == -1)
        {
            printf("no hay marcas para mostrar \n");
        }

    return retorno;
}

int mostrarElectroMarca(eElecotrodomestico listaElectro[], int tamE, eMarca listaMarca[], int tamM)
{

    int i;
    int j;
    int retorno = -1;
    int flag = -1;

    printf("numSerie   idElectro    fechaModelo   idMarca   marca \n");
    for(i=0; i<tamM ; i++)
    {
        for(j=0; j<tamE ; j++)
        {
            if(listaElectro[i].estado == OCUPADO &&
                    listaMarca[j].estado == OCUPADO &&
                    listaElectro[i].idMarca == listaMarca[j].idMarca)
            {
                printf("\n %d    %10d    %5d    %10d %10s  \n",
                       listaElectro[i].serieElectrodomestico,
                       listaElectro[i].idElectromestico,
                       listaElectro[i].anioModelo,
                       listaElectro[i].idMarca,
                       listaMarca[j].descripcionMarca);
                flag = 0;
                retorno = 0;
            }

        }
    }

    if(flag == -1)
    {
        printf("No hay electrodomesticos para mostrar\n");
    }

    return retorno;
}


int inicializarElectro(eElecotrodomestico listaElectro[], int tamE)
{
    int i;
    int retorno = -1;
    for(i=0; i<tamE; i++)
    {

        listaElectro[i].estado = LIBRE;
        retorno = 0;
    }
    return retorno;
}
int buscarIdClientes(eElecotrodomestico listaElectro[], int tamE, int id)
{


    int indice = -1;

    for(int i=0; i<tamE; i++)
    {
        if(listaElectro[i].estado == OCUPADO && listaElectro[i].idElectromestico == id)
        {
            indice = i;
            break;
        }
    }


    return indice;

}

int buscarLibreElectro(eElecotrodomestico listaElectro[], int tamE)
{
    int i;
    int index = -1;
    for(i=0; i<tamE; i++)
    {
        if(listaElectro[i].estado == LIBRE)
        {
            index = i;
            break;
        }
    }
    return index;
}


int inicializarMarca(eMarca listaMarca[], int tamM)
{
    int i;
    int retorno = -1;
    for(i=0; i<tamM; i++)
    {

        listaMarca[i].estado = LIBRE;
        retorno = 0;
    }
    return retorno;
}
